// Service Worker for CODE BAZAR PWA & Web Push Notifications
const CACHE_NAME = 'codebazar-pwa-v2';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Handle Background Push Events
self.addEventListener('push', (event) => {
  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { title: 'CODE BAZAR', body: event.data.text() };
    }
  }

  const title = data.title || 'CODE BAZAR - নতুন আপডেট!';
  const options = {
    body: data.body || 'নতুন প্রোডাক্ট এবং এক্সক্লুসিভ অফার দেখতে ট্যাপ করুন।',
    icon: data.icon || '/icon-192.png',
    badge: data.badge || '/favicon.png',
    image: data.image || null,
    data: data.data || { url: '/' },
    vibrate: [200, 100, 200, 100, 200],
    tag: data.tag || 'codebazar-broadcast',
    renotify: true,
    requireInteraction: false
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

// Handle Notification Click (Open Website or Product)
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // If a window is already open, focus it
      for (const client of clientList) {
        if (client.url && 'focus' in client) {
          if ('navigate' in client && targetUrl !== '/') {
            client.navigate(targetUrl);
          }
          return client.focus();
        }
      }
      // Otherwise open a new window
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});

// Cache / Fetch Handler
self.addEventListener('fetch', (event) => {
  event.respondWith(
    fetch(event.request).catch(() => {
      return caches.match(event.request);
    })
  );
});
