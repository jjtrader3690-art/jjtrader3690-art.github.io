export type Language = 'bn' | 'en';

export type CategoryId = string;

export interface Category {
  id: CategoryId;
  nameBn: string;
  nameEn: string;
  icon?: string;
}

export type DeliveryType = 'instant' | 'manual' | '5m';

export interface ProductVariant {
  id: string;
  nameBn: string;
  nameEn: string;
  durationBn: string;
  durationEn: string;
  price: number;
  originalPrice?: number;
  inStock: boolean;
  stockCount: number;
  credentialsPool?: Array<{
    email?: string;
    password?: string;
    pin?: string;
    licenseKey?: string;
    profileName?: string;
    additionalInfo?: string;
  }>;
}

export interface Product {
  id: string;
  categoryId: CategoryId;
  titleBn: string;
  titleEn: string;
  shortDescBn: string;
  shortDescEn: string;
  descriptionBn: string;
  descriptionEn: string;
  imageUrl: string;
  bgGradient: string;
  popular?: boolean;
  featured?: boolean;
  deliveryType: DeliveryType;
  warrantyBn: string;
  warrantyEn: string;
  variants: ProductVariant[];
  rating: number;
  soldCount: number;
  instructionsBn: string;
  instructionsEn: string;
  demoImages?: string[];
  demoUrl?: string;
}

export interface CredentialDetails {
  email?: string;
  password?: string;
  pin?: string;
  licenseKey?: string;
  profileName?: string;
  additionalInfo?: string;
}

export type OrderStatus = 'active' | 'completed' | 'expired' | 'processing' | 'refunded';

export interface Order {
  id: string;
  orderNumber: string;
  userId?: string;
  userEmail?: string;
  userPhone?: string;
  userName?: string;
  productId: string;
  productTitleBn: string;
  productTitleEn: string;
  productImage: string;
  variantId: string;
  variantNameBn: string;
  variantNameEn: string;
  price: number;
  purchaseDate: string;
  expiryDate: string;
  status: OrderStatus;
  deliveryType: DeliveryType;
  credentials?: CredentialDetails;
  instructionsBn: string;
  instructionsEn: string;
  warrantyDays: number;
  warrantyClaimed?: boolean;
  // Custom site ordering details
  siteName?: string;
  siteLogoUrl?: string;
  siteAdminEmail?: string;
  siteAdminPassword?: string;
  sitePhone?: string;
  // Payment info
  paymentMethod?: PaymentMethod | 'wallet';
  paymentTrxId?: string;
  paymentSenderMobile?: string;
}

export interface RegisteredUser {
  id: string;
  name: string;
  phone: string;
  email: string;
  password?: string;
  registeredAt: string;
  walletBalance: number;
  isBlocked?: boolean;
}

export type PaymentMethod = 'bkash' | 'nagad';

export type WalletTxType = 'deposit' | 'purchase' | 'refund' | 'bonus';
export type WalletTxStatus = 'approved' | 'pending' | 'rejected';

export interface WalletTransaction {
  id: string;
  type: WalletTxType;
  amount: number;
  method: PaymentMethod | 'wallet' | 'system';
  userId?: string;
  userEmail?: string;
  userName?: string;
  trxId?: string;
  senderMobile?: string;
  date: string;
  status: WalletTxStatus;
  descriptionBn: string;
  descriptionEn: string;
  bonusAmount?: number;
}

export type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed';

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  orderId?: string;
  subject: string;
  category: 'account_issue' | 'replacement' | 'deposit_issue' | 'other';
  status: TicketStatus;
  createdAt: string;
  updatedAt: string;
  messages: Array<{
    id: string;
    sender: 'user' | 'support';
    text: string;
    timestamp: string;
  }>;
}

export interface ResellerTier {
  nameBn: string;
  nameEn: string;
  level: 'regular' | 'silver' | 'gold' | 'diamond';
  discountPercent: number;
  minMonthlySpend: number;
  badgeColor: string;
}

export interface UserProfile {
  id?: string;
  name: string;
  email: string;
  phone: string;
  walletBalance: number;
  pendingBalance: number;
  rewardPoints: number;
  tier: ResellerTier;
  apiKey?: string;
  avatarUrl: string;
  isBlocked?: boolean;
}

export interface Announcement {
  id: string;
  textBn: string;
  textEn: string;
  type: 'info' | 'warning' | 'success';
  active: boolean;
}

export interface PromoBanner {
  id: string;
  imageUrl: string;
  title?: string;
  linkUrl?: string;
  active: boolean;
}

export interface SiteConfig {
  siteName: string;
  siteTaglineBn: string;
  siteTaglineEn: string;
  logoUrl?: string;
  whatsappNumber: string;
  telegramLink: string;
  supportEmail: string;
  helplinePhone: string;
  adminPin: string;
  adminApiKey?: string;
  adminMasterKey?: string;
  ownerRecoveryEmail?: string;
  isAdminPermanentlyLocked?: boolean;
  adminLockReason?: string;
  adminLockedAt?: string;
  whatsappBannerText: string;
  whatsappIconUrl?: string;
  footerAboutBn: string;
  copyrightText: string;
  currencySymbol: string;
  telegramBotToken?: string; // Default fallback bot token
  telegramChatId?: string; // Main / Orders Channel ID
  telegramOrderBotToken?: string; // Dedicated Orders Bot Token
  telegramRegistrationBotToken?: string; // Dedicated Registration Bot Token
  telegramRegistrationChatId?: string; // New User Registration Channel ID
  telegramDepositBotToken?: string; // Dedicated Deposit Bot Token
  telegramDepositChatId?: string; // General Deposit Channel ID
  telegramBkashChatId?: string; // bKash Deposit Channel ID
  telegramNagadChatId?: string; // Nagad Deposit Channel ID
  telegramRocketChatId?: string; // Rocket / Other Deposit Channel ID
  telegramNotifyEnabled?: boolean;
  pushNotifyEnabled?: boolean;
  pushAutoNotifyOnNewProduct?: boolean;
}

export interface PushBroadcast {
  id: string;
  title: string;
  body: string;
  icon?: string;
  image?: string;
  url?: string;
  productId?: string;
  tag?: string;
  createdAt: string;
  timestamp: number;
}

export interface VisitorStats {
  totalVisits: number;
  todayVisits: number;
  uniqueVisitors: number;
  liveVisitors: number;
  lastVisitAt: string;
  dailyVisits?: Record<string, number>;
}

