import React, { useState } from 'react';
import { Product, ProductVariant } from '../types';
import { useStore } from '../context/StoreContext';
import {
  ShoppingBag,
  Eye
} from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    language,
    setSelectedProductForBuy,
    addToast,
    isUserLoggedIn,
    setIsAuthModalOpen
  } = useStore();
  const [selectedVariant] = useState<ProductVariant>(
    product.variants[0] || {}
  );

  const isBn = language === 'bn';
  const originalPrice = selectedVariant.originalPrice || Math.round(selectedVariant.price * 1.2);
  const currentPrice = selectedVariant.price;

  const handleBuyClick = () => {
    if (!isUserLoggedIn) {
      addToast(isBn ? 'অর্ডার সম্পন্ন করতে দয়া করে রেজিস্ট্রেশন/লগইন করুন।' : 'Please register/login to place an order.', 'info');
      setIsAuthModalOpen(true);
      return;
    }
    setSelectedProductForBuy(product);
  };

  const getValidDemoUrl = (url?: string) => {
    if (!url || !url.trim()) return null;
    const trimmed = url.trim();
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) return trimmed;
    return `https://${trimmed}`;
  };

  const demoLink = getValidDemoUrl(product.demoUrl);

  const handleEyeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (demoLink) {
      window.open(demoLink, '_blank', 'noopener,noreferrer');
    } else {
      addToast(
        isBn
          ? 'এই প্রোডাক্টের লাইভ ডেমো লিঙ্ক যুক্ত করা হয়নি।'
          : 'No live demo link added for this product.',
        'info'
      );
    }
  };

  return (
    <div className="group relative bg-white border border-slate-200/90 hover:border-blue-500 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between">
      
      {/* Product Image Header */}
      <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-slate-100">
        <img
          src={product.imageUrl}
          alt={product.titleEn}
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80';
          }}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/30 via-transparent to-transparent" />
      </div>

      {/* Product Title & Details */}
      <div className="p-3.5 flex-1 flex flex-col justify-between space-y-2.5">
        <div>
          <h3 className="text-xs sm:text-sm font-black text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 min-h-[36px] leading-snug">
            {isBn ? product.titleBn : product.titleEn}
          </h3>
        </div>

        {/* Price Section */}
        <div className="flex items-baseline gap-2">
          <span className="text-base sm:text-lg font-black text-blue-700">
            ৳{currentPrice.toLocaleString()}
          </span>
          <span className="text-xs text-slate-400 line-through font-semibold">
            ৳{originalPrice.toLocaleString()}
          </span>
        </div>

        {/* Action Buttons Row (Buy Now + Eye Icon for Direct Live Demo) */}
        <div className="flex items-center gap-1.5 pt-1">
          <button
            onClick={handleBuyClick}
            disabled={!selectedVariant.inStock}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1 transition-all shadow-xs active:scale-95 cursor-pointer ${
              selectedVariant.inStock
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-slate-200 text-slate-500 cursor-not-allowed'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Buy Now</span>
          </button>

          <button
            onClick={handleEyeClick}
            className={`p-2 rounded-xl transition-all flex items-center justify-center cursor-pointer active:scale-95 shrink-0 border ${
              demoLink
                ? 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700 hover:text-blue-600'
                : 'bg-slate-100 border-slate-200 text-slate-700 hover:text-blue-600'
            }`}
            title={demoLink ? (isBn ? 'লাইভ ডেমো ওয়েবসাইট ভিজিট করুন' : 'Visit Live Demo Website') : (isBn ? 'ডেমো লিঙ্ক নেই' : 'No Demo Link')}
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};




