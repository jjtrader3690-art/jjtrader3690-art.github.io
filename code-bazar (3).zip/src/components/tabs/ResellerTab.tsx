import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  UserCheck,
  Shield,
  Key,
  Copy,
  Check,
  Download,
  Percent,
  TrendingUp,
  Award,
  Zap,
  Code2,
  Lock
} from 'lucide-react';

export const ResellerTab: React.FC = () => {
  const { user, language, products, addToast } = useStore();
  const [copiedApiKey, setCopiedApiKey] = useState<boolean>(false);
  const isBn = language === 'bn';

  const handleCopyApi = () => {
    if (user.apiKey) {
      navigator.clipboard.writeText(user.apiKey);
      setCopiedApiKey(true);
      addToast(isBn ? 'API Key কপি করা হয়েছে!' : 'API Key copied!', 'success');
      setTimeout(() => setCopiedApiKey(false), 2000);
    }
  };

  const handleDownloadWholesalePriceList = () => {
    let csvContent = 'Product ID,Title,Variant,Retail Price BDT,Reseller Price BDT (VIP),Stock Status\n';
    products.forEach((p) => {
      p.variants.forEach((v) => {
        const resellerPrice = Math.floor(v.price * (1 - user.tier.discountPercent / 100));
        csvContent += `"${p.id}","${p.titleEn}","${v.nameEn}",${v.price},${resellerPrice},"${v.inStock ? 'IN STOCK' : 'OUT OF STOCK'}"\n`;
      });
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'CODE_BAZAR_Wholesale_Price_List.csv';
    link.click();

    addToast(isBn ? 'হোলসেল প্রাইস লিস্ট ডাউনলোড হয়েছে!' : 'Wholesale price list downloaded!', 'success');
  };

  return (
    <div className="space-y-6">
      
      {/* Tier Hero Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950/80 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Award className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-white">{user.tier.nameBn}</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500 text-slate-950 uppercase">
                  ACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {isBn ? `আপনি পাচ্ছেন প্রতিটি অর্ডারে ফ্ল্যাট ${user.tier.discountPercent}% রিসেলার ছাড়!` : `You get flat ${user.tier.discountPercent}% reseller discount on all orders!`}
              </p>
            </div>
          </div>

          <button
            onClick={handleDownloadWholesalePriceList}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{isBn ? 'হোলসেল রেট কার্ড ডাউনলোড (CSV)' : 'Download Wholesale Rates'}</span>
          </button>
        </div>

        {/* Reseller Level Progress */}
        <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400 font-medium">{isBn ? 'ডায়মন্ড রিসেলার টার্গেট (৳10,000/মাস):' : 'Diamond Reseller Target (৳10,000/mo):'}</span>
            <span className="font-bold text-amber-400">৳ 6,450 / ৳ 10,000 (64%)</span>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-amber-500 to-amber-300 w-[64%] rounded-full" />
          </div>
        </div>
      </div>

      {/* API Key Management */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Code2 className="w-5 h-5 text-cyan-400" />
            <span>{isBn ? 'রিসেলার অটোমেশন এপিআই (REST API)' : 'Automated Reseller API'}</span>
          </h3>
          <span className="text-xs text-emerald-400 font-bold bg-emerald-950 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
            READY
          </span>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          {isBn
            ? 'আপনার ওয়েবসাইট বা ওয়েবসাইট বটের মাধ্যমে স্বয়ংক্রিয়ভাবে CODE BAZAR থেকে প্রোডাক্ট কেনার জন্য এপিআই কী ব্যবহার করুন।'
            : 'Integrate CODE BAZAR digital products directly into your own website or Telegram bot using REST API.'}
        </p>

        <div className="flex items-center justify-between bg-slate-950 border border-slate-800 p-3 rounded-xl">
          <div className="font-mono text-xs font-bold text-cyan-300 tracking-wider truncate mr-2">
            {user.apiKey}
          </div>
          <button
            onClick={handleCopyApi}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-bold rounded-lg border border-slate-700 cursor-pointer shrink-0"
          >
            {copiedApiKey ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copiedApiKey ? (isBn ? 'কপি হয়েছে' : 'Copied') : (isBn ? 'কপি' : 'Copy')}</span>
          </button>
        </div>
      </div>

      {/* Reseller Discount Price Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="p-4 bg-slate-950 border-b border-slate-800">
          <h3 className="text-sm font-bold text-white">
            {isBn ? 'লাইভ প্রাইজ ও ভিআইপি রেট চার্ট' : 'Live Product Wholesale Rates'}
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800 uppercase text-[10px]">
              <tr>
                <th className="p-3.5">{isBn ? 'প্রোডাক্ট ও ভ্যারিয়েন্ট' : 'Product & Variant'}</th>
                <th className="p-3.5">{isBn ? 'রিটেইল রেট' : 'Retail Price'}</th>
                <th className="p-3.5 text-amber-400">{isBn ? 'ভিআইপি রিসেলার প্রাইস' : 'VIP Reseller Rate'}</th>
                <th className="p-3.5 text-right">{isBn ? 'প্রফিট মার্জিন' : 'Profit Margin'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {products.map((p) =>
                p.variants.map((v) => {
                  const vipPrice = Math.floor(v.price * (1 - user.tier.discountPercent / 100));
                  const profit = v.price - vipPrice;
                  return (
                    <tr key={v.id} className="hover:bg-slate-800/30">
                      <td className="p-3.5">
                        <span className="font-bold text-white block">{isBn ? p.titleBn : p.titleEn}</span>
                        <span className="text-[10px] text-cyan-400">{isBn ? v.nameBn : v.nameEn}</span>
                      </td>
                      <td className="p-3.5 font-bold text-slate-300">৳ {v.price}</td>
                      <td className="p-3.5 font-black text-amber-400 text-sm">৳ {vipPrice}</td>
                      <td className="p-3.5 text-right font-bold text-emerald-400">+৳ {profit} / sale</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
