import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { Product, CategoryId, Category, RegisteredUser, PromoBanner } from '../../types';
import {
  Settings,
  PlusCircle,
  Database,
  Check,
  Zap,
  PackagePlus,
  Edit3,
  Trash2,
  Phone,
  Megaphone,
  Wallet,
  Save,
  X,
  Plus,
  Tag,
  Users,
  LayoutGrid,
  Search,
  Mail,
  Lock,
  Unlock,
  Key,
  KeyRound,
  Cpu,
  ShieldAlert,
  Code2,
  ShieldCheck,
  Image as ImageIcon,
  Upload,
  ShoppingBag,
  Clock,
  CheckCircle2,
  XCircle,
  Globe,
  Ban,
  UserX,
  UserCheck,
  Send,
  Sparkles,
  Bot,
  Eye,
  EyeOff,
  Activity,
  TrendingUp,
  BarChart2,
  Bell,
  BellRing,
  Radio,
  Smartphone,
  Link as LinkIcon,
  Play,
  MessageCircle,
  ExternalLink
} from 'lucide-react';


const compressImageFile = (file: File, maxWidth = 600, maxHeight = 600, quality = 0.7): Promise<string> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (!dataUrl) {
        resolve('');
        return;
      }
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;
        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        } else {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    };
    reader.onerror = () => resolve('');
    reader.readAsDataURL(file);
  });
};

interface ImageUploadFieldProps {
  label: string;
  value: string;
  onChange: (url: string) => void;
  isBn?: boolean;
}

const ImageUploadField: React.FC<ImageUploadFieldProps> = ({ label, value, onChange, isBn = true }) => {
  const [showUrlInput, setShowUrlInput] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      alert(isBn ? 'ইমেজ ফাইলের সাইজ ১০ মেগাবাইটের কম হতে হবে।' : 'Image file size must be under 10MB.');
      return;
    }

    const compressed = await compressImageFile(file);
    if (compressed) {
      onChange(compressed);
    }
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="text-slate-300 font-bold block text-xs">{label}</label>
        <button
          type="button"
          onClick={() => setShowUrlInput(!showUrlInput)}
          className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
        >
          {showUrlInput ? (isBn ? 'গ্যালারি/ফাইল আপলোড' : 'File Upload') : (isBn ? 'ইউআরএল লিঙ্ক ইনপুট' : 'Paste URL')}
        </button>
      </div>

      {value && (
        <div className="relative w-full h-36 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden group mb-1.5">
          <img src={value} alt="Preview" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-slate-950/70 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => onChange('')}
              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow cursor-pointer transition active:scale-95"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{isBn ? 'ছবি মুছুন' : 'Remove'}</span>
            </button>
          </div>
        </div>
      )}

      {!showUrlInput ? (
        <label className="cursor-pointer border-2 border-dashed border-slate-700 hover:border-cyan-500 bg-slate-950/80 hover:bg-slate-950 p-3 rounded-xl flex items-center justify-center gap-2 transition group text-center">
          <Upload className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition shrink-0" />
          <span className="text-xs font-bold text-slate-300 group-hover:text-cyan-400">
            {value
              ? (isBn ? 'অন্য ছবি পরিবর্তন/আপলোড করুন' : 'Change/Upload New Image')
              : (isBn ? 'গ্যালারি বা ডিভাইস থেকে ছবি আপলোড করুন' : 'Upload Image from Gallery/Device')}
          </span>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
        </label>
      ) : (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="https://images.unsplash.com/..."
          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 font-mono"
        />
      )}
    </div>
  );
};

interface MultipleImageUploadFieldProps {
  label: string;
  images: string[];
  onChange: (images: string[]) => void;
  isBn?: boolean;
}

const MultipleImageUploadField: React.FC<MultipleImageUploadFieldProps> = ({ label, images, onChange, isBn = true }) => {
  const [showTextarea, setShowTextarea] = useState(false);

  const handleMultipleFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const compressedList: string[] = [];
    for (const file of files) {
      if (file.size <= 10 * 1024 * 1024) {
        const compressed = await compressImageFile(file);
        if (compressed) compressedList.push(compressed);
      }
    }
    if (compressedList.length > 0) {
      onChange([...images, ...compressedList]);
    }
  };

  const handleRemoveImage = (index: number) => {
    onChange(images.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="text-slate-300 font-bold block text-xs">{label}</label>
        <button
          type="button"
          onClick={() => setShowTextarea(!showTextarea)}
          className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
        >
          {showTextarea ? (isBn ? 'ফাইল আপলোড মোড' : 'File Upload Mode') : (isBn ? 'কমা টেক্সট ইনপুট' : 'Comma Text Input')}
        </button>
      </div>

      {/* Grid of uploaded demo images */}
      {images.length > 0 && (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-2">
          {images.map((imgUrl, idx) => (
            <div key={idx} className="relative aspect-video bg-slate-950 border border-slate-800 rounded-lg overflow-hidden group">
              <img src={imgUrl} alt={`Demo ${idx + 1}`} className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => handleRemoveImage(idx)}
                className="absolute top-1 right-1 p-1 bg-rose-600/90 text-white rounded-md opacity-0 group-hover:opacity-100 transition hover:bg-rose-500 cursor-pointer"
                title={isBn ? 'ছবি সরান' : 'Remove Image'}
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {!showTextarea ? (
        <label className="cursor-pointer border-2 border-dashed border-slate-700 hover:border-cyan-500 bg-slate-950/80 hover:bg-slate-950 p-3 rounded-xl flex items-center justify-center gap-2 transition group text-center">
          <Upload className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition shrink-0" />
          <span className="text-xs font-bold text-slate-300 group-hover:text-cyan-400">
            {isBn ? 'একাধিক ডেমো ছবি গ্যালারি থেকে সিলেক্ট করুন' : 'Upload Multiple Demo Images'}
          </span>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={handleMultipleFiles}
            className="hidden"
          />
        </label>
      ) : (
        <textarea
          rows={2}
          value={images.join(', ')}
          onChange={(e) => {
            const list = e.target.value.split(',').map((s) => s.trim()).filter(Boolean);
            onChange(list);
          }}
          placeholder="https://image1.jpg, https://image2.jpg"
          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500"
        />
      )}
    </div>
  );
};

// Dedicated component for Admin Authentication Gate to respect React Rules of Hooks
const AdminApiKeyGate: React.FC = () => {
  const {
    language,
    verifyAdminApiKey,
    siteConfig,
    addToast
  } = useStore();

  const isBn = language === 'bn';

  // Inline auth gate states
  const [authApiKey, setAuthApiKey] = useState<string>('');
  const [showAuthApiKey, setShowAuthApiKey] = useState<boolean>(false);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);

  const handleInlineApiKeySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authApiKey.trim()) return;

    setIsConnecting(true);
    setTimeout(() => {
      const ok = verifyAdminApiKey(authApiKey);
      if (ok) {
        addToast(
          isBn ? 'API Key অথরাইজড! সিস্টেম সেশন শুরু হয়েছে।' : 'API Key Authorized! Gateway Session Active.',
          'success'
        );
        setAuthApiKey('');
      }
      setIsConnecting(false);
    }, 250);
  };

  return (
    <div className="bg-slate-900/95 border border-slate-700/80 shadow-2xl shadow-blue-500/10 p-6 sm:p-8 rounded-3xl space-y-5 my-6 max-w-md mx-auto transition-all">
      {/* Brand Header */}
      <div className="flex items-center gap-3.5 border-b border-slate-800 pb-4">
        <img
          src={siteConfig.logoUrl || '/favicon.svg'}
          alt="Site Logo"
          className="w-12 h-12 rounded-2xl object-cover border border-slate-700/80 shadow-sm shrink-0 bg-slate-950 p-1"
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).src = '/favicon.svg';
          }}
        />
        <div>
          <h2 className="text-base font-black text-white tracking-tight">
            {siteConfig.siteName || 'XS BAZAR'}
          </h2>
          <p className="text-[11px] text-slate-400 font-mono">
            Secure Access Gateway
          </p>
        </div>
      </div>

      {/* Connection Form */}
      <form onSubmit={handleInlineApiKeySubmit} className="space-y-4">
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-slate-300 block">
              {isBn ? 'সিক্রেট API Key:' : 'Secret API Key:'}
            </label>
            <button
              type="button"
              onClick={() => setShowAuthApiKey(!showAuthApiKey)}
              className="text-[11px] text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1 cursor-pointer"
            >
              {showAuthApiKey ? (
                <>
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>{isBn ? 'লুকান' : 'Hide'}</span>
                </>
              ) : (
                <>
                  <Eye className="w-3.5 h-3.5" />
                  <span>{isBn ? 'দেখুন' : 'Show'}</span>
                </>
              )}
            </button>
          </div>

          <div className="relative">
            <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-400" />
            <input
              type={showAuthApiKey ? 'text' : 'password'}
              value={authApiKey}
              onChange={(e) => setAuthApiKey(e.target.value)}
              placeholder=""
              className="w-full pl-10 pr-10 py-3 text-xs font-mono font-bold bg-slate-950 border border-slate-700 focus:border-blue-500 rounded-xl text-blue-300 focus:outline-none focus:ring-1 focus:ring-blue-500 transition"
              autoFocus
              required
            />
            <button
              type="button"
              onClick={() => setShowAuthApiKey(!showAuthApiKey)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-400 cursor-pointer p-1"
            >
              {showAuthApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <button
          type="submit"
          disabled={isConnecting}
          className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
        >
          {isConnecting ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>{isBn ? 'ভেরিফাই হচ্ছে...' : 'Authenticating...'}</span>
            </>
          ) : (
            <>
              <Lock className="w-4 h-4" />
              <span>{isBn ? 'প্রবেশ করুন' : 'Enter Panel'}</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

const AdminDashboardContent: React.FC = () => {
  const {
    products,
    categories,
    registeredUsers,
    banners,
    language,
    adminUpdateStock,
    adminAddCategory,
    adminUpdateCategory,
    adminDeleteCategory,
    adminAddBanner,
    adminUpdateBanner,
    adminDeleteBanner,
    adminAddProduct,
    adminEditProduct,
    adminDeleteProduct,
    adminUpdatePaymentNumbers,
    adminClearHistory,
    adminUpdateAnnouncement,
    adminUpdateUserBalance,
    adminCreditUserBalance,
    adminApproveTransaction,
    adminRejectTransaction,
    transactions,
    orders,
    adminUpdateOrderStatus,
    adminDeleteOrder,
    adminClearCancelledOrders,
    adminDeleteTransaction,
    adminClearRejectedTransactions,
    adminToggleBlockUser,
    adminDeleteUser,
    adminTestTelegramNotification,
    user,
    paymentNumbers,
    announcements,
    siteConfig,
    adminUpdateSiteConfig,
    visitorStats,
    adminResetVisitorStats,
    adminUpdateVisitorStats,
    setIsAdminAuthenticated,
    setIsAdminAuthModalOpen,
    isAdminPermanentlyLocked,
    adminLockPermanently,
    adminUnlockPermanently,
    unlockAdminWithMasterKey,
    addToast
  } = useStore();

  const isBn = language === 'bn';

  // Admin sub-tabs
  const [activeAdminSubTab, setActiveAdminSubTab] = useState<'orders' | 'users' | 'banners' | 'categories' | 'products' | 'payments' | 'notice' | 'balance' | 'add_stock' | 'site_settings'>('orders');

  // Site Customization Settings State
  const [siteNameForm, setSiteNameForm] = useState<string>(siteConfig.siteName);
  const [siteTaglineBnForm, setSiteTaglineBnForm] = useState<string>(siteConfig.siteTaglineBn);
  const [siteTaglineEnForm, setSiteTaglineEnForm] = useState<string>(siteConfig.siteTaglineEn);
  const [logoUrlForm, setLogoUrlForm] = useState<string>(siteConfig.logoUrl || '');
  const [whatsappNumberForm, setWhatsappNumberForm] = useState<string>(siteConfig.whatsappNumber);
  const [whatsappBannerTextForm, setWhatsappBannerTextForm] = useState<string>(siteConfig.whatsappBannerText);
  const [whatsappIconUrlForm, setWhatsappIconUrlForm] = useState<string>(siteConfig.whatsappIconUrl || '');
  const [telegramLinkForm, setTelegramLinkForm] = useState<string>(siteConfig.telegramLink);
  const [supportEmailForm, setSupportEmailForm] = useState<string>(siteConfig.supportEmail);
  const [helplinePhoneForm, setHelplinePhoneForm] = useState<string>(siteConfig.helplinePhone);
  const [adminApiKeyForm, setAdminApiKeyForm] = useState<string>(siteConfig.adminApiKey || 'CB-ADMIN-SECURE-998877-KEY');
  const [adminPinForm, setAdminPinForm] = useState<string>(siteConfig.adminPin);
  const [adminMasterKeyForm, setAdminMasterKeyForm] = useState<string>(siteConfig.adminMasterKey || 'MASTER#3690#JJ');
  const [ownerRecoveryEmailForm, setOwnerRecoveryEmailForm] = useState<string>(siteConfig.ownerRecoveryEmail || 'jjtrader3690@gmail.com');
  const [footerAboutBnForm, setFooterAboutBnForm] = useState<string>(siteConfig.footerAboutBn);
  const [copyrightTextForm, setCopyrightTextForm] = useState<string>(siteConfig.copyrightText);
  const [currencySymbolForm, setCurrencySymbolForm] = useState<string>(siteConfig.currencySymbol);

  // Telegram Bot Notification Form State
  const [telegramBotTokenForm, setTelegramBotTokenForm] = useState<string>(siteConfig.telegramBotToken || '');
  const [telegramChatIdForm, setTelegramChatIdForm] = useState<string>(siteConfig.telegramChatId || '');
  const [telegramOrderBotTokenForm, setTelegramOrderBotTokenForm] = useState<string>(siteConfig.telegramOrderBotToken || '');
  const [telegramRegistrationBotTokenForm, setTelegramRegistrationBotTokenForm] = useState<string>(siteConfig.telegramRegistrationBotToken || '');
  const [telegramRegistrationChatIdForm, setTelegramRegistrationChatIdForm] = useState<string>(siteConfig.telegramRegistrationChatId || '');
  const [telegramDepositBotTokenForm, setTelegramDepositBotTokenForm] = useState<string>(siteConfig.telegramDepositBotToken || '');
  const [telegramDepositChatIdForm, setTelegramDepositChatIdForm] = useState<string>(siteConfig.telegramDepositChatId || '');
  const [telegramBkashChatIdForm, setTelegramBkashChatIdForm] = useState<string>(siteConfig.telegramBkashChatId || '');
  const [telegramNagadChatIdForm, setTelegramNagadChatIdForm] = useState<string>(siteConfig.telegramNagadChatId || '');
  const [telegramRocketChatIdForm, setTelegramRocketChatIdForm] = useState<string>(siteConfig.telegramRocketChatId || '');
  const [telegramNotifyEnabledForm, setTelegramNotifyEnabledForm] = useState<boolean>(siteConfig.telegramNotifyEnabled ?? true);

  const handleSaveSiteSettings = (e: React.FormEvent) => {
    e.preventDefault();
    adminUpdateSiteConfig({
      siteName: siteNameForm,
      siteTaglineBn: siteTaglineBnForm,
      siteTaglineEn: siteTaglineEnForm,
      logoUrl: logoUrlForm,
      whatsappNumber: whatsappNumberForm,
      whatsappBannerText: whatsappBannerTextForm,
      whatsappIconUrl: whatsappIconUrlForm,
      telegramLink: telegramLinkForm,
      supportEmail: supportEmailForm,
      helplinePhone: helplinePhoneForm,
      adminApiKey: adminApiKeyForm,
      adminPin: adminPinForm,
      adminMasterKey: adminMasterKeyForm,
      ownerRecoveryEmail: ownerRecoveryEmailForm,
      footerAboutBn: footerAboutBnForm,
      copyrightText: copyrightTextForm,
      currencySymbol: currencySymbolForm,
      telegramBotToken: telegramBotTokenForm,
      telegramChatId: telegramChatIdForm,
      telegramOrderBotToken: telegramOrderBotTokenForm,
      telegramRegistrationBotToken: telegramRegistrationBotTokenForm,
      telegramRegistrationChatId: telegramRegistrationChatIdForm,
      telegramDepositBotToken: telegramDepositBotTokenForm,
      telegramDepositChatId: telegramDepositChatIdForm,
      telegramBkashChatId: telegramBkashChatIdForm,
      telegramNagadChatId: telegramNagadChatIdForm,
      telegramRocketChatId: telegramRocketChatIdForm,
      telegramNotifyEnabled: telegramNotifyEnabledForm
    });
  };

  // Banner State
  const [bannerUrlInput, setBannerUrlInput] = useState<string>('');
  const [bannerTitleInput, setBannerTitleInput] = useState<string>('');
  const [bannerLinkInput, setBannerLinkInput] = useState<string>('');

  // Edit Banner Modal State
  const [editingBanner, setEditingBanner] = useState<PromoBanner | null>(null);
  const [editBannerUrl, setEditBannerUrl] = useState<string>('');
  const [editBannerTitle, setEditBannerTitle] = useState<string>('');
  const [editBannerLink, setEditBannerLink] = useState<string>('');
  const [editBannerActive, setEditBannerActive] = useState<boolean>(true);

  // Users Filter State
  const [userSearchQuery, setUserSearchQuery] = useState<string>('');

  // Category Add State
  const [catNameBn, setCatNameBn] = useState<string>('');
  const [catNameEn, setCatNameEn] = useState<string>('');

  // Edit product modal state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Payment Numbers & Logos & Status Form
  const [payBkash, setPayBkash] = useState<string>(paymentNumbers.bkash);
  const [payNagad, setPayNagad] = useState<string>(paymentNumbers.nagad);
  const [payRocket, setPayRocket] = useState<string>(paymentNumbers.rocket);
  const [payUpay, setPayUpay] = useState<string>(paymentNumbers.upay);
  const [payBkashLogo, setPayBkashLogo] = useState<string>(paymentNumbers.bkashLogo || '');
  const [payNagadLogo, setPayNagadLogo] = useState<string>(paymentNumbers.nagadLogo || '');
  const [payRocketLogo, setPayRocketLogo] = useState<string>(paymentNumbers.rocketLogo || '');
  const [payUpayLogo, setPayUpayLogo] = useState<string>(paymentNumbers.upayLogo || '');

  const [payBkashEnabled, setPayBkashEnabled] = useState<boolean>(paymentNumbers.bkashEnabled ?? true);
  const [payNagadEnabled, setPayNagadEnabled] = useState<boolean>(paymentNumbers.nagadEnabled ?? true);
  const [payRocketEnabled, setPayRocketEnabled] = useState<boolean>(paymentNumbers.rocketEnabled ?? true);
  const [payUpayEnabled, setPayUpayEnabled] = useState<boolean>(paymentNumbers.upayEnabled ?? true);
  const [payQuickAmounts, setPayQuickAmounts] = useState<string>((paymentNumbers.quickDepositAmounts || [100, 300, 500, 1000, 2000, 5000]).join(', '));

  // Inline delete confirmation states (avoids blocked window.confirm in iframe)
  const [deletingCatId, setDeletingCatId] = useState<string | null>(null);
  const [deletingProdId, setDeletingProdId] = useState<string | null>(null);

  useEffect(() => {
    setPayBkash(paymentNumbers.bkash || '');
    setPayNagad(paymentNumbers.nagad || '');
    setPayRocket(paymentNumbers.rocket || '');
    setPayUpay(paymentNumbers.upay || '');
    setPayBkashLogo(paymentNumbers.bkashLogo || '');
    setPayNagadLogo(paymentNumbers.nagadLogo || '');
    setPayRocketLogo(paymentNumbers.rocketLogo || '');
    setPayUpayLogo(paymentNumbers.upayLogo || '');
    setPayBkashEnabled(paymentNumbers.bkashEnabled ?? true);
    setPayNagadEnabled(paymentNumbers.nagadEnabled ?? true);
    setPayRocketEnabled(paymentNumbers.rocketEnabled ?? true);
    setPayUpayEnabled(paymentNumbers.upayEnabled ?? true);
    setPayQuickAmounts((paymentNumbers.quickDepositAmounts || [100, 300, 500, 1000, 2000, 5000]).join(', '));
  }, [paymentNumbers]);

  const handleLogoCompress = (file: File, setter: (val: string) => void) => {
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
      addToast(isBn ? 'ইমেজ সাইজ ৮ মেগাবাইটের কম হতে হবে' : 'File size must be under 8MB', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxW = 320;
        const maxH = 140;
        let w = img.width;
        let h = img.height;

        if (w > maxW || h > maxH) {
          if (w / maxW > h / maxH) {
            h = Math.round((h * maxW) / w);
            w = maxW;
          } else {
            w = Math.round((w * maxH) / h);
            h = maxH;
          }
        }

        canvas.width = Math.max(1, w);
        canvas.height = Math.max(1, h);
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const compressedDataUrl = canvas.toDataURL('image/png', 0.9);
          setter(compressedDataUrl);
          addToast(isBn ? 'লোগো সফলভাবে সেট করা হয়েছে!' : 'Logo set successfully!', 'success');
        } else {
          setter(e.target?.result as string);
        }
      };
      img.onerror = () => {
        setter(e.target?.result as string);
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };
  // Notice Form
  const [noticeBn, setNoticeBn] = useState<string>(announcements[0]?.textBn || '');
  const [noticeEn, setNoticeEn] = useState<string>(announcements[0]?.textEn || '');

  // Balance Form & Manual Credit
  const [userBalanceInput, setUserBalanceInput] = useState<string>(user.walletBalance.toString());
  const [targetUserIdForCredit, setTargetUserIdForCredit] = useState<string>('');
  const [creditAmountInput, setCreditAmountInput] = useState<string>('');
  const [quickCreditUser, setQuickCreditUser] = useState<RegisteredUser | null>(null);
  const [quickCreditAmount, setQuickCreditAmount] = useState<string>('');

  const handleManualCreditUser = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(creditAmountInput);
    if (!amt || amt <= 0) {
      addToast(isBn ? 'সঠিক টাকার পরিমাণ দিন!' : 'Enter valid amount!', 'error');
      return;
    }
    const targetId = targetUserIdForCredit || registeredUsers[0]?.id || 'current';
    adminCreditUserBalance(targetId, amt);
    setCreditAmountInput('');
  };

  const handleQuickCreditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickCreditUser) return;
    const amt = parseFloat(quickCreditAmount);
    if (!amt || amt <= 0) {
      addToast(isBn ? 'সঠিক টাকার পরিমাণ দিন!' : 'Enter valid amount!', 'error');
      return;
    }
    adminCreditUserBalance(quickCreditUser.id, amt);
    setQuickCreditUser(null);
    setQuickCreditAmount('');
  };

  // Category Edit state
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingCategoryOriginalId, setEditingCategoryOriginalId] = useState<string>('');

  // Stock Add state
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [selectedVariantId, setSelectedVariantId] = useState<string>('');
  const [stockAddCount, setStockAddCount] = useState<number>(10);
  const [bulkCredentials, setBulkCredentials] = useState<string>('');

  // Add Product Form State
  const [newTitleBn, setNewTitleBn] = useState<string>('');
  const [newTitleEn, setNewTitleEn] = useState<string>('');
  const [newPrice, setNewPrice] = useState<number>(3500);
  const [newOriginalPrice, setNewOriginalPrice] = useState<number>(5000);
  const [newCategory, setNewCategory] = useState<CategoryId>('betting_scripts');
  const [newImage, setNewImage] = useState<string>('https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80');
  const [newShortDescBn, setNewShortDescBn] = useState<string>('');
  const [newShortDescEn, setNewShortDescEn] = useState<string>('');
  const [newDemoImages, setNewDemoImages] = useState<string[]>([]);
  const [newDemoUrl, setNewDemoUrl] = useState<string>('');
  const [newDeliveryType, setNewDeliveryType] = useState<'instant' | '5m'>('instant');

  // Package variants with duration state for new product
  const [newVariantsList, setNewVariantsList] = useState<
    Array<{
      id: string;
      nameBn: string;
      nameEn: string;
      durationBn: string;
      durationEn: string;
      price: number;
      originalPrice?: number;
    }>
  >([
    {
      id: 'var-d1',
      nameBn: '১ মাস মেয়াদী সাবস্ক্রিপশন',
      nameEn: '1 Month Subscription',
      durationBn: '১ মাস',
      durationEn: '1 Month',
      price: 2500,
      originalPrice: 3000
    },
    {
      id: 'var-d2',
      nameBn: '১ বছর মেয়াদী সাবস্ক্রিপশন',
      nameEn: '1 Year Subscription',
      durationBn: '১ বছর',
      durationEn: '1 Year',
      price: 5500,
      originalPrice: 7000
    },
    {
      id: 'var-d3',
      nameBn: 'লাইফটাইম মেয়াদী ফুল প্যাকেজ + সোর্স ফাইল',
      nameEn: 'Lifetime Full Package & Source',
      durationBn: 'লাইফটাইম',
      durationEn: 'Lifetime',
      price: 9500,
      originalPrice: 12000
    }
  ]);

  // Filters State
  const [productSearchQuery, setProductSearchQuery] = useState<string>('');
  const [productCategoryFilter, setProductCategoryFilter] = useState<string>('all');
  const [orderSearchQuery, setOrderSearchQuery] = useState<string>('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');

  const selectedProduct = products.find((p) => p.id === selectedProductId);

  // Filter Users
  const filteredUsers = registeredUsers.filter((u) => {
    const q = userSearchQuery.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.phone.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q)
    );
  });

  // Filter Products
  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.titleBn.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
      p.titleEn.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
      p.id.toLowerCase().includes(productSearchQuery.toLowerCase());
    const matchesCat =
      productCategoryFilter === 'all' || p.categoryId === productCategoryFilter;
    return matchesSearch && matchesCat;
  });

  // Filter Orders
  const filteredOrders = orders.filter((o) => {
    const q = orderSearchQuery.toLowerCase();
    const matchesQuery =
      (o.orderNumber && o.orderNumber.toLowerCase().includes(q)) ||
      o.id.toLowerCase().includes(q) ||
      o.productTitleBn.toLowerCase().includes(q) ||
      o.productTitleEn.toLowerCase().includes(q) ||
      (o.siteName && o.siteName.toLowerCase().includes(q)) ||
      (o.sitePhone && o.sitePhone.toLowerCase().includes(q)) ||
      (o.siteAdminEmail && o.siteAdminEmail.toLowerCase().includes(q));

    const matchesStatus =
      orderStatusFilter === 'all' || o.status === orderStatusFilter;

    return matchesQuery && matchesStatus;
  });

  const handleAddCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catNameBn.trim()) return;
    const catId = 'cat_' + Date.now();
    const newCat: Category = {
      id: catId as any,
      nameBn: catNameBn.trim(),
      nameEn: catNameEn.trim() || catNameBn.trim(),
      icon: 'Code2'
    };
    adminAddCategory(newCat);
    setCatNameBn('');
    setCatNameEn('');
  };

  const handleBannerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bannerUrlInput.trim()) return;
    adminAddBanner(
      bannerUrlInput.trim(),
      bannerTitleInput.trim() || 'Code Bazar Banner',
      bannerLinkInput.trim() || undefined
    );
    setBannerUrlInput('');
    setBannerTitleInput('');
    setBannerLinkInput('');
  };

  const handleOpenEditBanner = (b: PromoBanner) => {
    setEditingBanner(b);
    setEditBannerUrl(b.imageUrl || '');
    setEditBannerTitle(b.title || '');
    setEditBannerLink(b.linkUrl || '');
    setEditBannerActive(b.active ?? true);
  };

  const handleSaveBannerEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBanner || !editBannerUrl.trim()) return;
    adminUpdateBanner({
      ...editingBanner,
      imageUrl: editBannerUrl.trim(),
      title: editBannerTitle.trim() || 'Code Bazar Banner',
      linkUrl: editBannerLink.trim() || undefined,
      active: editBannerActive
    });
    setEditingBanner(null);
  };

  const handleBannerFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64Url = event.target?.result as string;
      if (base64Url) {
        setBannerUrlInput(base64Url);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleEditBannerFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64Url = event.target?.result as string;
      if (base64Url) {
        setEditBannerUrl(base64Url);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleStockUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || !selectedVariantId) return;
    adminUpdateStock(selectedProductId, selectedVariantId, stockAddCount, bulkCredentials);
    setBulkCredentials('');
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleBn.trim()) return;

    const prod: Product = {
      id: 'prod-' + Date.now(),
      categoryId: newCategory || 'betting_scripts',
      titleBn: newTitleBn.trim(),
      titleEn: newTitleEn.trim() || newTitleBn.trim(),
      shortDescBn: newShortDescBn.trim() || 'রেডিমেড প্রফেশনাল সফটওয়্যার ও ফুল এডমিন প্যানেল।',
      shortDescEn: newShortDescBn.trim() || 'Professional readymade software & admin panel.',
      descriptionBn: newShortDescBn.trim() || 'সম্পূর্ণ প্রফেশনাল রেডিমেড সাইট ও সফটওয়্যার।',
      descriptionEn: newShortDescBn.trim() || 'Full production-ready website with admin panel delivery.',
      imageUrl: newImage.trim() || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80',
      demoImages: [newImage.trim() || 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80'],
      demoUrl: newDemoUrl.trim() || undefined,
      bgGradient: 'from-blue-700 to-indigo-950',
      deliveryType: 'instant',
      warrantyBn: 'লাইফটাইম সাপোর্ট',
      warrantyEn: 'Lifetime Support',
      rating: 5.0,
      soldCount: 0,
      instructionsBn: 'অর্ডার কমপ্লিট হলে সরাসরি সাইটের এডমিন প্যানেল এক্সেস ও পাসওয়ার্ড প্রদান করা হবে।',
      instructionsEn: 'Direct website admin credentials delivered in order panel.',
      variants: [
        {
          id: 'var-' + Date.now(),
          nameBn: 'রেডিমেড ওয়েবসাইট + ফুল এডমিন প্যানেল',
          nameEn: 'Full Package + Admin Panel Access',
          durationBn: 'লাইফটাইম',
          durationEn: 'Lifetime',
          price: newPrice || 0,
          originalPrice: newOriginalPrice > 0 ? newOriginalPrice : undefined,
          inStock: true,
          stockCount: 10,
          credentialsPool: []
        }
      ]
    };

    adminAddProduct(prod);
    addToast(isBn ? 'নতুন প্রোডাক্ট সফলভাবে পাবলিশ হয়েছে!' : 'New product published successfully!', 'success');
    setNewTitleBn('');
    setNewShortDescBn('');
    setNewPrice(3500);
    setNewOriginalPrice(5000);
    setNewDemoUrl('');
  };

  const handleSavePaymentNumbers = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmounts = payQuickAmounts
      .split(',')
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => !isNaN(n) && n > 0);

    adminUpdatePaymentNumbers({
      bkash: payBkash,
      nagad: payNagad,
      rocket: payRocket,
      upay: payUpay,
      bkashLogo: payBkashLogo,
      nagadLogo: payNagadLogo,
      rocketLogo: payRocketLogo,
      upayLogo: payUpayLogo,
      bkashEnabled: payBkashEnabled,
      nagadEnabled: payNagadEnabled,
      rocketEnabled: payRocketEnabled,
      upayEnabled: payUpayEnabled,
      quickDepositAmounts: parsedAmounts.length > 0 ? parsedAmounts : [100, 300, 500, 1000, 2000, 5000]
    });
  };

  const handleSaveNotice = (e: React.FormEvent) => {
    e.preventDefault();
    adminUpdateAnnouncement(noticeBn, noticeEn);
  };

  const handleSaveUserBalance = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(userBalanceInput);
    if (!isNaN(val)) {
      adminUpdateUserBalance(val);
    }
  };

  const handleSaveProductEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProduct) {
      adminEditProduct(editingProduct);
      setEditingProduct(null);
    }
  };

  const totalSalesRevenue = orders.reduce((sum, o) => sum + o.price, 0);

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-slate-950 border border-amber-500/40 p-4 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-amber-400 animate-spin-slow" />
            <h2 className="text-lg font-black text-white">
              {isBn ? 'CODE BAZAR ফুল অ্যাডমিন কন্ট্রোল প্যানেল' : 'CODE BAZAR Admin Master Control Panel'}
            </h2>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            {isBn
              ? 'এখানে রেজিস্টার্ড ইউজার দেখা, পাসওয়ার্ড ম্যানেজ, ক্যাটাগরি ও প্রোডাক্ট অ্যাড/এডিট করতে পারবেন।'
              : 'View registered users with Gmail & Passwords, manage categories, edit products & update payment numbers.'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              setIsAdminAuthenticated(false);
              addToast(isBn ? 'অ্যাডমিন প্যানেল লক করা হয়েছে!' : 'Admin panel locked!', 'info');
            }}
            className="px-3.5 py-2 bg-rose-600/90 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer active:scale-95"
            title={isBn ? 'প্যানেল লক করুন' : 'Lock Panel'}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{isBn ? 'লক প্যানেল' : 'Lock Panel'}</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Pills */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800/80 pb-3">
        <button
          onClick={() => setActiveAdminSubTab('orders')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer relative ${
            activeAdminSubTab === 'orders'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>{isBn ? `কাস্টমার অর্ডারসমূহ (${orders.length})` : `Orders (${orders.length})`}</span>
          {orders.some((o) => o.status === 'processing') && (
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping absolute -top-0.5 -right-0.5" />
          )}
        </button>

        <button
          onClick={() => setActiveAdminSubTab('users')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'users'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>{isBn ? `রেজিস্টার্ড ইউজার (${registeredUsers.length})` : `Users (${registeredUsers.length})`}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('banners')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'banners'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span>{isBn ? `ব্যানার ছবি এড (${banners.length})` : `Banners (${banners.length})`}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('categories')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'categories'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <LayoutGrid className="w-3.5 h-3.5" />
          <span>{isBn ? 'ক্যাটাগরি এড ও ম্যানেজ' : 'Categories'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('products')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'products'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>{isBn ? 'পণ্যসমূহ এডিট ও ডিলেট' : 'Edit Products'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('add_stock')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'add_stock'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5" />
          <span>{isBn ? 'নতুন প্রোডাক্ট এড / স্টক' : 'Add Product'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('payments')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'payments'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Phone className="w-3.5 h-3.5" />
          <span>{isBn ? 'বিকাশ / নগদ নম্বর' : 'Payment Numbers'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('notice')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'notice'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Megaphone className="w-3.5 h-3.5" />
          <span>{isBn ? 'সাইট নোটিশ টেক্সট' : 'Notice Ticker'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('balance')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'balance'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Wallet className="w-3.5 h-3.5" />
          <span>{isBn ? 'ব্যালেন্স ও ট্রানজ্যাকশন' : 'User Balance'}</span>
        </button>

        <button
          onClick={() => setActiveAdminSubTab('site_settings')}
          className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
            activeAdminSubTab === 'site_settings'
              ? 'bg-amber-500 text-slate-950 shadow-md'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>{isBn ? 'সাইট সেটিং ও এডিট (Edit Everything)' : 'Site Settings'}</span>
        </button>
      </div>

      {/* SUB-TAB 0: ORDERS MANAGEMENT & CONFIRMATIONS */}
      {activeAdminSubTab === 'orders' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-4 rounded-2xl">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-400" />
                <span>{isBn ? 'কাস্টমার অর্ডার ও কনফার্মেশন ম্যানেজমেন্ট' : 'Customer Orders & Confirmation'}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {isBn
                  ? 'ইউজারদের করা নতুন অর্ডার ম্যানুয়ালি ভেরিফাই করুন এবং কনফার্ম বা ক্যান্সেল করুন।'
                  : 'Manually review pending processing orders and mark them as confirmed (active) or cancelled.'}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-amber-400 bg-amber-950/80 px-3 py-1.5 rounded-xl border border-amber-500/30">
                {isBn
                  ? `অপেক্ষমান: ${orders.filter((o) => o.status === 'processing').length} টি`
                  : `Pending: ${orders.filter((o) => o.status === 'processing').length}`}
              </span>
              <span className="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-3 py-1.5 rounded-xl border border-emerald-500/30">
                {isBn
                  ? `কনফার্মকৃত: ${orders.filter((o) => o.status === 'active').length} টি`
                  : `Confirmed: ${orders.filter((o) => o.status === 'active').length}`}
              </span>
              {orders.some((o) => o.status === 'expired') && (
                <span className="text-xs font-bold text-rose-400 bg-rose-950/80 px-3 py-1.5 rounded-xl border border-rose-500/30">
                  {isBn
                    ? `বাতিলকৃত: ${orders.filter((o) => o.status === 'expired').length} টি`
                    : `Cancelled: ${orders.filter((o) => o.status === 'expired').length}`}
                </span>
              )}
              {orders.some((o) => o.status === 'expired') && (
                <button
                  type="button"
                  onClick={() => {
                    adminClearCancelledOrders();
                  }}
                  className="px-3 py-1.5 bg-rose-900 hover:bg-rose-800 border border-rose-500/70 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer active:scale-95 shadow-md shadow-rose-950/40"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-300" />
                  <span>{isBn ? `বাতিলকৃত অর্ডার মুছুন (${orders.filter((o) => o.status === 'expired').length})` : `Delete Cancelled (${orders.filter((o) => o.status === 'expired').length})`}</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  adminClearHistory();
                }}
                className="px-3 py-1.5 bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer active:scale-95"
              >
                <Trash2 className="w-3.5 h-3.5 text-slate-500" />
                <span>{isBn ? 'সব হিস্ট্রি ক্লিয়ার' : 'Clear All'}</span>
              </button>
            </div>
          </div>

          {/* Search & Status Filter Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-2">
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={orderSearchQuery}
                onChange={(e) => setOrderSearchQuery(e.target.value)}
                placeholder={isBn ? 'অর্ডার নম্বর, প্রডাক্ট, সাইটের নাম বা ইমেইল দিয়ে সার্চ করুন...' : 'Search order #, product, site or email...'}
                className="w-full pl-10 pr-3.5 py-2 text-xs bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
            <div className="flex items-center gap-1 shrink-0 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
              {[
                { id: 'all', labelBn: `সকল (${orders.length})`, labelEn: `All (${orders.length})` },
                { id: 'processing', labelBn: `অপেক্ষমান (${orders.filter((o) => o.status === 'processing').length})`, labelEn: `Pending (${orders.filter((o) => o.status === 'processing').length})` },
                { id: 'active', labelBn: `কনফার্মড (${orders.filter((o) => o.status === 'active').length})`, labelEn: `Confirmed (${orders.filter((o) => o.status === 'active').length})` },
                { id: 'expired', labelBn: `বাতিল (${orders.filter((o) => o.status === 'expired').length})`, labelEn: `Cancelled (${orders.filter((o) => o.status === 'expired').length})` }
              ].map((st) => (
                <button
                  key={st.id}
                  onClick={() => setOrderStatusFilter(st.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    orderStatusFilter === st.id
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {isBn ? st.labelBn : st.labelEn}
                </button>
              ))}
            </div>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
              <ShoppingBag className="w-8 h-8 mx-auto mb-2 text-slate-600" />
              <p>{isBn ? 'কোন অর্ডার পাওয়া যায়নি।' : 'No orders found matching filters.'}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredOrders.map((ord) => {
                const isProcessing = ord.status === 'processing';
                const isActive = ord.status === 'active';

                return (
                  <div
                    key={ord.id}
                    className={`bg-slate-900 border rounded-2xl p-4 transition-all ${
                      isProcessing
                        ? 'border-amber-500/50 shadow-lg shadow-amber-500/5'
                        : isActive
                        ? 'border-emerald-500/30'
                        : 'border-slate-800 opacity-75'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded text-xs border border-cyan-500/30">
                            #{ord.orderNumber || ord.id}
                          </span>
                          <span className="text-xs text-slate-400">
                            {ord.purchaseDate}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white mt-1">
                          {isBn ? ord.productTitleBn : ord.productTitleEn}
                        </h4>
                        <span className="text-xs text-emerald-400 font-semibold">
                          {isBn ? ord.variantNameBn : ord.variantNameEn}
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block">{isBn ? 'অর্ডার মূল্য:' : 'Price:'}</span>
                          <span className="text-base font-black text-emerald-400">৳ {ord.price}</span>
                        </div>

                        {/* Status Badge */}
                        {isProcessing && (
                          <span className="px-3 py-1 bg-amber-950/80 text-amber-400 border border-amber-500/40 rounded-full text-xs font-bold flex items-center gap-1.5 animate-pulse">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{isBn ? 'অপেক্ষমান (Processing)' : 'Processing'}</span>
                          </span>
                        )}
                        {isActive && (
                          <span className="px-3 py-1 bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 rounded-full text-xs font-bold flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{isBn ? 'কনফার্মকৃত (Active)' : 'Active'}</span>
                          </span>
                        )}
                        {!isProcessing && !isActive && (
                          <span className="px-3 py-1 bg-rose-950/80 text-rose-400 border border-rose-500/40 rounded-full text-xs font-bold flex items-center gap-1.5">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>{isBn ? 'বাতিলকৃত' : 'Cancelled'}</span>
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Customer Site Input Details & Customer Info */}
                    <div className="mt-3 bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-1.5 text-[11px]">
                        <span className="font-bold text-slate-300 flex items-center gap-1.5">
                          <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{isBn ? 'কাস্টমার প্রোফাইল:' : 'Customer Profile:'}</span>
                          <span className="text-white font-mono">{ord.userName || ord.userEmail || ord.userPhone || 'অর্ডারকারী'}</span>
                        </span>
                        {(ord.userEmail || ord.userPhone) && (
                          <span className="text-slate-400 font-mono text-[10px]">
                            {ord.userEmail && <span>{ord.userEmail}</span>}
                            {ord.userEmail && ord.userPhone && <span className="mx-1">|</span>}
                            {ord.userPhone && <span>{ord.userPhone}</span>}
                          </span>
                        )}
                      </div>

                      {(ord.siteName || ord.siteAdminEmail || ord.paymentMethod) && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-1 font-mono text-[11px]">
                          {ord.siteName && (
                            <div>
                              <span className="text-slate-500 block text-[10px]">{isBn ? 'সাইটের নাম:' : 'Site Name:'}</span>
                              <span className="text-white font-bold">{ord.siteName}</span>
                            </div>
                          )}
                          {ord.sitePhone && (
                            <div>
                              <span className="text-slate-500 block text-[10px]">{isBn ? 'মোবাইল:' : 'Phone:'}</span>
                              <span className="text-white font-bold">{ord.sitePhone}</span>
                            </div>
                          )}
                          {ord.siteAdminEmail && (
                            <div>
                              <span className="text-slate-500 block text-[10px]">{isBn ? 'এডমিন ইমেইল:' : 'Admin Email:'}</span>
                              <span className="text-cyan-400 font-bold">{ord.siteAdminEmail}</span>
                            </div>
                          )}
                          {ord.siteAdminPassword && (
                            <div>
                              <span className="text-slate-500 block text-[10px]">{isBn ? 'এডমিন পাসওয়ার্ড:' : 'Admin Pass:'}</span>
                              <span className="text-emerald-400 font-bold">{ord.siteAdminPassword}</span>
                            </div>
                          )}
                          {ord.paymentMethod && (
                            <div>
                              <span className="text-slate-500 block text-[10px]">{isBn ? 'পেমেন্ট মাধ্যম:' : 'Payment:'}</span>
                              <span className="text-amber-400 font-bold uppercase">{ord.paymentMethod} {ord.paymentTrxId ? `(${ord.paymentTrxId})` : ''}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action Controls */}
                    <div className="mt-3 flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-slate-800/80">
                      {/* Confirm Order Button */}
                      {!isActive && (
                        <button
                          type="button"
                          onClick={() => {
                            adminUpdateOrderStatus(ord.id, 'active');
                            addToast(
                              isBn
                                ? `অর্ডার #${ord.orderNumber || ord.id} সফলভাবে কনফার্ম করা হয়েছে!`
                                : `Order #${ord.orderNumber || ord.id} confirmed!`,
                              'success'
                            );
                          }}
                          className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition flex items-center gap-1.5 cursor-pointer active:scale-95"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>{isBn ? 'অর্ডার কনফার্ম করুন (Confirm)' : 'Confirm Order'}</span>
                        </button>
                      )}

                      {/* Move to Pending/Processing */}
                      {!isProcessing && (
                        <button
                          type="button"
                          onClick={() => {
                            adminUpdateOrderStatus(ord.id, 'processing');
                            addToast(
                              isBn ? `অর্ডার #${ord.orderNumber || ord.id} অপেক্ষমান তালিকাভুক্ত করা হলো` : `Order set to pending`,
                              'info'
                            );
                          }}
                          className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold rounded-xl transition flex items-center gap-1 cursor-pointer"
                        >
                          <Clock className="w-3.5 h-3.5" />
                          <span>{isBn ? 'পেন্ডিং করুন' : 'Set Pending'}</span>
                        </button>
                      )}

                      {/* Cancel Button */}
                      {ord.status !== 'expired' && (
                        <button
                          type="button"
                          onClick={() => {
                            adminUpdateOrderStatus(ord.id, 'expired');
                            addToast(
                              isBn ? `অর্ডার #${ord.orderNumber || ord.id} বাতিল করা হয়েছে` : `Order cancelled successfully`,
                              'info'
                            );
                          }}
                          className="px-3 py-1.5 bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-600/60 font-bold text-xs rounded-xl transition flex items-center gap-1 cursor-pointer active:scale-95"
                        >
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                          <span>{isBn ? 'অর্ডার বাতিল করুন' : 'Cancel Order'}</span>
                        </button>
                      )}

                      {/* If order is already cancelled/expired, show direct prominent Delete button */}
                      {ord.status === 'expired' && (
                        <button
                          type="button"
                          onClick={() => {
                            adminDeleteOrder(ord.id);
                          }}
                          className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs rounded-xl transition flex items-center gap-1.5 shadow-md shadow-rose-950/40 cursor-pointer active:scale-95"
                        >
                          <Trash2 className="w-3.5 h-3.5 stroke-[2.5]" />
                          <span>{isBn ? 'স্থায়ীভাবে ডিলিট করুন' : 'Delete Permanently'}</span>
                        </button>
                      )}

                      {/* Delete Order from list */}
                      {ord.status !== 'expired' && (
                        <button
                          type="button"
                          onClick={() => {
                            adminDeleteOrder(ord.id);
                          }}
                          className="px-2.5 py-1.5 bg-slate-950 hover:bg-rose-950 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-800 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ml-auto"
                          title={isBn ? 'ডিলিট করুন' : 'Delete'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 0: REGISTERED USERS MANAGEMENT */}
      {activeAdminSubTab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-4 rounded-2xl">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-cyan-400" />
                <span>{isBn ? 'রেজিস্টার্ড ইউজার তালিকা' : 'Registered Users Directory'}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {isBn ? 'ওয়েবসাইটে মোট রেজিস্টার্ড ইউজারের নাম, জিমেইল, মোবাইল ও পাসওয়ার্ড তথ্য' : 'List of all registered user emails, phones & passwords'}
              </p>
            </div>
            <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-slate-300">
              <span className="text-slate-400">{isBn ? 'মোট ইউজার:' : 'Total Users:'}</span>
              <span className="font-black text-cyan-400 text-sm">{registeredUsers.length}</span>
            </div>
          </div>

          {/* Search Filter */}
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={userSearchQuery}
              onChange={(e) => setUserSearchQuery(e.target.value)}
              placeholder={isBn ? 'ইউজার নাম, মোবাইল বা জিমেইল দিয়ে ফিল্টার করুন...' : 'Filter by name, phone or email...'}
              className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          {/* User Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredUsers.map((u) => (
              <div
                key={u.id}
                className={`bg-slate-900/90 border p-4 rounded-2xl space-y-2.5 shadow-md transition ${
                  u.isBlocked ? 'border-rose-800/80 bg-rose-950/10' : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-400 font-black flex items-center justify-center text-xs shadow">
                      {u.name.slice(0, 1).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-white">{u.name}</h4>
                        {u.isBlocked ? (
                          <span className="px-2 py-0.5 bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-black rounded-lg flex items-center gap-1">
                            <Ban className="w-3 h-3 text-rose-400" />
                            {isBn ? 'ব্লকড' : 'Blocked'}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 text-[10px] font-bold rounded-lg flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3" />
                            {isBn ? 'এক্টিভ' : 'Active'}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400">{u.registeredAt}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-lg border border-emerald-800/40">
                      ৳ {u.walletBalance}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-1.5 text-xs">
                  <div className="flex items-center justify-between bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-800/80">
                    <span className="text-slate-400 text-[11px] flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-cyan-400" />
                      {isBn ? 'জিমেইল / ইমেইল:' : 'Gmail / Email:'}
                    </span>
                    <span className="font-bold text-cyan-300 font-mono text-[11px] select-all">{u.email}</span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-800/80">
                    <span className="text-slate-400 text-[11px] flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-amber-400" />
                      {isBn ? 'মোবাইল নম্বর:' : 'Phone:'}
                    </span>
                    <span className="font-bold text-amber-300 font-mono text-[11px] select-all">{u.phone}</span>
                  </div>

                  <div className="flex items-center justify-between bg-slate-950/70 px-2.5 py-1.5 rounded-lg border border-slate-800/80">
                    <span className="text-slate-400 text-[11px] flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-pink-400" />
                      {isBn ? 'পাসওয়ার্ড:' : 'Password:'}
                    </span>
                    <span className="font-bold text-pink-300 font-mono text-[11px] select-all">{u.password}</span>
                  </div>
                </div>

                {/* User Control Action Buttons */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 gap-2">
                  <button
                    onClick={() => setQuickCreditUser(u)}
                    className="px-2.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-[11px] rounded-xl shadow transition flex items-center gap-1 cursor-pointer active:scale-95"
                    title="Add Money To User Balance"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>{isBn ? 'টাকা যোগ করুন' : 'Add Money'}</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {u.isBlocked ? (
                      <button
                        onClick={() => adminToggleBlockUser(u.id)}
                        className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] rounded-xl transition flex items-center gap-1 cursor-pointer active:scale-95 shadow"
                        title="Unblock User"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>{isBn ? 'আনব্লক করুন' : 'Unblock'}</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => adminToggleBlockUser(u.id)}
                        className="px-2.5 py-1.5 bg-rose-950 hover:bg-rose-900 border border-rose-700/80 text-rose-300 font-bold text-[11px] rounded-xl transition flex items-center gap-1 cursor-pointer active:scale-95 shadow"
                        title="Block User"
                      >
                        <Ban className="w-3.5 h-3.5 text-rose-400" />
                        <span>{isBn ? 'ইউজার ব্লক করুন' : 'Block User'}</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        adminDeleteUser(u.id);
                      }}
                      className="p-1.5 bg-slate-950 hover:bg-rose-950 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-800 rounded-xl transition cursor-pointer"
                      title={isBn ? 'ইউজার ডিলিট করুন' : 'Delete User'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 0.25: BANNER MANAGEMENT */}
      {activeAdminSubTab === 'banners' && (
        <div className="space-y-4">
          {/* Add Banner Form */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-4 shadow-md">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-amber-400" />
                  <span>{isBn ? 'নতুন ব্যানার ছবি আপলোড ও যুক্ত করুন' : 'Upload & Add New Banner'}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isBn
                    ? 'গ্যালারি/মোবাইল থেকে সরাসরি ছবি আপলোড করুন অথবা পিকচারের লিঙ্ক ও কাস্টম অ্যাকশন লিঙ্ক দিন'
                    : 'Upload image directly from device or paste image URL with optional action link'}
                </p>
              </div>
              <span className="text-xs font-mono font-bold bg-amber-500/20 text-amber-300 px-2.5 py-1 rounded-lg border border-amber-500/30">
                {banners.length} {isBn ? 'টি ব্যানার রয়েছে' : 'Active Banners'}
              </span>
            </div>

            <form onSubmit={handleBannerSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Device Upload */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-dashed border-slate-700 hover:border-amber-500/60 transition text-center flex flex-col items-center justify-center space-y-2">
                  <Upload className="w-6 h-6 text-amber-400" />
                  <span className="text-xs font-bold text-slate-300">
                    {isBn ? 'ডিভাইস থেকে ছবি আপলোড করুন' : 'Upload Image File'}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleBannerFileUpload}
                    className="text-[11px] text-slate-400 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-amber-500 file:text-slate-950 cursor-pointer"
                  />
                </div>

                {/* Direct Image URL Input */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                  <label className="text-xs font-bold text-slate-300 block">
                    {isBn ? 'অথবা ব্যানার ছবির লিঙ্ক (Image URL):' : 'Or Image URL:'}
                  </label>
                  <input
                    type="url"
                    value={bannerUrlInput}
                    onChange={(e) => setBannerUrlInput(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  {isBn ? 'ব্যানারের অফার শিরোনাম / ক্যাপশন (ঐচ্ছিক):' : 'Banner Title / Offer Caption (Optional):'}
                </label>
                <input
                  type="text"
                  value={bannerTitleInput}
                  onChange={(e) => setBannerTitleInput(e.target.value)}
                  placeholder="e.g. ৫০% ছাড় পাবেন! সকল প্রোডাক্টের উপর | প্রোমো কোড: 50-EID-2026"
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              {/* Banner Action Link Input (Video Link, Telegram Link, etc.) */}
              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/90 space-y-2">
                <label className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5" />
                  <span>{isBn ? 'ব্যানার অ্যাকশন / টার্গেট লিংক (ভিডিও / টেলিগ্রাম / ওয়েবসাইট):' : 'Banner Action / Target Link (Video / Telegram / URL):'}</span>
                </label>
                <input
                  type="text"
                  value={bannerLinkInput}
                  onChange={(e) => setBannerLinkInput(e.target.value)}
                  placeholder="e.g. https://t.me/codebazar_official অথবা https://youtube.com/watch?v=..."
                  className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                />

                {/* Quick Presets */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-400 font-semibold">{isBn ? 'কুইক লিংক প্রিসেট:' : 'Quick Presets:'}</span>
                  <button
                    type="button"
                    onClick={() => setBannerLinkInput(siteConfig.telegramLink || 'https://t.me/codebazar_official')}
                    className="px-2.5 py-1 rounded-lg bg-sky-950/80 hover:bg-sky-900 border border-sky-700/60 text-sky-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    <Send className="w-3 h-3" />
                    <span>{isBn ? 'টেলিগ্রাম চ্যানেল' : 'Telegram'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setBannerLinkInput('https://youtube.com')}
                    className="px-2.5 py-1 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-700/60 text-rose-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    <Play className="w-3 h-3" />
                    <span>{isBn ? 'ইউটিউব ভিডিও' : 'YouTube Video'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const num = (siteConfig.whatsappNumber || '01836828065').replace(/\D/g, '');
                      setBannerLinkInput(`https://wa.me/${num.startsWith('88') ? num : '88' + num}`);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    <MessageCircle className="w-3 h-3" />
                    <span>{isBn ? 'হোয়াটসঅ্যাপ' : 'WhatsApp'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  {isBn
                    ? '💡 ব্যানারে আপনার ইচ্ছামতো যে কোনো ইউটিউব ভিডিও লিংক, টেলিগ্রাম চ্যানেল/গ্রুপের লিংক বা অফার পেজের লিংক বসাতে পারেন। ইউজাররা স্লাইডারে ক্লিক করলেই এই লিংকে চলে যাবে।'
                    : '💡 Add any YouTube video link, Telegram channel link, or custom URL. Visitors clicking the banner will open this link directly.'}
                </p>
              </div>

              {/* Image Preview if provided */}
              {bannerUrlInput && (
                <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold block">ব্যানার প্রিভিউ:</span>
                  <div className="h-32 rounded-lg overflow-hidden border border-slate-800 relative group/prev">
                    <img src={bannerUrlInput} alt="Banner preview" className="w-full h-full object-cover" />
                    {bannerLinkInput && (
                      <div className="absolute top-2 right-2 bg-slate-950/90 border border-amber-400/50 text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-full shadow flex items-center gap-1">
                        <LinkIcon className="w-3 h-3" />
                        <span className="truncate max-w-[150px]">{bannerLinkInput}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={!bannerUrlInput.trim()}
                className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-black text-xs rounded-xl shadow-lg cursor-pointer transition flex items-center justify-center gap-1.5 active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'ব্যানার যুক্ত করুন' : 'Add Banner'}</span>
              </button>
            </form>
          </div>

          {/* Active Banners List */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider">
              {isBn ? 'বর্তমান একটিভ ব্যানারসমূহ' : 'Active Banners'}
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {banners.map((b) => (
                <div key={b.id} className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-md space-y-2.5 p-3">
                  <div className="relative h-36 rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
                    <img src={b.imageUrl} alt={b.title} className="w-full h-full object-cover" />
                    <div className="absolute top-2 right-2 flex items-center gap-1.5">
                      <button
                        onClick={() => handleOpenEditBanner(b)}
                        className="bg-cyan-600 hover:bg-cyan-500 text-white p-1.5 rounded-xl shadow-lg transition active:scale-90 cursor-pointer flex items-center gap-1 text-[11px] font-bold"
                        title={isBn ? 'সম্পাদনা করুন' : 'Edit Banner'}
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>{isBn ? 'এডিট' : 'Edit'}</span>
                      </button>
                      <button
                        onClick={() => adminDeleteBanner(b.id)}
                        className="bg-rose-600 hover:bg-rose-500 text-white p-1.5 rounded-xl shadow-lg transition active:scale-90 cursor-pointer flex items-center gap-1 text-[11px] font-bold"
                        title={isBn ? 'ডিলিট করুন' : 'Delete Banner'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>{isBn ? 'ডিলিট' : 'Delete'}</span>
                      </button>
                    </div>
                  </div>
                  <div className="px-1 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-bold text-white line-clamp-1">{b.title || 'Code Bazar Banner'}</p>
                      <span className="text-[10px] text-slate-400 font-mono shrink-0">ID: {b.id}</span>
                    </div>

                    {/* Banner Link Display */}
                    {b.linkUrl ? (
                      <div className="flex items-center justify-between gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 text-[11px]">
                        <div className="flex items-center gap-1.5 text-slate-300 truncate">
                          <LinkIcon className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span className="truncate font-mono text-[10px] text-amber-300/90">{b.linkUrl}</span>
                        </div>
                        <a
                          href={b.linkUrl.startsWith('http') ? b.linkUrl : `https://${b.linkUrl}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2 py-0.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-[10px] font-bold flex items-center gap-1 shrink-0 transition"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span>{isBn ? 'টেস্ট' : 'Test'}</span>
                        </a>
                      </div>
                    ) : (
                      <div className="bg-slate-950/60 px-2.5 py-1 rounded-lg border border-dashed border-slate-800 text-[10px] text-slate-500 flex items-center justify-between">
                        <span>{isBn ? 'কোনো লিংক যুক্ত নেই (শুধুমাত্র ছবি)' : 'No link attached'}</span>
                        <button
                          onClick={() => handleOpenEditBanner(b)}
                          className="text-amber-400 hover:underline font-bold"
                        >
                          {isBn ? '+ লিংক দিন' : '+ Add Link'}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 0.5: CATEGORY MANAGEMENT */}
      {activeAdminSubTab === 'categories' && (
        <div className="space-y-4">
          {/* Add Category Form */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-3 shadow-md">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <LayoutGrid className="w-4 h-4 text-cyan-400" />
              <span>{isBn ? 'নতুন ক্যাটাগরি তৈরি করুন' : 'Add New Category'}</span>
            </h3>
            
            <form onSubmit={handleAddCategorySubmit} className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">বাংলা ক্যাটাগরি নাম:</label>
                <input
                  type="text"
                  value={catNameBn}
                  onChange={(e) => setCatNameBn(e.target.value)}
                  placeholder="e.g. ক্যাসিনো ও বেটিং সাইট"
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">English Category Name:</label>
                <input
                  type="text"
                  value={catNameEn}
                  onChange={(e) => setCatNameEn(e.target.value)}
                  placeholder="e.g. Casino & Betting Sites"
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  required
                />
              </div>
              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs rounded-xl shadow cursor-pointer transition flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isBn ? 'ক্যাটাগরি যুক্ত করুন' : 'Add Category'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Categories List with Edit & Delete */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
              {isBn ? `সকল ক্যাটাগরি (${categories.length} টি)` : `All Categories (${categories.length})`}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {categories.map((c) => (
                <div key={c.id} className="bg-slate-900/90 border border-slate-800 p-3.5 rounded-2xl flex items-center justify-between shadow-sm hover:border-slate-700 transition">
                  <div className="min-w-0 flex-1 pr-2">
                    <h4 className="text-xs font-bold text-white truncate">{c.nameBn}</h4>
                    <p className="text-[10px] text-slate-400 truncate">{c.nameEn}</p>
                    <span className="inline-block mt-1 text-[9px] font-mono bg-cyan-950 text-cyan-400 px-1.5 py-0.5 rounded border border-cyan-800/40">
                      ID: {c.id}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => {
                        setEditingCategory({ ...c });
                        setEditingCategoryOriginalId(c.id);
                      }}
                      className="p-2 rounded-xl bg-blue-950/80 hover:bg-blue-900 border border-blue-700/50 text-blue-300 transition active:scale-95 cursor-pointer"
                      title={isBn ? 'সম্পাদনা করুন' : 'Edit Category'}
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    {c.id !== 'all' ? (
                      deletingCatId === c.id ? (
                        <div className="flex items-center gap-1 bg-rose-950 border border-rose-800 p-1 rounded-xl">
                          <button
                            onClick={() => {
                              adminDeleteCategory(c.id);
                              setDeletingCatId(null);
                            }}
                            className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold rounded-lg transition"
                          >
                            {isBn ? 'হ্যাঁ' : 'Yes'}
                          </button>
                          <button
                            onClick={() => setDeletingCatId(null)}
                            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold rounded-lg transition"
                          >
                            {isBn ? 'না' : 'No'}
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeletingCatId(c.id)}
                          className="p-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 border border-rose-700/50 text-rose-300 transition active:scale-95 cursor-pointer"
                          title={isBn ? 'ক্যাটাগরি মুছুন' : 'Delete Category'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )
                    ) : (
                      <span className="text-[10px] text-slate-500 font-bold px-1.5 py-1 bg-slate-950 rounded-lg border border-slate-800">
                        {isBn ? 'ডিফল্ট' : 'Default'}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 1: PRODUCTS LIST & EDIT */}
      {activeAdminSubTab === 'products' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Tag className="w-4 h-4 text-cyan-400" />
              <span>{isBn ? 'সকল স্টোর পণ্য (সম্পাদনা করুন)' : 'All Store Products (Edit & Manage)'}</span>
            </h3>
            <span className="text-xs text-slate-400">Total: {products.length} Products</span>
          </div>

          {/* Search & Category Filter */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <div className="relative sm:col-span-2">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={productSearchQuery}
                onChange={(e) => setProductSearchQuery(e.target.value)}
                placeholder={isBn ? 'প্রোডাক্টের নাম বা আইডি দিয়ে ফিল্টার করুন...' : 'Search by product title or ID...'}
                className="w-full pl-10 pr-3.5 py-2 text-xs bg-slate-900 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
              />
            </div>
            <select
              value={productCategoryFilter}
              onChange={(e) => setProductCategoryFilter(e.target.value)}
              className="px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
            >
              <option value="all">{isBn ? 'সকল ক্যাটাগরি' : 'All Categories'}</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {isBn ? c.nameBn : c.nameEn}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredProducts.map((p) => (
              <div
                key={p.id}
                className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 p-3.5 rounded-2xl flex items-center gap-3 transition"
              >
                <img
                  src={p.imageUrl}
                  alt={p.titleBn}
                  className="w-16 h-16 rounded-xl object-cover border border-slate-700/60 flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider block mb-0.5">
                    {p.categoryId.replace('_', ' ')}
                  </span>
                  <h4 className="text-xs font-bold text-white truncate">{isBn ? p.titleBn : p.titleEn}</h4>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">{isBn ? p.shortDescBn : p.shortDescEn}</p>
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span className="text-xs font-black text-amber-400">
                      ৳{p.variants[0]?.price || 0}
                    </span>
                    <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800/60 px-2 py-0.5 rounded-full font-bold">
                      Sold: {p.soldCount}
                    </span>
                    {p.demoUrl ? (
                      <a
                        href={p.demoUrl.startsWith('http') ? p.demoUrl : `https://${p.demoUrl}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[10px] bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800/60 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 transition"
                        title={p.demoUrl}
                      >
                        <Globe className="w-3 h-3 text-cyan-400" />
                        <span>Demo Link</span>
                      </a>
                    ) : (
                      <span className="text-[10px] bg-slate-950 text-slate-500 border border-slate-800 px-2 py-0.5 rounded-full font-semibold">
                        No Demo
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 flex-shrink-0">
                  <button
                    onClick={() => setEditingProduct(p)}
                    className="p-2 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-800/80 text-cyan-300 text-xs font-bold flex items-center justify-center transition"
                    title="Edit Product"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  {deletingProdId === p.id ? (
                    <div className="flex flex-col gap-1 bg-rose-950 border border-rose-800 p-1 rounded-xl">
                      <span className="text-[9px] text-rose-300 font-bold text-center">{isBn ? 'মুছবেন?' : 'Delete?'}</span>
                      <button
                        onClick={() => {
                          adminDeleteProduct(p.id);
                          setDeletingProdId(null);
                        }}
                        className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold rounded-lg transition"
                      >
                        {isBn ? 'হ্যাঁ' : 'Yes'}
                      </button>
                      <button
                        onClick={() => setDeletingProdId(null)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold rounded-lg transition"
                      >
                        {isBn ? 'না' : 'No'}
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setDeletingProdId(p.id)}
                      className="p-2 rounded-xl bg-rose-950 hover:bg-rose-900 border border-rose-800/80 text-rose-300 text-xs font-bold flex items-center justify-center transition"
                      title="Delete Product"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: PAYMENT NUMBERS */}
      {activeAdminSubTab === 'payments' && (
        <div className="bg-slate-900/90 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-4 max-w-xl">
          <div className="flex items-center gap-2">
            <Phone className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-white">
              {isBn ? 'বিকাশ ও নগদ গেটওয়ে নম্বর, লোগো ও অন/অফ সেটআপ' : 'Edit bKash & Nagad Numbers, Logos & Status'}
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            {isBn
              ? 'এখানে দেয়া নম্বর ও লোগো ডিপোজিট ও কেনাকাটার সময় সরাসরি ইউজারের সামনে প্রদর্শিত হবে।'
              : 'These send-money personal numbers and custom logos will be shown in user top-up modals.'}
          </p>

          <form onSubmit={handleSavePaymentNumbers} className="space-y-4 pt-2">
            {/* bKash Number & Logo */}
            <div className="p-3.5 bg-slate-950 border border-pink-500/30 rounded-2xl space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-pink-400 block">bKash Personal Number (বিকাশ পার্সোনাল নম্বর):</label>
                <button
                  type="button"
                  onClick={() => setPayBkashEnabled(!payBkashEnabled)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1.5 transition border cursor-pointer ${
                    payBkashEnabled
                      ? 'bg-emerald-950/80 text-emerald-400 border-emerald-500/50 hover:bg-emerald-900'
                      : 'bg-rose-950/80 text-rose-400 border-rose-500/50 hover:bg-rose-900'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${payBkashEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
                  <span>{payBkashEnabled ? (isBn ? 'সক্রিয় (ON)' : 'ENABLED') : (isBn ? 'নিষ্ক্রিয় (OFF)' : 'DISABLED')}</span>
                </button>
              </div>
              <input
                type="text"
                value={payBkash}
                onChange={(e) => setPayBkash(e.target.value)}
                placeholder="018XXXXXXXX"
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-pink-500"
              />

              <label className="text-[11px] font-bold text-pink-300 block pt-1">bKash Logo (বিকাশ লোগো ছবি / ইউআরএল):</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={payBkashLogo}
                  onChange={(e) => setPayBkashLogo(e.target.value)}
                  placeholder="Paste bKash logo image URL or choose file"
                  className="flex-1 px-3 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-pink-500"
                />
                <label className="px-3 py-1.5 bg-pink-950 hover:bg-pink-900 border border-pink-700/60 text-pink-300 rounded-xl cursor-pointer text-xs font-bold shrink-0 flex items-center gap-1">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isBn ? 'ফাইল আপলোড' : 'Upload'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleLogoCompress(file, setPayBkashLogo);
                    }}
                    className="hidden"
                  />
                </label>
              </div>
              {payBkashLogo && (
                <div className="mt-1 flex items-center justify-between p-2 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="flex items-center gap-2">
                    <img src={payBkashLogo} alt="bKash Logo Preview" className="h-7 object-contain rounded bg-white p-0.5 border border-pink-300/40" />
                    <span className="text-[11px] text-emerald-400 font-bold">bKash Logo Ready ✓</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPayBkashLogo('')}
                    className="p-1 bg-rose-950/80 hover:bg-rose-900 text-rose-300 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Nagad Number & Logo */}
            <div className="p-3.5 bg-slate-950 border border-orange-500/30 rounded-2xl space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-orange-400 block">Nagad Personal Number (নগদ পার্সোনাল নম্বর):</label>
                <button
                  type="button"
                  onClick={() => setPayNagadEnabled(!payNagadEnabled)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1.5 transition border cursor-pointer ${
                    payNagadEnabled
                      ? 'bg-emerald-950/80 text-emerald-400 border-emerald-500/50 hover:bg-emerald-900'
                      : 'bg-rose-950/80 text-rose-400 border-rose-500/50 hover:bg-rose-900'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${payNagadEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`} />
                  <span>{payNagadEnabled ? (isBn ? 'সক্রিয় (ON)' : 'ENABLED') : (isBn ? 'নিষ্ক্রিয় (OFF)' : 'DISABLED')}</span>
                </button>
              </div>
              <input
                type="text"
                value={payNagad}
                onChange={(e) => setPayNagad(e.target.value)}
                placeholder="018XXXXXXXX"
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-orange-500"
              />

              <label className="text-[11px] font-bold text-orange-300 block pt-1">Nagad Logo (নগদ লোগো ছবি / ইউআরএল):</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={payNagadLogo}
                  onChange={(e) => setPayNagadLogo(e.target.value)}
                  placeholder="Paste Nagad logo image URL or choose file"
                  className="flex-1 px-3 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
                <label className="px-3 py-1.5 bg-orange-950 hover:bg-orange-900 border border-orange-700/60 text-orange-300 rounded-xl cursor-pointer text-xs font-bold shrink-0 flex items-center gap-1">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isBn ? 'ফাইল আপলোড' : 'Upload'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleLogoCompress(file, setPayNagadLogo);
                    }}
                    className="hidden"
                  />
                </label>
              </div>
              {payNagadLogo && (
                <div className="mt-1 flex items-center justify-between p-2 bg-slate-900 border border-slate-800 rounded-xl">
                  <div className="flex items-center gap-2">
                    <img src={payNagadLogo} alt="Nagad Logo Preview" className="h-7 object-contain rounded bg-white p-0.5 border border-orange-300/40" />
                    <span className="text-[11px] text-emerald-400 font-bold">Nagad Logo Ready ✓</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPayNagadLogo('')}
                    className="p-1 bg-rose-950/80 hover:bg-rose-900 text-rose-300 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Quick Deposit Preset Amounts Selector */}
            <div className="p-3.5 bg-slate-950 border border-blue-500/30 rounded-2xl space-y-2.5">
              <label className="text-xs font-bold text-blue-400 block">
                {isBn ? 'কুইক ডিপোজিট / টাকা এড কাস্টম বাটনসমূহ (Deposit Amounts):' : 'Quick Deposit Preset Amounts:'}
              </label>
              <input
                type="text"
                value={payQuickAmounts}
                onChange={(e) => setPayQuickAmounts(e.target.value)}
                placeholder="100, 300, 500, 1000, 2000, 5000"
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <p className="text-[11px] text-slate-400 leading-relaxed">
                💡 {isBn
                  ? 'কমা (,) দিয়ে আলাদা করে আপনার পছন্দমতো যেকোনো টাকা এড করার অ্যামাউন্ট লিখুন (যেমন: 100, 200, 500, 1000, 2000, 5000)। ইউজারের ডিপোজিট পেমেন্ট মোডালে এই অ্যামাউন্টের বাটনগুলো সরাসরি চলে আসবে।'
                  : 'Separate deposit amounts with commas (e.g. 100, 200, 500, 1000, 2000, 5000). These will be displayed as quick buttons on the user deposit modal.'}
              </p>
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[10px] text-slate-500 font-bold block">{isBn ? 'বাটন প্রিভিউ:' : 'Button Preview:'}</span>
                {payQuickAmounts.split(',').map(s => s.trim()).filter(Boolean).map((amt, idx) => (
                  <span key={idx} className="px-2.5 py-0.5 bg-blue-950 border border-blue-700/60 text-blue-300 font-mono font-bold text-[11px] rounded-lg">
                    ৳{amt}
                  </span>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition cursor-pointer active:scale-95"
            >
              <Save className="w-4 h-4 text-slate-950 stroke-[2.5]" />
              <span>{isBn ? 'নম্বর ও লোগো তথ্য সংরক্ষণ করুন' : 'Save Payment Info & Logos'}</span>
            </button>
          </form>
        </div>
      )}

      {/* SUB-TAB 3: NOTICE TICKER */}
      {activeAdminSubTab === 'notice' && (
        <div className="bg-slate-900/90 border border-slate-800 p-4 sm:p-5 rounded-2xl space-y-4 max-w-xl">
          <div className="flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-white">
              {isBn ? 'হেডার নোটিশ ব্যানার এডিটর' : 'Edit Announcement Ticker'}
            </h3>
          </div>

          <form onSubmit={handleSaveNotice} className="space-y-3.5 pt-2">
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">বাংলা নোটিশ টেক্সট:</label>
              <textarea
                rows={3}
                value={noticeBn}
                onChange={(e) => setNoticeBn(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-1">English Notice Text:</label>
              <textarea
                rows={3}
                value={noticeEn}
                onChange={(e) => setNoticeEn(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition"
            >
              <Save className="w-4 h-4" />
              <span>{isBn ? 'নোটিশ আপডেট করুন' : 'Update Notice Ticker'}</span>
            </button>
          </form>
        </div>
      )}

      {/* SUB-TAB 4: BALANCE & TRANSACTIONS */}
      {activeAdminSubTab === 'balance' && (
        <div className="space-y-5">
          {/* Manual User Balance Top-up */}
          <div className="bg-slate-900/90 border border-emerald-500/30 p-4 sm:p-5 rounded-2xl space-y-3.5 shadow-lg shadow-emerald-500/5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <PlusCircle className="w-4 h-4 text-emerald-400" />
                  <span>{isBn ? 'ম্যানুয়ালি ইউজারের ওয়ালেটে টাকা যোগ করুন' : 'Manual Credit / Add Balance to User'}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isBn
                    ? 'কোন কাস্টমার ডিপোজিট করলে কিন্তু একাউন্টে টাকা যোগ না হলে এখান থেকে সরাসরি তার একাউন্টে টাকা এড করে দিন।'
                    : 'If a user deposited money but balance was not updated, manually credit their account here.'}
                </p>
              </div>
            </div>

            <form onSubmit={handleManualCreditUser} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'ইউজার সিলেক্ট করুন:' : 'Select User:'}
                  </label>
                  <select
                    value={targetUserIdForCredit}
                    onChange={(e) => setTargetUserIdForCredit(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="current">
                      {isBn ? 'বর্তমান একাউন্ট' : 'Current Account'} ({user.name} - ৳{user.walletBalance})
                    </option>
                    {registeredUsers.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} - {u.phone} (৳{u.walletBalance})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'টাকার পরিমাণ (BDT):' : 'Amount (BDT):'}
                  </label>
                  <input
                    type="number"
                    value={creditAmountInput}
                    onChange={(e) => setCreditAmountInput(e.target.value)}
                    placeholder="e.g. 500"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              {/* Quick Presets */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] text-slate-400 font-semibold">{isBn ? 'কুইক এম্যাউন্ট:' : 'Quick Amount:'}</span>
                {[100, 200, 500, 1000, 2000, 5000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setCreditAmountInput(amt.toString())}
                    className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 text-emerald-400 font-bold text-xs rounded-lg border border-emerald-500/30 transition cursor-pointer"
                  >
                    +৳{amt}
                  </button>
                ))}
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition cursor-pointer active:scale-98"
              >
                <PlusCircle className="w-4 h-4" />
                <span>{isBn ? 'একাউন্টে টাকা এড করুন (Credit Balance)' : 'Credit User Balance'}</span>
              </button>
            </form>
          </div>

          {/* Direct balance edit */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl max-w-md space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Wallet className="w-4 h-4 text-cyan-400" />
              <span>{isBn ? 'অ্যাডমিন ওয়ালেট ব্যালেন্স পরিবর্তন করুন' : 'Change Admin Wallet Balance'}</span>
            </h3>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={userBalanceInput}
                onChange={(e) => setUserBalanceInput(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                placeholder="Amount BDT"
              />
              <button
                onClick={handleSaveUserBalance}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs rounded-xl flex-shrink-0"
              >
                {isBn ? 'সেট করুন' : 'Set Balance'}
              </button>
            </div>
          </div>

          {/* Deposit approvals */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>{isBn ? 'ওয়ালেট ডিপোজিট রিকোয়েস্ট তালিকা' : 'Deposit TrxID Requests'}</span>
              </h3>
              <div className="flex items-center gap-2">
                {transactions.some((t) => t.type === 'deposit' && t.status === 'rejected') && (
                  <button
                    type="button"
                    onClick={() => {
                      adminClearRejectedTransactions();
                    }}
                    className="px-3 py-1 bg-rose-900 hover:bg-rose-800 border border-rose-600/70 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer active:scale-95 shadow-md"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-300" />
                    <span>{isBn ? 'বাতিল ডিপোজিট মুছুন' : 'Clear Rejected'}</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    adminClearHistory();
                  }}
                  className="px-3 py-1 bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-400 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5 text-slate-500" />
                  <span>{isBn ? 'হিস্ট্রি ক্লিয়ার' : 'Clear All'}</span>
                </button>
              </div>
            </div>

            <div className="space-y-2.5">
              {transactions.filter((t) => t.type === 'deposit').length === 0 ? (
                <p className="text-xs text-slate-500 italic p-4 text-center bg-slate-950 rounded-xl border border-slate-800/80">
                  {isBn ? 'কোনো ডিপোজিট রিকোয়েস্ট পাওয়া যায়নি।' : 'No deposit requests found.'}
                </p>
              ) : (
                transactions
                  .filter((t) => t.type === 'deposit')
                  .map((tx) => (
                    <div
                      key={tx.id}
                      className="bg-slate-950 border border-slate-800/90 p-3.5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-md"
                    >
                      <div className="space-y-1">
                        <div className="font-bold text-white flex items-center gap-2 flex-wrap">
                          <span className={`uppercase px-2 py-0.5 rounded-lg text-[10px] font-black border ${
                            tx.method === 'bkash' ? 'bg-pink-950/80 text-pink-300 border-pink-700/50' : 'bg-orange-950/80 text-orange-300 border-orange-700/50'
                          }`}>
                            {tx.method}
                          </span>
                          <span className="text-emerald-400 font-mono font-black text-sm">৳{tx.amount} BDT</span>
                          <span className="text-[10px] text-slate-400 font-mono">({tx.date})</span>
                        </div>

                        {/* Customer Information & TrxID */}
                        <div className="text-[11px] text-slate-300 space-y-0.5 pt-0.5">
                          <div>
                            <span className="text-slate-500">{isBn ? 'কাস্টমার:' : 'User:'} </span>
                            <span className="font-bold text-slate-200">{tx.userName || tx.userEmail || tx.senderMobile || 'ইউজার'}</span>
                            {tx.userEmail && <span className="text-slate-400 font-mono text-[10px] ml-1">({tx.userEmail})</span>}
                          </div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span>
                              {isBn ? 'প্রেরক নম্বর:' : 'Sender:'} <span className="text-amber-300 font-mono font-bold">{tx.senderMobile}</span>
                            </span>
                            <span className="text-slate-600">|</span>
                            <span>
                              TrxID: <span className="text-cyan-300 font-mono font-black select-all bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">{tx.trxId}</span>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Admin Actions */}
                      <div className="flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80">
                        {tx.status === 'approved' ? (
                          <span className="px-3 py-1 rounded-xl bg-emerald-950/80 text-emerald-400 border border-emerald-700/60 text-[11px] font-black flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" />
                            <span>{isBn ? 'অনুমোদিত (Approved)' : 'Approved'}</span>
                          </span>
                        ) : tx.status === 'rejected' ? (
                          <div className="flex items-center gap-1.5">
                            <span className="px-3 py-1 rounded-xl bg-rose-950/80 text-rose-400 border border-rose-700/60 text-[11px] font-black flex items-center gap-1">
                              <X className="w-3.5 h-3.5" />
                              <span>{isBn ? 'বাতিলকৃত (Rejected)' : 'Rejected'}</span>
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                adminDeleteTransaction(tx.id);
                              }}
                              className="p-1.5 bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800/80 rounded-xl transition flex items-center gap-1 cursor-pointer active:scale-95 shadow"
                              title={isBn ? 'ডিলিট করুন' : 'Delete'}
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                adminApproveTransaction(tx.id);
                              }}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black flex items-center gap-1 cursor-pointer active:scale-95 shadow-md shadow-emerald-900/30"
                            >
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                              <span>{isBn ? 'অনুমোদন করুন (Approve)' : 'Approve'}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                adminRejectTransaction(tx.id);
                              }}
                              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer active:scale-95 shadow-md shadow-rose-900/30"
                            >
                              <X className="w-3.5 h-3.5 stroke-[3]" />
                              <span>{isBn ? 'রিজেক্ট করুন' : 'Reject'}</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 5: ADD PRODUCT */}
      {activeAdminSubTab === 'add_stock' && (
        <div className="max-w-2xl mx-auto">
          {/* Form: Add new product */}
          <div className="bg-slate-900/90 border border-slate-800 p-5 sm:p-6 rounded-2xl space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
              <PackagePlus className="w-5 h-5 text-emerald-400" />
              <span>{isBn ? 'নতুন প্রোডাক্ট যোগ করুন' : 'Add New Product'}</span>
            </h3>

            <form onSubmit={handleAddProduct} className="space-y-4 text-xs">
              {/* Category Selector */}
              <div>
                <label className="text-slate-300 font-bold block mb-1.5">
                  {isBn ? 'ক্যাটাগরি সিলেক্ট করুন:' : 'Select Category:'}
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-bold focus:outline-none focus:border-emerald-500"
                  required
                >
                  {categories.filter(c => c.id !== 'all').map((c) => (
                    <option key={c.id} value={c.id}>
                      {isBn ? c.nameBn : c.nameEn}
                    </option>
                  ))}
                </select>
              </div>

              {/* 1. Product Title */}
              <div>
                <label className="text-slate-300 font-bold block mb-1.5">{isBn ? 'প্রোডাক্ট টাইটেল (Product Title):' : 'Product Title:'}</label>
                <input
                  type="text"
                  value={newTitleBn}
                  onChange={(e) => setNewTitleBn(e.target.value)}
                  placeholder={isBn ? 'প্রোডাক্টের টাইটেল লিখুন...' : 'Enter product title...'}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              {/* 2. Product Description */}
              <div>
                <label className="text-slate-300 font-bold block mb-1.5">{isBn ? 'ডেসক্রিপশন (Description):' : 'Description:'}</label>
                <textarea
                  rows={3}
                  value={newShortDescBn}
                  onChange={(e) => setNewShortDescBn(e.target.value)}
                  placeholder={isBn ? 'প্রোডাক্টের ডেসক্রিপশন ও বিস্তারিত লিখুন...' : 'Enter product description...'}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              {/* 3. Product Image */}
              <ImageUploadField
                label={isBn ? 'প্রোডাক্টের ছবি (Product Image):' : 'Product Image:'}
                value={newImage}
                onChange={(url) => setNewImage(url)}
                isBn={isBn}
              />

              {/* 3.5 Live Demo Link */}
              <div>
                <label className="text-slate-300 font-bold block mb-1.5 flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-cyan-400" />
                  <span>{isBn ? 'লাইভ ডেমো ওয়েবসাইট লিঙ্ক (Demo Website URL):' : 'Live Demo Website URL:'}</span>
                </label>
                <input
                  type="url"
                  value={newDemoUrl}
                  onChange={(e) => setNewDemoUrl(e.target.value)}
                  placeholder="e.g. https://demo.mysite.com"
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  {isBn ? '💡 কাস্টমার চোখের (Eye) আইকনে ক্লিক করলে সরাসরি এই ডেমো ওয়েবসাইটে যেতে পারবে।' : '💡 Customers can click the Eye icon to visit this live demo site.'}
                </p>
              </div>

              {/* 4. Price & Offer Price */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="text-slate-300 font-bold block mb-1.5">{isBn ? 'রেগুলার প্রাইজ / আসল দাম (BDT):' : 'Regular Price (BDT):'}</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-black text-sm">৳</span>
                    <input
                      type="number"
                      value={newOriginalPrice || ''}
                      onChange={(e) => setNewOriginalPrice(parseFloat(e.target.value) || 0)}
                      placeholder="5000"
                      className="w-full pl-8 pr-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-300 font-bold text-sm focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1.5">{isBn ? 'অফার প্রাইজ / বিশেষ দাম (BDT):' : 'Offer Price (BDT):'}</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-400 font-black text-sm">৳</span>
                    <input
                      type="number"
                      value={newPrice || ''}
                      onChange={(e) => setNewPrice(parseFloat(e.target.value) || 0)}
                      placeholder="3500"
                      className="w-full pl-8 pr-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-emerald-400 font-bold text-sm focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* 5. Save Button */}
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 font-black text-slate-950 text-sm flex items-center justify-center gap-2 transition shadow-xl cursor-pointer active:scale-98 mt-2"
              >
                <Save className="w-4 h-4" />
                <span>{isBn ? 'প্রোডাক্ট সেভ করুন' : 'Save Product'}</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SUB-TAB 9: FULL SITE SETTINGS & CUSTOMIZATION (EDIT EVERYTHING) */}
      {activeAdminSubTab === 'site_settings' && (
        <div className="space-y-6">
          <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-3xl shadow-xl space-y-2">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-amber-400" />
              <span>{isBn ? 'ওয়েবসাইটের সর্বাত্মক কাস্টমাইজেশন ও ব্র্যান্ডিং (Full Site Settings)' : 'Global Site Settings & Customization'}</span>
            </h2>
            <p className="text-xs text-slate-400">
              {isBn ? 'এখান থেকে আপনি ওয়েবসাইটের নাম, লোগো, হোয়াটসঅ্যাপ নম্বর, সোশ্যাল লিংক, নোটিশ, কারেন্সি এবং সিকিউরিটি পিন পরিবর্তন করতে পারবেন।' : 'Manage site name, logo, WhatsApp support phone, notice tickers, currency, and security PIN.'}
            </p>
          </div>

          <form onSubmit={handleSaveSiteSettings} className="space-y-6 text-xs">
            {/* 1. Branding & Name */}
            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-3xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <Tag className="w-4 h-4 text-cyan-400" />
                <span>{isBn ? '১. ব্রান্ডিং ও ওয়েবসাইট আইডেন্টিটি (Branding & Identity)' : '1. Branding & Identity'}</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'ওয়েবসাইটের নাম (Site Name):' : 'Site Name:'}
                  </label>
                  <input
                    type="text"
                    value={siteNameForm}
                    onChange={(e) => setSiteNameForm(e.target.value)}
                    placeholder="e.g. CODE BAZAR"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-bold focus:outline-none focus:ring-1 focus:ring-cyan-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'কারেন্সি সিম্বল (Currency Symbol):' : 'Currency Symbol:'}
                  </label>
                  <input
                    type="text"
                    value={currencySymbolForm}
                    onChange={(e) => setCurrencySymbolForm(e.target.value)}
                    placeholder="e.g. ৳ or $"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-emerald-400 font-extrabold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  {isBn ? 'ব্র্যান্ড লোগো ইমেজ (Logo URL or Upload):' : 'Logo Image URL or Upload:'}
                </label>
                <div className="space-y-2">
                  <ImageUploadField
                    value={logoUrlForm}
                    onChange={setLogoUrlForm}
                    label={isBn ? 'লোগো ইমেজ ফাইল নির্বাচন করুন বা ড্রাগ করুন' : 'Select or drop logo image file'}
                  />
                  {logoUrlForm && (
                    <div className="flex items-center gap-3 p-2 bg-slate-950 border border-slate-800 rounded-xl w-fit">
                      <span className="text-[11px] text-slate-400 font-bold">{isBn ? 'লোগো প্রিভিউ:' : 'Logo Preview:'}</span>
                      <img src={logoUrlForm} alt="Logo preview" className="w-8 h-8 object-cover rounded-lg border border-slate-700" />
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'ট্যাগলাইন (বাংলা):' : 'Tagline (Bangla):'}
                  </label>
                  <input
                    type="text"
                    value={siteTaglineBnForm}
                    onChange={(e) => setSiteTaglineBnForm(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'ট্যাগলাইন (ইংরেজি):' : 'Tagline (English):'}
                  </label>
                  <input
                    type="text"
                    value={siteTaglineEnForm}
                    onChange={(e) => setSiteTaglineEnForm(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>
            </div>

            {/* 2. Support & Contact Information */}
            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-3xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? '২. সাপোর্ট ও হেল্পলাইন কন্টাক্ট (Support Channels & Helpline)' : '2. Support Channels & Helpline'}</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'অফিসিয়াল হোয়াটসঅ্যাপ নাম্বার (WhatsApp Support):' : 'Official WhatsApp Number:'}
                  </label>
                  <input
                    type="text"
                    value={whatsappNumberForm}
                    onChange={(e) => setWhatsappNumberForm(e.target.value)}
                    placeholder="e.g. 01836828065"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-emerald-400 font-mono font-bold focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'হোমপেজ হোয়াটসঅ্যাপ ব্যানার টেক্সট:' : 'Homepage WhatsApp Banner Text:'}
                  </label>
                  <input
                    type="text"
                    value={whatsappBannerTextForm}
                    onChange={(e) => setWhatsappBannerTextForm(e.target.value)}
                    placeholder="WHATSAPP (01836828065) বাটনে ক্লিক করে সরাসরি সাপোর্ট নিন 👍"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>

                <div className="md:col-span-2 bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800">
                  <ImageUploadField
                    label={isBn ? 'হোয়াটসঅ্যাপ ফ্লোটিং বাটন কাস্টম লোগো/আইকন ছবি (WhatsApp Button Icon):' : 'Custom WhatsApp Button Icon Image:'}
                    value={whatsappIconUrlForm}
                    onChange={(url) => setWhatsappIconUrlForm(url)}
                    isBn={isBn}
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'টেলিগ্রাম গ্রুপ/চ্যানেল লিংক (Telegram Link):' : 'Telegram Channel/Group Link:'}
                  </label>
                  <input
                    type="text"
                    value={telegramLinkForm}
                    onChange={(e) => setTelegramLinkForm(e.target.value)}
                    placeholder="https://t.me/codebazar_official"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-sky-400 font-mono focus:outline-none focus:ring-1 focus:ring-sky-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'সাপোর্ট ইমেইল (Support Email):' : 'Support Email:'}
                  </label>
                  <input
                    type="email"
                    value={supportEmailForm}
                    onChange={(e) => setSupportEmailForm(e.target.value)}
                    placeholder="support@codebazar.store"
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>
            </div>

            {/* Telegram Multi-Channel Auto Alert Settings */}
            <div className="bg-slate-900/90 border border-sky-500/40 p-5 rounded-3xl space-y-5 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 rounded-xl bg-sky-950 border border-sky-500/40 text-sky-400">
                    <Send className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{isBn ? 'অটো টেলিগ্রাম মাল্টি-চ্যানেল নোটিফিকেশন' : 'Multi-Channel Telegram Auto Alerts'}</span>
                      <span className="px-2 py-0.5 bg-sky-950 text-sky-400 border border-sky-800/60 text-[10px] font-black rounded-lg">
                        BOT API
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      {isBn
                        ? 'অর্ডার, ইউজার রেজিস্ট্রেশন, বিকাশ ডিপোজিট ও নগদ ডিপোজিটের জন্য আলাদা আলাদা চ্যানেলে অটো মেসেজ পাঠান।'
                        : 'Send automated Telegram alerts to separate channels for orders, registrations, bKash & Nagad deposits.'}
                    </p>
                  </div>
                </div>

                <label className="flex items-center gap-2 cursor-pointer bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 hover:border-sky-500/50 transition-colors">
                  <input
                    type="checkbox"
                    checked={telegramNotifyEnabledForm}
                    onChange={(e) => setTelegramNotifyEnabledForm(e.target.checked)}
                    className="w-4 h-4 accent-sky-500 rounded cursor-pointer"
                  />
                  <span className="text-xs font-bold text-slate-200">
                    {isBn ? 'অটো নোটিফিকেশন চালু' : 'Enable Auto Alerts'}
                  </span>
                </label>
              </div>

              {/* Step-by-Step Instructions */}
              <div className="bg-sky-950/40 border border-sky-800/40 p-3.5 rounded-2xl space-y-2 text-xs">
                <h4 className="font-bold text-sky-300 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-sky-400 shrink-0" />
                  <span>{isBn ? 'টেলিগ্রাম নোটিফিকেশন সেটআপ নির্দেশিকা:' : 'Telegram Multi-Bot & Multi-Channel Guide:'}</span>
                </h4>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isBn
                    ? 'আপনি চাইলে রেজিস্ট্রেশন, ডিপোজিট এবং অর্ডারের জন্য আলাদা আলাদা বট (Bot Token) এবং আলাদা আলাদা চ্যানেল/গ্রুপ ব্যবহার করতে পারেন। কোনো ক্যাটাগরির নিজস্ব বট টোকেন না দিলে ডিফল্ট বট টোকেন দিয়ে নোটিফিকেশন যাবে।'
                    : 'You can configure dedicated bots (Bot Tokens) and specific private channels/groups for User Registrations, Deposit/TrxID Requests, and Product Orders independently.'}
                </p>
              </div>

              {/* SECTION A: REGISTRATION BOT & CHANNEL */}
              <div className="bg-slate-950/80 border border-purple-800/50 p-4 rounded-3xl space-y-3.5 shadow-lg">
                <div className="flex items-center justify-between border-b border-purple-900/30 pb-2.5">
                  <h4 className="text-xs font-black text-purple-300 flex items-center gap-2 uppercase tracking-wide">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-500 animate-pulse"></span>
                    <span>👤 {isBn ? '১. নতুন ইউজার রেজিস্ট্রেশন বট ও চ্যানেল (User Registration)' : '1. User Registration Bot & Channel'}</span>
                  </h4>
                  <span className="text-[10px] bg-purple-950 text-purple-300 px-2 py-0.5 rounded-full border border-purple-700/50 font-bold">
                    {isBn ? 'শুধুমাত্র রেজিস্ট্রেশন অ্যালার্ট' : 'Registration Only'}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-300 font-bold block mb-1 text-[11px]">
                      {isBn ? 'রেজিস্ট্রেশন Bot Token (বট টোকেন):' : 'Registration Bot Token:'}
                      <span className="text-[10px] text-slate-400 font-normal ml-1">({isBn ? 'ঐচ্ছিক / খালি রাখলে ডিফল্ট বট' : 'Optional'})</span>
                    </label>
                    <input
                      type="text"
                      value={telegramRegistrationBotTokenForm}
                      onChange={(e) => setTelegramRegistrationBotTokenForm(e.target.value)}
                      placeholder="e.g. 8853475013:AAH-z33AZW5J9..."
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-purple-300 font-mono text-xs focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-bold block mb-1 text-[11px]">
                      {isBn ? 'রেজিস্ট্রেশন চ্যানেল/চ্যাট আইডি (Chat ID):' : 'Registration Channel / Chat ID:'}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={telegramRegistrationChatIdForm}
                        onChange={(e) => setTelegramRegistrationChatIdForm(e.target.value)}
                        placeholder="e.g. -1003714893029"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-purple-300 font-mono text-xs focus:outline-none focus:border-purple-500"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          adminTestTelegramNotification(
                            telegramRegistrationBotTokenForm || telegramBotTokenForm,
                            telegramRegistrationChatIdForm || telegramChatIdForm,
                            'registration'
                          )
                        }
                        className="px-3 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1 shrink-0 cursor-pointer active:scale-95"
                        title={isBn ? 'রেজিস্ট্রেশন টেস্ট মেসেজ পাঠান' : 'Send Registration Test'}
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{isBn ? 'টেস্ট' : 'Test'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION B: DEPOSIT / MONEY BOT & CHANNELS */}
              <div className="bg-slate-950/80 border border-emerald-800/50 p-4 rounded-3xl space-y-3.5 shadow-lg">
                <div className="flex items-center justify-between border-b border-emerald-900/30 pb-2.5">
                  <h4 className="text-xs font-black text-emerald-300 flex items-center gap-2 uppercase tracking-wide">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>💵 {isBn ? '২. ডিপোজিট রিকোয়েস্ট বট ও চ্যানেলসমূহ (Deposit & TrxID Alerts)' : '2. Deposit & TrxID Alerts'}</span>
                  </h4>
                  <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-700/50 font-bold">
                    {isBn ? 'শুধুমাত্র ডিপোজিট অ্যালার্ট' : 'Deposits Only'}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-300 font-bold block mb-1 text-[11px]">
                      {isBn ? 'ডিপোজিট Bot Token (বট টোকেন):' : 'Deposit Bot Token:'}
                      <span className="text-[10px] text-slate-400 font-normal ml-1">({isBn ? 'ঐচ্ছিক / খালি রাখলে ডিফল্ট বট' : 'Optional'})</span>
                    </label>
                    <input
                      type="text"
                      value={telegramDepositBotTokenForm}
                      onChange={(e) => setTelegramDepositBotTokenForm(e.target.value)}
                      placeholder="e.g. 8853475013:AAH-z33AZW5J9..."
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-emerald-300 font-mono text-xs focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-bold block mb-1 text-[11px]">
                      {isBn ? 'সাধারণ ডিপোজিট চ্যানেল আইডি (General Deposit Channel):' : 'General Deposit Channel ID:'}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={telegramDepositChatIdForm}
                        onChange={(e) => setTelegramDepositChatIdForm(e.target.value)}
                        placeholder="e.g. -100XXXXXXXXXX"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-emerald-300 font-mono text-xs focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          adminTestTelegramNotification(
                            telegramDepositBotTokenForm || telegramBotTokenForm,
                            telegramDepositChatIdForm || telegramChatIdForm,
                            'deposit'
                          )
                        }
                        className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1 shrink-0 cursor-pointer active:scale-95"
                        title={isBn ? 'ডিপোজিট টেস্ট মেসেজ পাঠান' : 'Send Deposit Test'}
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{isBn ? 'টেস্ট' : 'Test'}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Specific Method Channels */}
                <div className="pt-2 space-y-2 border-t border-slate-800">
                  <span className="text-[11px] font-bold text-slate-300 block">
                    {isBn ? 'নির্দিষ্ট পেমেন্ট মেথড ভিত্তিক আলাদা চ্যানেল (Specific Gateway Channels):' : 'Payment Method Specific Channels:'}
                  </span>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                    {/* bKash */}
                    <div className="bg-slate-900/90 border border-pink-900/40 p-2.5 rounded-2xl">
                      <label className="text-pink-400 font-bold block mb-1 text-[11px] flex items-center justify-between">
                        <span>💳 {isBn ? 'বিকাশ ডিপোজিট চ্যানেল ID:' : 'bKash Channel ID:'}</span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={telegramBkashChatIdForm}
                          onChange={(e) => setTelegramBkashChatIdForm(e.target.value)}
                          placeholder="-1003778905526"
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-pink-300 font-mono text-xs focus:outline-none focus:border-pink-500"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            adminTestTelegramNotification(
                              telegramDepositBotTokenForm || telegramBotTokenForm,
                              telegramBkashChatIdForm || telegramDepositChatIdForm || telegramChatIdForm,
                              'bkash'
                            )
                          }
                          className="p-1.5 bg-pink-600 hover:bg-pink-500 text-white rounded-xl shadow transition shrink-0 cursor-pointer active:scale-95"
                          title="Test bKash Alert"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Nagad */}
                    <div className="bg-slate-900/90 border border-orange-900/40 p-2.5 rounded-2xl">
                      <label className="text-orange-400 font-bold block mb-1 text-[11px] flex items-center justify-between">
                        <span>🟠 {isBn ? 'নগদ ডিপোজিট চ্যানেল ID:' : 'Nagad Channel ID:'}</span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={telegramNagadChatIdForm}
                          onChange={(e) => setTelegramNagadChatIdForm(e.target.value)}
                          placeholder="-1004417567167"
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-orange-300 font-mono text-xs focus:outline-none focus:border-orange-500"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            adminTestTelegramNotification(
                              telegramDepositBotTokenForm || telegramBotTokenForm,
                              telegramNagadChatIdForm || telegramDepositChatIdForm || telegramChatIdForm,
                              'nagad'
                            )
                          }
                          className="p-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded-xl shadow transition shrink-0 cursor-pointer active:scale-95"
                          title="Test Nagad Alert"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Rocket / Other */}
                    <div className="bg-slate-900/90 border border-violet-900/40 p-2.5 rounded-2xl">
                      <label className="text-violet-400 font-bold block mb-1 text-[11px] flex items-center justify-between">
                        <span>🚀 {isBn ? 'রকেট/অন্যান্য চ্যানেল ID:' : 'Rocket Channel ID:'}</span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={telegramRocketChatIdForm}
                          onChange={(e) => setTelegramRocketChatIdForm(e.target.value)}
                          placeholder="-100XXXXXXXXXX"
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl text-violet-300 font-mono text-xs focus:outline-none focus:border-violet-500"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            adminTestTelegramNotification(
                              telegramDepositBotTokenForm || telegramBotTokenForm,
                              telegramRocketChatIdForm || telegramDepositChatIdForm || telegramChatIdForm,
                              'rocket'
                            )
                          }
                          className="p-1.5 bg-violet-600 hover:bg-violet-500 text-white rounded-xl shadow transition shrink-0 cursor-pointer active:scale-95"
                          title="Test Rocket Alert"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION C: PRODUCT ORDERS BOT & CHANNEL */}
              <div className="bg-slate-950/80 border border-sky-800/50 p-4 rounded-3xl space-y-3.5 shadow-lg">
                <div className="flex items-center justify-between border-b border-sky-900/30 pb-2.5">
                  <h4 className="text-xs font-black text-sky-300 flex items-center gap-2 uppercase tracking-wide">
                    <span className="w-2.5 h-2.5 rounded-full bg-sky-500 animate-pulse"></span>
                    <span>📦 {isBn ? '৩. প্রোডাক্ট অর্ডার বট ও চ্যানেল (Product Orders)' : '3. Product Orders Bot & Channel'}</span>
                  </h4>
                  <span className="text-[10px] bg-sky-950 text-sky-300 px-2 py-0.5 rounded-full border border-sky-700/50 font-bold">
                    {isBn ? 'শুধুমাত্র অর্ডার অ্যালার্ট' : 'Orders Only'}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-300 font-bold block mb-1 text-[11px]">
                      {isBn ? 'অর্ডার Bot Token (বট টোকেন):' : 'Orders Bot Token:'}
                      <span className="text-[10px] text-slate-400 font-normal ml-1">({isBn ? 'ঐচ্ছিক / খালি রাখলে ডিফল্ট বট' : 'Optional'})</span>
                    </label>
                    <input
                      type="text"
                      value={telegramOrderBotTokenForm}
                      onChange={(e) => setTelegramOrderBotTokenForm(e.target.value)}
                      placeholder="e.g. 8853475013:AAH-z33AZW5J9..."
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-sky-300 font-mono text-xs focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="text-slate-300 font-bold block mb-1 text-[11px]">
                      {isBn ? 'প্রোডাক্ট অর্ডার চ্যানেল আইডি (Orders Channel ID):' : 'Product Orders Channel ID:'}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={telegramChatIdForm}
                        onChange={(e) => setTelegramChatIdForm(e.target.value)}
                        placeholder="e.g. -1004482692104"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-sky-300 font-mono text-xs focus:outline-none focus:border-sky-500"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          adminTestTelegramNotification(
                            telegramOrderBotTokenForm || telegramBotTokenForm,
                            telegramChatIdForm,
                            'order'
                          )
                        }
                        className="px-3 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1 shrink-0 cursor-pointer active:scale-95"
                        title={isBn ? 'অর্ডার টেস্ট মেসেজ পাঠান' : 'Send Order Test'}
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{isBn ? 'টেস্ট' : 'Test'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION D: DEFAULT FALLBACK BOT TOKEN */}
              <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl">
                <label className="text-slate-300 font-bold block mb-1 text-xs flex items-center gap-1.5">
                  <Bot className="w-4 h-4 text-amber-400" />
                  <span>{isBn ? '৪. গ্লোবাল ডিফল্ট Bot Token (Default Fallback Token):' : '4. Default Fallback Bot Token:'}</span>
                </label>
                <input
                  type="text"
                  value={telegramBotTokenForm}
                  onChange={(e) => setTelegramBotTokenForm(e.target.value)}
                  placeholder="e.g. 8853475013:AAH-z33AZW5J9..."
                  className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-amber-300 font-mono text-xs focus:outline-none focus:border-amber-500"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  {isBn
                    ? 'উপরে কোনো ক্যাটাগরির নিজস্ব Bot Token না দেওয়া থাকলে স্বয়ংক্রিয়ভাবে এই ডিফল্ট টোকেনটি ব্যবহার হবে।'
                    : 'Used as fallback for any category where a dedicated bot token is not specified.'}
                </span>
              </div>
            </div>



            {/* 3. Strict Admin API Key Security & Master Recovery */}
            <div className="bg-slate-900/90 border border-amber-500/30 p-5 rounded-3xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-amber-400" />
                  <span>{isBn ? '৩. এডমিন সিক্রেট API Key গেটওয়ে ও সিকিউরিটি' : '3. Admin Secret API Key Gateway'}</span>
                </h3>
                <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800/60 font-black px-2.5 py-0.5 rounded-full uppercase">
                  {isBn ? '🔒 API Key সিকিউরিটি সক্রিয়' : '🔒 API Key Active'}
                </span>
              </div>

              <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-2xl text-[11px] text-slate-300 space-y-1.5">
                <div className="font-bold text-blue-400 flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4" />
                  <span>{isBn ? 'এডমিন অ্যাক্সেস কি সেটিংস (Secret API Key Settings):' : 'Admin Secret API Key Settings:'}</span>
                </div>
                <p className="leading-relaxed text-slate-400 text-[11px]">
                  {isBn
                    ? 'এডমিন প্যানেলে প্রবেশের জন্য একমাত্র আপনার নির্ধারিত এই সিক্রেট API Key টি ব্যবহৃত হবে। এটি শুধুমাত্র আপনার কাছে গোপন রাখুন।'
                    : 'This secret API Key is used to authenticate into the admin workspace. Keep it strictly confidential.'}
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-slate-300 font-bold block text-xs">
                    {isBn ? 'আপনার সিক্রেট API Key (Admin Secret API Key):' : 'Admin Secret API Key:'}
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase() + '-' + Date.now().toString().slice(-4);
                      setAdminApiKeyForm(`CB-ADMIN-${randomSuffix}`);
                      addToast(isBn ? 'নতুন ইউনিক API Key জেনারেট করা হয়েছে! সেভ করতে ভুলবেন না।' : 'New Unique API Key Generated! Remember to save.', 'info');
                    }}
                    className="text-[11px] text-blue-400 hover:text-blue-300 font-mono font-bold underline cursor-pointer"
                  >
                    {isBn ? '🔄 নতুন API Key জেনারেট করুন' : '🔄 Generate New Key'}
                  </button>
                </div>
                <input
                  type="text"
                  value={adminApiKeyForm}
                  onChange={(e) => setAdminApiKeyForm(e.target.value)}
                  placeholder="CB-ADMIN-SECURE-998877-KEY"
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-blue-500/40 rounded-xl text-blue-300 font-mono font-bold text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  required
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  {isBn ? '🔑 এই API Key টি কপি করে নিরাপদে রাখুন। এটি ছাড়া প্যানেল ওপেন করা যাবে না।' : '🔑 Store this API Key safely. You need it to authenticate into the panel.'}
                </p>
              </div>
            </div>

            {/* 4. Footer & About Section */}
            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-3xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <Code2 className="w-4 h-4 text-cyan-400" />
                <span>{isBn ? '৪. ফুটার বিবরণী ও কপিরাইট টেক্সট (Footer Info & Copyright)' : '4. Footer Info & Copyright'}</span>
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'ফুটার সংক্ষিপ্ত পরিচিতি (বাংলা):' : 'Footer About Description (Bangla):'}
                  </label>
                  <textarea
                    rows={2}
                    value={footerAboutBnForm}
                    onChange={(e) => setFooterAboutBnForm(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">
                    {isBn ? 'কপিরাইট নোটিশ (Copyright Line):' : 'Copyright Notice Line:'}
                  </label>
                  <input
                    type="text"
                    value={copyrightTextForm}
                    onChange={(e) => setCopyrightTextForm(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-300 font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>
            </div>

            {/* Save Button Bar */}
            <div className="sticky bottom-4 z-20 bg-slate-900/95 border border-cyan-500/40 p-4 rounded-2xl shadow-2xl backdrop-blur-md flex items-center justify-between gap-4">
              <div className="text-slate-300 text-xs font-bold flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{isBn ? 'পরিবর্তন করার পর সেভ বাটনে ক্লিক করতে ভুলবেন না।' : 'Click save to permanently store your global configuration changes.'}</span>
              </div>
              <button
                type="submit"
                className="px-6 py-3 bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-cyan-500/20 flex items-center gap-2 cursor-pointer transition active:scale-95 shrink-0"
              >
                <Save className="w-4 h-4" />
                <span>{isBn ? 'সবকিছু সেভ ও সংরক্ষণ করুন' : 'Save All Settings'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* EDIT PRODUCT MODAL */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl p-5 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-amber-400" />
                <span>{isBn ? 'প্রোডাক্ট তথ্য সম্পাদনা (Edit Product)' : 'Edit Product Details'}</span>
              </h3>
              <button onClick={() => setEditingProduct(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProductEdit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  {isBn ? 'ক্যাটাগরি সিলেক্ট করুন (Category):' : 'Select Category:'}
                </label>
                <select
                  value={editingProduct.categoryId}
                  onChange={(e) => setEditingProduct({ ...editingProduct, categoryId: e.target.value as CategoryId })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-bold focus:outline-none focus:border-emerald-500"
                >
                  {categories.filter(c => c.id !== 'all').map((c) => (
                    <option key={c.id} value={c.id}>
                      {isBn ? c.nameBn : c.nameEn}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">টাইটেল (বাংলা):</label>
                <input
                  type="text"
                  value={editingProduct.titleBn}
                  onChange={(e) => setEditingProduct({ ...editingProduct, titleBn: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">Title (English):</label>
                <input
                  type="text"
                  value={editingProduct.titleEn}
                  onChange={(e) => setEditingProduct({ ...editingProduct, titleEn: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                />
              </div>

              {/* Package Variants & Duration Editor inside Edit Modal */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>{isBn ? 'মেয়াদী প্যাকেজ ও ভ্যারিয়েন্টসমূহ (Edit Variants):' : 'Package Variants & Durations:'}</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const newVar = {
                        id: 'var-' + Date.now(),
                        nameBn: 'নতুন প্যাকেজ ' + (editingProduct.variants.length + 1),
                        nameEn: 'New Package ' + (editingProduct.variants.length + 1),
                        durationBn: '১ বছর',
                        durationEn: '1 Year',
                        price: 5000,
                        originalPrice: 6500,
                        inStock: true,
                        stockCount: 10,
                        credentialsPool: []
                      };
                      setEditingProduct({
                        ...editingProduct,
                        variants: [...editingProduct.variants, newVar]
                      });
                    }}
                    className="px-2 py-1 bg-amber-950 hover:bg-amber-900 text-amber-300 text-[10px] font-bold rounded-lg border border-amber-800 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>{isBn ? 'নতুন মেয়াদী প্যাকেজ যোগ করুন' : 'Add Duration Package'}</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {editingProduct.variants.map((v, vIdx) => (
                    <div key={v.id || vIdx} className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[10px] font-bold text-cyan-400 font-mono">প্যাকেজ #{vIdx + 1}</span>
                        {editingProduct.variants.length > 1 && (
                          <button
                            type="button"
                            onClick={() => {
                              const filtered = editingProduct.variants.filter((_, i) => i !== vIdx);
                              setEditingProduct({ ...editingProduct, variants: filtered });
                            }}
                            className="text-rose-400 hover:text-rose-300 text-[10px] font-bold"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] text-slate-400 block mb-0.5">প্যাকেজ নাম (বাংলা):</label>
                          <input
                            type="text"
                            value={v.nameBn}
                            onChange={(e) => {
                              const updatedVars = editingProduct.variants.map((item, i) =>
                                i === vIdx ? { ...item, nameBn: e.target.value } : item
                              );
                              setEditingProduct({ ...editingProduct, variants: updatedVars });
                            }}
                            className="w-full px-2.5 py-1 text-xs bg-slate-950 border border-slate-700 rounded-lg text-white"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-400 block mb-0.5">মেয়াদ (Duration):</label>
                          <input
                            type="text"
                            value={v.durationBn}
                            onChange={(e) => {
                              const updatedVars = editingProduct.variants.map((item, i) =>
                                i === vIdx ? { ...item, durationBn: e.target.value, durationEn: e.target.value } : item
                              );
                              setEditingProduct({ ...editingProduct, variants: updatedVars });
                            }}
                            placeholder="e.g. ১ মাস, ১ বছর, ৩ বছর, লাইফটাইম"
                            className="w-full px-2.5 py-1 text-xs bg-slate-950 border border-slate-700 rounded-lg text-amber-300 font-bold"
                          />
                        </div>
                      </div>

                      {/* Quick Duration Preset Chips */}
                      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                        <span className="text-[9px] text-slate-500 whitespace-nowrap">দ্রুত সময়:</span>
                        {['১৫ দিন', '১ মাস', '৩ মাস', '৬ মাস', '১ বছর', '২ বছর', '৩ বছর', 'লাইফটাইম'].map((dur) => (
                          <button
                            key={dur}
                            type="button"
                            onClick={() => {
                              const updatedVars = editingProduct.variants.map((item, i) =>
                                i === vIdx ? { ...item, durationBn: dur, durationEn: dur } : item
                              );
                              setEditingProduct({ ...editingProduct, variants: updatedVars });
                            }}
                            className={`px-1.5 py-0.5 text-[9px] font-bold rounded border cursor-pointer whitespace-nowrap ${
                              v.durationBn === dur
                                ? 'bg-amber-500 text-slate-950 border-amber-400'
                                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                            }`}
                          >
                            {dur}
                          </button>
                        ))}
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] text-slate-400 block mb-0.5">অফার প্রাইস (BDT):</label>
                          <input
                            type="number"
                            value={v.price}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              const updatedVars = editingProduct.variants.map((item, i) =>
                                i === vIdx ? { ...item, price: val } : item
                              );
                              setEditingProduct({ ...editingProduct, variants: updatedVars });
                            }}
                            className="w-full px-2.5 py-1 text-xs bg-slate-950 border border-slate-700 rounded-lg text-emerald-400 font-bold"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-400 block mb-0.5">আগের প্রাইস (BDT):</label>
                          <input
                            type="number"
                            value={v.originalPrice || 0}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              const updatedVars = editingProduct.variants.map((item, i) =>
                                i === vIdx ? { ...item, originalPrice: val } : item
                              );
                              setEditingProduct({ ...editingProduct, variants: updatedVars });
                            }}
                            className="w-full px-2.5 py-1 text-xs bg-slate-950 border border-slate-700 rounded-lg text-slate-400 line-through"
                          />
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-300 font-bold block mb-1">ডেলিভারি টাইপ:</label>
                  <select
                    value={editingProduct.deliveryType || 'instant'}
                    onChange={(e) => setEditingProduct({ ...editingProduct, deliveryType: e.target.value as 'instant' | '5m' })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                  >
                    <option value="instant">ইনস্ট্যান্ট (Instant)</option>
                    <option value="5m">৫ মিনিট (5m Delivery)</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">ওয়ারেন্টি টেক্সট (বাংলা):</label>
                  <input
                    type="text"
                    value={editingProduct.warrantyBn || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, warrantyBn: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">সংক্ষিপ্ত বিবরণ (Short Description):</label>
                <input
                  type="text"
                  value={editingProduct.shortDescBn}
                  onChange={(e) => setEditingProduct({ ...editingProduct, shortDescBn: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none"
                />
              </div>

              <ImageUploadField
                label={isBn ? 'প্রাইমারি প্রোডাক্ট ছবি (Main Image):' : 'Main Product Image:'}
                value={editingProduct.imageUrl}
                onChange={(url) => setEditingProduct({ ...editingProduct, imageUrl: url })}
                isBn={isBn}
              />

              <div className="bg-cyan-950/30 border border-cyan-500/30 p-3 rounded-2xl space-y-1.5">
                <label className="text-cyan-300 font-bold block text-xs flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-cyan-400" />
                  <span>{isBn ? 'লাইভ ডেমো ওয়েবসাইট লিঙ্ক (Demo Website URL):' : 'Live Demo Website URL:'}</span>
                </label>
                <input
                  type="text"
                  value={editingProduct.demoUrl || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, demoUrl: e.target.value })}
                  placeholder="e.g. https://demo.casino-script.com"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none font-mono text-xs"
                />
                <p className="text-[11px] text-slate-400">
                  {isBn ? '💡 কাস্টমার চোখের (Eye) আইকনে ক্লিক করলে সরাসরি এই ডেমো লিঙ্কে ভিজিট করতে পারবে।' : '💡 Clicking the eye icon will take customers to this live demo site.'}
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" /> Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* QUICK CREDIT USER MODAL */}
      {quickCreditUser && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-500/40 w-full max-w-sm rounded-2xl p-5 space-y-4 shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {isBn ? 'ইউজার ওয়ালেটে টাকা এড করুন' : 'Add Money To User'}
                  </h3>
                  <span className="text-xs text-emerald-400 font-bold block">{quickCreditUser.name} ({quickCreditUser.phone})</span>
                </div>
              </div>
              <button onClick={() => setQuickCreditUser(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleQuickCreditSubmit} className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-bold block mb-1">
                  {isBn ? 'বর্তমান ওয়ালেট ব্যালেন্স:' : 'Current Balance:'} <span className="text-emerald-400 font-mono">৳{quickCreditUser.walletBalance}</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-emerald-400 font-black text-sm">৳</span>
                  <input
                    type="number"
                    value={quickCreditAmount}
                    onChange={(e) => setQuickCreditAmount(e.target.value)}
                    placeholder={isBn ? 'কত টাকা যোগ করতে চান?' : 'Enter BDT amount'}
                    className="w-full pl-8 pr-3 py-2.5 text-sm font-bold bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    autoFocus
                    required
                  />
                </div>
              </div>

              {/* Presets */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {[100, 200, 500, 1000, 2000, 5000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setQuickCreditAmount(amt.toString())}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 text-xs font-bold rounded-lg border border-slate-700 cursor-pointer"
                  >
                    +৳{amt}
                  </button>
                ))}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setQuickCreditUser(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isBn ? 'টাকা যোগ সম্পন্ন করুন' : 'Confirm Credit'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT CATEGORY MODAL */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-cyan-400" />
                <span>{isBn ? 'ক্যাটাগরি সম্পাদনা করুন' : 'Edit Category'}</span>
              </h3>
              <button
                onClick={() => setEditingCategory(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!editingCategory.nameBn.trim()) return;
                adminUpdateCategory(editingCategory, editingCategoryOriginalId);
                setEditingCategory(null);
              }}
              className="space-y-3"
            >
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  {isBn ? 'ক্যাটাগরি আইডি (Category ID):' : 'Category ID:'}
                </label>
                <input
                  type="text"
                  value={editingCategory.id}
                  onChange={(e) => setEditingCategory({ ...editingCategory, id: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-slate-300 font-mono focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  {isBn ? 'বাংলা ক্যাটাগরি নাম:' : 'Bangla Category Name:'}
                </label>
                <input
                  type="text"
                  value={editingCategory.nameBn}
                  onChange={(e) => setEditingCategory({ ...editingCategory, nameBn: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  {isBn ? 'ইংরেজি ক্যাটাগরি নাম:' : 'English Category Name:'}
                </label>
                <input
                  type="text"
                  value={editingCategory.nameEn}
                  onChange={(e) => setEditingCategory({ ...editingCategory, nameEn: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  required
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs rounded-xl shadow cursor-pointer transition flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{isBn ? 'সংরক্ষণ করুন' : 'Save Changes'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT BANNER MODAL */}
      {editingBanner && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-5 space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-amber-400" />
                <span>{isBn ? 'ব্যানার সম্পাদনা ও লিংক আপডেট' : 'Edit Banner & Link'}</span>
              </h3>
              <button
                onClick={() => setEditingBanner(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBannerEdit} className="space-y-3.5">
              {/* Image Upload / URL */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">
                  {isBn ? 'ব্যানার ছবির লিংক অথবা নতুন ছবি আপলোড:' : 'Banner Image URL / Upload:'}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="url"
                    value={editBannerUrl}
                    onChange={(e) => setEditBannerUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="flex-1 px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                    required
                  />
                  <label className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold rounded-xl border border-slate-700 cursor-pointer shrink-0 flex items-center gap-1">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isBn ? 'ফাইল' : 'Upload'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleEditBannerFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Title Input */}
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  {isBn ? 'ব্যানার ক্যাপশন / শিরোনাম:' : 'Banner Title / Caption:'}
                </label>
                <input
                  type="text"
                  value={editBannerTitle}
                  onChange={(e) => setEditBannerTitle(e.target.value)}
                  placeholder="e.g. Code Bazar Special Offer"
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              {/* Action Link Input */}
              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <label className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5" />
                  <span>{isBn ? 'টার্গেট লিংক (ভিডিও লিংক / টেলিগ্রাম চ্যানেল / কাস্টম লিংক):' : 'Target Action Link (Video / Telegram / URL):'}</span>
                </label>
                <input
                  type="text"
                  value={editBannerLink}
                  onChange={(e) => setEditBannerLink(e.target.value)}
                  placeholder="e.g. https://t.me/codebazar_official অথবা https://youtube.com/watch?v=..."
                  className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:ring-1 focus:ring-amber-500"
                />

                {/* Quick presets for Edit modal */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-400 font-semibold">{isBn ? 'প্রিসেট:' : 'Presets:'}</span>
                  <button
                    type="button"
                    onClick={() => setEditBannerLink(siteConfig.telegramLink || 'https://t.me/codebazar_official')}
                    className="px-2 py-0.5 rounded-lg bg-sky-950/80 hover:bg-sky-900 border border-sky-700/60 text-sky-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    <Send className="w-2.5 h-2.5" />
                    <span>{isBn ? 'টেলিগ্রাম' : 'Telegram'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditBannerLink('https://youtube.com')}
                    className="px-2 py-0.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-700/60 text-rose-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    <Play className="w-2.5 h-2.5" />
                    <span>{isBn ? 'ইউটিউব' : 'YouTube'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const num = (siteConfig.whatsappNumber || '01836828065').replace(/\D/g, '');
                      setEditBannerLink(`https://wa.me/${num.startsWith('88') ? num : '88' + num}`);
                    }}
                    className="px-2 py-0.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-300 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    <MessageCircle className="w-2.5 h-2.5" />
                    <span>{isBn ? 'হোয়াটসঅ্যাপ' : 'WhatsApp'}</span>
                  </button>
                  {editBannerLink && (
                    <button
                      type="button"
                      onClick={() => setEditBannerLink('')}
                      className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 text-[10px] font-bold transition cursor-pointer"
                    >
                      {isBn ? 'লিংক মুছুন' : 'Clear Link'}
                    </button>
                  )}
                </div>
              </div>

              {/* Active status checkbox */}
              <div className="flex items-center gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <input
                  type="checkbox"
                  id="editBannerActiveToggle"
                  checked={editBannerActive}
                  onChange={(e) => setEditBannerActive(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500 bg-slate-900 border-slate-700 cursor-pointer"
                />
                <label htmlFor="editBannerActiveToggle" className="text-xs font-bold text-slate-300 cursor-pointer">
                  {isBn ? 'স্লাইডারে এই ব্যানার প্রদর্শন করুন (Active)' : 'Show this banner on slider (Active)'}
                </label>
              </div>

              {/* Preview */}
              {editBannerUrl && (
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold block">প্রিভিউ:</span>
                  <div className="h-32 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 relative">
                    <img src={editBannerUrl} alt="Preview" className="w-full h-full object-cover" />
                    {editBannerLink && (
                      <div className="absolute top-2 right-2 bg-slate-950/90 border border-amber-400/50 text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-full shadow flex items-center gap-1">
                        <LinkIcon className="w-3 h-3" />
                        <span className="truncate max-w-[150px]">{editBannerLink}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingBanner(null)}
                  className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl shadow cursor-pointer transition flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{isBn ? 'সংরক্ষণ করুন' : 'Save Changes'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export const AdminTab: React.FC = () => {
  const { isAdminAuthenticated } = useStore();

  if (!isAdminAuthenticated) {
    return <AdminApiKeyGate />;
  }

  return <AdminDashboardContent />;
};
