import React from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Sparkles,
  Calendar,
  Clock,
  ShieldCheck,
  RefreshCw,
  Zap,
  CheckCircle2
} from 'lucide-react';

export const SubscriptionsTab: React.FC = () => {
  const { orders, user, isUserLoggedIn, language, setSelectedOrderForView, setSelectedProductForBuy, products } = useStore();
  const isBn = language === 'bn';

  const activeSubscriptions = isUserLoggedIn
    ? orders.filter((o) => {
        if (o.status !== 'active') return false;
        if (o.userId && user.id && o.userId === user.id) return true;
        if (user.email && (o.userEmail === user.email || o.siteAdminEmail === user.email)) return true;
        if (user.phone && (o.userPhone === user.phone || o.sitePhone === user.phone || o.paymentSenderMobile === user.phone)) return true;
        return false;
      })
    : [];

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>{isBn ? 'সক্রিয় সাবস্ক্রিপশন ট্র্যাকার' : 'Active Subscription Tracker'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isBn ? 'আপনার সক্রিয় অ্যাকাউন্টগুলোর মেয়াদ ও রিনিউয়াল রিমাইন্ডার ট্র্যাক করুন।' : 'Track active sub expiration dates and quick renewals.'}
          </p>
        </div>
      </div>

      {/* Grid of active subscriptions */}
      {activeSubscriptions.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activeSubscriptions.map((sub) => (
            <div
              key={sub.id}
              className="bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-5 shadow-lg space-y-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={sub.productImage}
                    alt={sub.productTitleEn}
                    className="w-12 h-12 object-cover rounded-xl border border-slate-800"
                  />
                  <div>
                    <h3 className="text-sm font-bold text-white">{isBn ? sub.productTitleBn : sub.productTitleEn}</h3>
                    <p className="text-xs text-cyan-400 font-medium">{isBn ? sub.variantNameBn : sub.variantNameEn}</p>
                  </div>
                </div>

                <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                  ACTIVE
                </span>
              </div>

              {/* Validity timeline */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>{isBn ? 'ক্রয় তারিখ:' : 'Purchased On:'}</span>
                  <span className="font-semibold text-slate-200">{sub.purchaseDate}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>{isBn ? 'মেয়াদ শেষ:' : 'Valid Until:'}</span>
                  <span className="font-bold text-amber-400">{sub.expiryDate}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                <button
                  onClick={() => setSelectedOrderForView(sub)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  {isBn ? 'লগইন ইনফো দেখুন' : 'View Credentials'}
                </button>

                <button
                  onClick={() => {
                    const matchedProd = products.find((p) => p.id === sub.productId);
                    if (matchedProd) setSelectedProductForBuy(matchedProd);
                  }}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-md cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{isBn ? 'মেয়াদ বাড়ান (Renew)' : 'Renew Now'}</span>
                </button>
              </div>

            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-3xl space-y-3">
          <Sparkles className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-slate-300">{isBn ? 'কোনো সক্রিয় সাবস্ক্রিপশন নেই' : 'No Active Subscriptions'}</h3>
          <p className="text-xs text-slate-500">{isBn ? 'মার্কেটপ্লেস থেকে আপনার পছন্দের ডিজিটাল সাবস্ক্রিপশন সার্ভিসটি ক্রয় করুন।' : 'Purchase a digital service subscription from marketplace.'}</p>
        </div>
      )}

    </div>
  );
};
