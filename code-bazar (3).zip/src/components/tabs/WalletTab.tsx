import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Wallet,
  PlusCircle,
  History,
  CheckCircle2,
  Clock,
  XCircle,
  Filter
} from 'lucide-react';

export const WalletTab: React.FC = () => {
  const { user, transactions, language, setIsAddMoneyModalOpen } = useStore();
  const isBn = language === 'bn';

  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  // Filter ONLY Deposit Transactions as requested
  const depositTransactions = transactions.filter((t) => t.type === 'deposit');

  const pendingCount = depositTransactions.filter((t) => t.status === 'pending').length;
  const approvedCount = depositTransactions.filter((t) => t.status === 'approved').length;
  const rejectedCount = depositTransactions.filter((t) => t.status === 'rejected').length;

  const filteredDeposits = depositTransactions.filter((tx) => {
    if (statusFilter === 'pending') return tx.status === 'pending';
    if (statusFilter === 'approved') return tx.status === 'approved';
    if (statusFilter === 'rejected') return tx.status === 'rejected';
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Wallet Balance & Deposit Action Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 border border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
                <Wallet className="w-5 h-5" />
              </span>
              <span className="text-xs font-bold uppercase text-emerald-400 tracking-wider">
                {isBn ? 'ওয়ালেট ব্যালেন্স' : 'Current Balance'}
              </span>
              <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 rounded-full border border-emerald-500/30">
                ACTIVE
              </span>
            </div>

            <div className="mt-4">
              <h2 className="text-4xl font-black text-white tracking-tight">৳ {user.walletBalance.toLocaleString()}</h2>
              <p className="text-xs text-slate-400 mt-1">{isBn ? 'ওয়েবসাইট অর্ডার করার জন্য প্রস্তুত' : 'Available for placing website orders'}</p>
            </div>
          </div>

          <div className="sm:w-72">
            <button
              onClick={() => setIsAddMoneyModalOpen(true)}
              className="w-full py-3.5 px-6 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-sm rounded-2xl shadow-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-98"
            >
              <PlusCircle className="w-5 h-5" />
              <span>{isBn ? 'টাকা ডিপোজিট করুন' : 'Deposit Money'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Deposit History Header & Status Filters */}
      <div className="space-y-3 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <History className="w-5 h-5 text-emerald-400" />
              <span>{isBn ? 'ডিপোজিট হিস্টোরি ও স্ট্যাটাস' : 'Deposit History & Status'}</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isBn
                ? 'আপনার জমাকৃত ডিপোজিট, পেন্ডিং/প্রসেসিং ও কনফার্মেশন স্ট্যাটাস দেখুন।'
                : 'View your deposit requests, pending/processing and confirmation status.'}
            </p>
          </div>

          <button
            onClick={() => setIsAddMoneyModalOpen(true)}
            className="self-start sm:self-auto px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{isBn ? 'নতুন ডিপোজিট করুন' : 'New Deposit'}</span>
          </button>
        </div>

        {/* Deposit Status Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs no-scrollbar">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl font-bold border transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              statusFilter === 'all'
                ? 'bg-slate-800 text-white border-slate-600 shadow'
                : 'bg-slate-950/80 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>{isBn ? 'সকল ডিপোজিট' : 'All Deposits'} ({depositTransactions.length})</span>
          </button>

          <button
            onClick={() => setStatusFilter('pending')}
            className={`px-3 py-1.5 rounded-xl font-bold border transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              statusFilter === 'pending'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow'
                : 'bg-slate-950/80 text-amber-400/70 border-slate-800 hover:text-amber-300'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{isBn ? 'পেন্ডিং / প্রসেসিং' : 'Pending / Processing'} ({pendingCount})</span>
          </button>

          <button
            onClick={() => setStatusFilter('approved')}
            className={`px-3 py-1.5 rounded-xl font-bold border transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              statusFilter === 'approved'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow'
                : 'bg-slate-950/80 text-emerald-400/70 border-slate-800 hover:text-emerald-300'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{isBn ? 'কনফার্মড' : 'Confirmed'} ({approvedCount})</span>
          </button>

          {rejectedCount > 0 && (
            <button
              onClick={() => setStatusFilter('rejected')}
              className={`px-3 py-1.5 rounded-xl font-bold border transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                statusFilter === 'rejected'
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow'
                  : 'bg-slate-950/80 text-rose-400/70 border-slate-800 hover:text-rose-300'
              }`}
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>{isBn ? 'বাতিলকৃত' : 'Rejected'} ({rejectedCount})</span>
            </button>
          )}
        </div>
      </div>

      {/* Deposit Transactions Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        {filteredDeposits.length === 0 ? (
          <div className="p-8 text-center space-y-3">
            <Clock className="w-10 h-10 text-slate-600 mx-auto" />
            <div>
              <p className="text-sm font-bold text-slate-300">
                {isBn ? 'কোনো ডিপোজিট রেকর্ড পাওয়া যায়নি' : 'No deposit record found'}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                {isBn ? 'আপনার সিলেক্ট করা ফিল্টারে কোনো ডিপোজিট এন্ট্রি নেই।' : 'No deposit entries matching selected filter.'}
              </p>
            </div>
            <button
              onClick={() => setIsAddMoneyModalOpen(true)}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              {isBn ? 'এখনই ডিপোজিট করুন' : 'Deposit Money Now'}
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="p-3.5">{isBn ? 'তারিখ ও আইডি' : 'Date & ID'}</th>
                  <th className="p-3.5">{isBn ? 'পেমেন্ট মেথড' : 'Payment Method'}</th>
                  <th className="p-3.5">{isBn ? 'Transaction ID (TrxID)' : 'TrxID'}</th>
                  <th className="p-3.5 text-right">{isBn ? 'ডিপোজিট পরিমাণ' : 'Deposit Amount'}</th>
                  <th className="p-3.5 text-center">{isBn ? 'ডিপোজিট স্ট্যাটাস' : 'Deposit Status'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredDeposits.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3.5">
                      <span className="font-bold text-white block">{tx.date}</span>
                      <span className="text-[10px] text-slate-500 font-mono">{tx.id}</span>
                    </td>

                    <td className="p-3.5">
                      <div className="flex items-center gap-2">
                        <span className="font-black uppercase text-[11px] text-pink-400 bg-pink-950/60 border border-pink-800/40 px-2 py-0.5 rounded-lg">
                          {tx.method}
                        </span>
                        {tx.senderMobile && (
                          <span className="text-[11px] text-slate-400 font-mono">
                            {tx.senderMobile}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {isBn ? tx.descriptionBn : tx.descriptionEn}
                      </span>
                    </td>

                    <td className="p-3.5">
                      <span className="font-mono text-cyan-300 font-black text-xs bg-slate-950 px-2 py-1 rounded-lg border border-slate-800 inline-block">
                        {tx.trxId || 'N/A'}
                      </span>
                    </td>

                    <td className="p-3.5 text-right">
                      <span className="text-emerald-400 font-black text-sm">
                        +৳ {tx.amount.toLocaleString()}
                      </span>
                      {tx.bonusAmount ? (
                        <span className="text-[10px] text-amber-400 block font-semibold">
                          +{tx.bonusAmount} BDT Bonus
                        </span>
                      ) : null}
                    </td>

                    <td className="p-3.5 text-center">
                      {tx.status === 'pending' && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm animate-pulse">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          <span>{isBn ? 'পেন্ডিং / প্রসেসিং' : 'Pending / Processing'}</span>
                        </span>
                      )}

                      {tx.status === 'approved' && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/40 shadow-sm">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{isBn ? 'কনফার্মড' : 'Confirmed'}</span>
                        </span>
                      )}

                      {tx.status === 'rejected' && (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-rose-500/15 text-rose-300 border border-rose-500/40 shadow-sm">
                          <XCircle className="w-3.5 h-3.5 text-rose-400" />
                          <span>{isBn ? 'বাতিলকৃত' : 'Rejected'}</span>
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};

