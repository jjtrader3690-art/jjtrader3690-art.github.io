import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  ShoppingBag,
  Key,
  Calendar,
  Clock,
  ShieldCheck,
  Search,
  ExternalLink,
  Zap,
  CheckCircle2,
  Copy,
  Check,
  Globe,
  Mail,
  Phone,
  HelpCircle,
  LogIn,
  UserCheck
} from 'lucide-react';

export const OrdersTab: React.FC = () => {
  const { orders, user, isUserLoggedIn, setIsAuthModalOpen, language, setSelectedOrderForView, addToast } = useStore();
  const [searchOrder, setSearchOrder] = useState<string>('');
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);

  const isBn = language === 'bn';

  const handleCopyOrderId = (e: React.MouseEvent, orderNum: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(orderNum);
    setCopiedOrderId(orderNum);
    addToast(isBn ? `অর্ডার নম্বর ${orderNum} কপি হয়েছে!` : `Order ID ${orderNum} copied!`, 'success');
    setTimeout(() => setCopiedOrderId(null), 2000);
  };

  // Strictly isolate orders belonging to the logged-in user account
  const myOrders = isUserLoggedIn
    ? orders.filter((order) => {
        if (order.userId && user.id && order.userId === user.id) return true;
        if (user.email && (order.userEmail === user.email || order.siteAdminEmail === user.email)) return true;
        if (user.phone && (order.userPhone === user.phone || order.sitePhone === user.phone || order.paymentSenderMobile === user.phone)) return true;
        return false;
      })
    : [];

  const filteredOrders = myOrders.filter((order) => {
    const query = searchOrder.toLowerCase().trim();
    return (
      !query ||
      order.orderNumber.toLowerCase().includes(query) ||
      order.id.toLowerCase().includes(query) ||
      order.productTitleBn.toLowerCase().includes(query) ||
      order.productTitleEn.toLowerCase().includes(query) ||
      (order.siteName && order.siteName.toLowerCase().includes(query)) ||
      (order.siteAdminEmail && order.siteAdminEmail.toLowerCase().includes(query)) ||
      (order.sitePhone && order.sitePhone.toLowerCase().includes(query))
    );
  });

  if (!isUserLoggedIn) {
    return (
      <div className="space-y-6">
        <div className="text-center py-16 bg-slate-900/60 border border-slate-800 rounded-3xl p-8 space-y-4 shadow-xl">
          <div className="w-16 h-16 bg-gradient-to-tr from-cyan-500/20 to-blue-500/20 rounded-2xl flex items-center justify-center mx-auto border border-cyan-500/30 text-cyan-400">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white">
            {isBn ? 'আপনার অর্ডার দেখতে লগইন করুন' : 'Login to View Your Orders'}
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            {isBn
              ? 'আপনার ক্রয়কৃত সকল ওয়েবসাইট অর্ডার ও অ্যাক্সেস ডিটেইলস শুধুমাত্র আপনার নিজস্ব একাউন্টে সুরক্ষিত থাকে।'
              : 'All your ordered website credentials & services are securely tied to your personal account.'}
          </p>
          <button
            type="button"
            onClick={() => setIsAuthModalOpen(true)}
            className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-cyan-500/20 transition cursor-pointer inline-flex items-center gap-2 active:scale-95"
          >
            <LogIn className="w-4 h-4" />
            <span>{isBn ? 'লগইন / রেজিস্টার করুন' : 'Login / Register'}</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      
      {/* Search Input Filter for Order ID & Info */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 p-4 rounded-2xl border border-slate-800 shadow-xl space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <Search className="w-4 h-4 text-cyan-400" />
            <span>{isBn ? 'অর্ডার আইডি বা সাইটের নাম দিয়ে সার্চ করুন:' : 'Search by Order ID or Site Name:'}</span>
          </label>
          <span className="text-[10px] text-slate-400">
            {isBn ? `মোট পাওয়া গেছে: ${filteredOrders.length} টি` : `Found: ${filteredOrders.length}`}
          </span>
        </div>

        <div className="relative">
          <input
            type="text"
            value={searchOrder}
            onChange={(e) => setSearchOrder(e.target.value)}
            placeholder={isBn ? 'আপনার অর্ডার নম্বর (যেমন: CB-2026-83920), সাইটের নাম বা ইমেইল টাইপ করুন...' : 'Type Order ID (e.g. CB-2026-83920), site name or email...'}
            className="w-full pl-3.5 pr-10 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-cyan-300 font-mono font-bold placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 shadow-inner"
          />
          {searchOrder && (
            <button
              onClick={() => setSearchOrder('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white font-bold bg-slate-800 rounded-full w-5 h-5 flex items-center justify-center"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Orders List Table */}
      {filteredOrders.length > 0 ? (
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 transition-all space-y-4 shadow-xl relative overflow-hidden"
            >
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                
                {/* Product Info */}
                <div className="flex items-start sm:items-center gap-3.5">
                  <img
                    src={order.productImage}
                    alt={order.productTitleEn}
                    className="w-16 h-16 object-cover rounded-2xl border border-slate-800 shrink-0 shadow-md"
                  />
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      
                      {/* Order ID Tag with copy button */}
                      <div className="flex items-center bg-cyan-950/90 border border-cyan-800/80 rounded-lg px-2.5 py-0.5">
                        <span className="text-xs font-mono font-black text-cyan-300 mr-1.5">
                          {order.orderNumber}
                        </span>
                        <button
                          onClick={(e) => handleCopyOrderId(e, order.orderNumber)}
                          className="text-cyan-400 hover:text-cyan-200 transition-colors p-0.5"
                          title={isBn ? 'আইডি কপি করুন' : 'Copy ID'}
                        >
                          {copiedOrderId === order.orderNumber ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      {/* Status Badge */}
                      <span
                        className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border flex items-center gap-1 ${
                          order.status === 'processing'
                            ? 'bg-amber-950/90 text-amber-300 border-amber-500/50 animate-pulse'
                            : order.status === 'active'
                            ? 'bg-emerald-950 text-emerald-400 border-emerald-500/40 shadow-sm shadow-emerald-500/20'
                            : 'bg-slate-800 text-slate-400 border-slate-700'
                        }`}
                      >
                        {order.status === 'processing' ? (
                          <>
                            <Clock className="w-3 h-3 text-amber-400 animate-spin" />
                            <span>{isBn ? '⏳ প্রসেসিং (অপেক্ষমান)' : 'Processing'}</span>
                          </>
                        ) : order.status === 'active' ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            <span>{isBn ? '✅ কনফার্মকৃত (Active)' : 'Active'}</span>
                          </>
                        ) : (
                          <span>{order.status}</span>
                        )}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white">
                      {isBn ? order.productTitleBn : order.productTitleEn}
                    </h3>

                    <div className="flex items-center gap-2 text-[11px] text-slate-400 flex-wrap">
                      <span className="text-amber-300 font-semibold bg-amber-950/40 px-2 py-0.5 rounded border border-amber-500/20">
                        {isBn ? order.variantNameBn : order.variantNameEn}
                      </span>
                      <span>•</span>
                      <span className="text-emerald-400 font-black text-xs">৳ {order.price}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-slate-400 font-medium">
                        <Calendar className="w-3 h-3" />
                        {order.purchaseDate}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Status & Action Button */}
                <div className="flex items-center justify-between md:justify-end gap-4 border-t md:border-t-0 border-slate-800 pt-3 md:pt-0">
                  <button
                    onClick={() => setSelectedOrderForView(order)}
                    className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black text-xs rounded-xl shadow-lg shadow-cyan-500/20 active:scale-95 transition-all cursor-pointer"
                  >
                    <Key className="w-4 h-4" />
                    <span>{isBn ? 'অর্ডার ডিটেইলস ও ক্রেডেনশিয়াল' : 'View Order Details'}</span>
                  </button>
                </div>
              </div>

              {/* Status Banner */}
              {order.status === 'processing' ? (
                <div className="p-3 bg-amber-950/60 border border-amber-500/40 rounded-xl flex items-center justify-between text-xs text-amber-200 gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400 shrink-0 animate-spin" />
                    <span className="font-medium">
                      {isBn
                        ? 'আপনার দেওয়া সাইটের তথ্য যাচাই করা হচ্ছে। খুব শীঘ্রই (৫ - ১৫ মিনিট) অর্ডার সম্পূর্ণ কনফার্ম হবে।'
                        : 'Your submitted site information is being verified. Order will be confirmed shortly (5-15 mins).'}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-amber-300 bg-amber-900/80 px-2.5 py-1 rounded-lg border border-amber-500/50 whitespace-nowrap">
                    {isBn ? '⏱️ সময়: ৫-১৫ মিনিট' : 'Est: 5-15 mins'}
                  </span>
                </div>
              ) : (
                <div className="p-2.5 bg-emerald-950/50 border border-emerald-500/40 rounded-xl flex items-center justify-between text-xs text-emerald-300">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-medium">
                      {isBn
                        ? 'আপনার অর্ডার সম্পূর্ণ কনফার্ম ও প্রসেসড হয়েছে। ক্রেডেনশিয়াল দেখতে ডানপাশের বাটনে ক্লিক করুন।'
                        : 'Your order is confirmed and master credentials are live.'}
                    </span>
                  </div>
                </div>
              )}

              {/* Submitted Site Credentials Box */}
              {(order.siteName || order.siteAdminEmail || order.sitePhone || order.siteAdminPassword) && (
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-1.5">
                    <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{isBn ? 'আপনার সাবমিটকৃত ওয়েবসাইট ও এডমিন তথ্য:' : 'Your Submitted Site Information:'}</span>
                    </span>
                    <span className="text-[10px] text-amber-400 font-medium">
                      {isBn ? '🔒 সুসুরক্ষিত' : '🔒 Protected'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 text-[11px] font-mono">
                    {order.siteName && (
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <span className="text-slate-500 block text-[10px]">{isBn ? 'সাইটের নাম:' : 'Site Name:'}</span>
                        <span className="text-white font-bold truncate block">{order.siteName}</span>
                      </div>
                    )}
                    {order.siteAdminEmail && (
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <span className="text-slate-500 block text-[10px]">{isBn ? 'এডমিন জিমেইল:' : 'Admin Gmail:'}</span>
                        <span className="text-cyan-300 font-bold truncate block">{order.siteAdminEmail}</span>
                      </div>
                    )}
                    {order.siteAdminPassword && (
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <span className="text-slate-500 block text-[10px]">{isBn ? 'এডমিন পাসওয়ার্ড:' : 'Admin Password:'}</span>
                        <span className="text-emerald-400 font-bold truncate block">{order.siteAdminPassword}</span>
                      </div>
                    )}
                    {order.sitePhone && (
                      <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <span className="text-slate-500 block text-[10px]">{isBn ? 'মোবাইল নাম্বার:' : 'Phone Number:'}</span>
                        <span className="text-white font-bold truncate block">{order.sitePhone}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-3xl space-y-3 shadow-inner">
          <ShoppingBag className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-slate-300">
            {searchOrder
              ? (isBn ? 'আপনার প্রদানকৃত অর্ডার নম্বরের সাথে কোনো অর্ডার মেলেনি!' : 'No order matches your search query!')
              : (isBn ? 'আপনার কোনো অর্ডার পাওয়া যায়নি!' : 'No Orders Found!')}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {searchOrder
              ? (isBn ? 'দয়া করে আপনার সঠিক অর্ডার আইডি (e.g. CB-2026-XXXXX) বা সাইটের নাম দিয়ে আবার চেষ্টা করুন।' : 'Please verify your Order ID and search again.')
              : (isBn ? 'আপনার প্রথম রেডিমেড বেটিং ও ক্যাসিনো সাইট কিনতে মার্কেটপ্লেসে ভিজিট করুন।' : 'Visit marketplace to order your first ready website.')}
          </p>
          {searchOrder && (
            <button
              onClick={() => setSearchOrder('')}
              className="px-4 py-2 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 text-xs font-bold rounded-xl border border-cyan-800 transition cursor-pointer"
            >
              {isBn ? 'সার্চ ফিল্টার ক্লিয়ার করুন' : 'Clear Search Filter'}
            </button>
          )}
        </div>
      )}

    </div>
  );
};

