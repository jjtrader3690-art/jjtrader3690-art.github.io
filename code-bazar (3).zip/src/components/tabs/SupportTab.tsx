import React from 'react';
import { useStore } from '../../context/StoreContext';
import { MessageCircle, ExternalLink, ShieldCheck, Headphones } from 'lucide-react';

export const SupportTab: React.FC = () => {
  const { language, siteConfig } = useStore();
  const isBn = language === 'bn';

  const cleanWaNumber = (siteConfig.whatsappNumber || '01836828065').replace(/\D/g, '');
  const displayWaNumber = siteConfig.whatsappNumber || '01836828065';
  const waUrl = `https://wa.me/${cleanWaNumber.startsWith('88') ? cleanWaNumber : '88' + cleanWaNumber}?text=${encodeURIComponent('মেসেজ: ' + (siteConfig.siteName || 'XS Bazar') + ' সাপোর্ট সাহায্য চাই।')}`;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* WhatsApp Helpline Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 border border-emerald-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-center space-y-6">
        
        {/* Glow & Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold uppercase tracking-wider">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{isBn ? '২৪/৭ অফিসিয়াল হেল্পলাইন' : '24/7 Official Helpline'}</span>
        </div>

        {/* Header Icon & Title */}
        <div className="space-y-3">
          <div className="w-16 h-16 mx-auto bg-emerald-500/15 border border-emerald-500/30 rounded-2xl flex items-center justify-center text-emerald-400 shadow-lg">
            <MessageCircle className="w-8 h-8" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white">
            {isBn ? 'হোয়াটসঅ্যাপ কাস্টমার সাপোর্ট' : 'WhatsApp Customer Support'}
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
            {isBn
              ? 'যেকোনো প্রশ্ন, অর্ডার সংক্রান্ত তথ্য বা যেকোনো সমস্যার জন্য সরাসরি আমাদের অফিসিয়াল হোয়াটসঅ্যাপ হেল্পলাইনে যোগাযোগ করুন।'
              : 'For any questions, order information, or help, contact our official WhatsApp helpline directly.'}
          </p>
        </div>

        {/* WhatsApp Action Box */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl max-w-md mx-auto space-y-4">
          <div className="flex items-center justify-between px-2">
            <span className="text-xs text-slate-400 font-medium">{isBn ? 'হোয়াটসঅ্যাপ নম্বর:' : 'WhatsApp Number:'}</span>
            <span className="text-sm font-mono font-bold text-emerald-400">{displayWaNumber}</span>
          </div>

          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-4 px-6 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-sm sm:text-base rounded-2xl shadow-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer active:scale-98"
          >
            <MessageCircle className="w-5 h-5 fill-slate-950" />
            <span>{isBn ? 'হোয়াটসঅ্যাপে মেসেজ দিন' : 'Chat on WhatsApp'}</span>
            <ExternalLink className="w-4 h-4 ml-1 opacity-80" />
          </a>
        </div>

        {/* Security & Reliability Badge */}
        <div className="pt-2 flex items-center justify-center gap-6 text-[11px] text-slate-400 font-medium border-t border-slate-800/80">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{isBn ? 'দ্রুত সমাধান' : 'Fast Response'}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Headphones className="w-4 h-4 text-cyan-400" />
            <span>{isBn ? 'সরাসরি এডমিন সাপোর্ট' : 'Direct Admin Support'}</span>
          </div>
        </div>

      </div>

    </div>
  );
};

