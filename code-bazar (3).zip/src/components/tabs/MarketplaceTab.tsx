import React from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCard } from '../ProductCard';
import { BannerSlider } from '../BannerSlider';
import { CategoryId } from '../../types';
import {
  LayoutGrid,
  Code2,
  ShieldCheck,
  UserCheck,
  Coins,
  Wallet,
  Zap,
  Search,
  Megaphone,
  Phone,
  Globe,
  Tag
} from 'lucide-react';

export const MarketplaceTab: React.FC = () => {
  const {
    products,
    categories,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    language,
    siteConfig,
    setIsAddMoneyModalOpen
  } = useStore();

  const isBn = language === 'bn';

  const cleanWaNumber = (siteConfig.whatsappNumber || '01836828065').replace(/\D/g, '');
  const waUrl = `https://wa.me/${cleanWaNumber.startsWith('88') ? cleanWaNumber : '88' + cleanWaNumber}?text=${encodeURIComponent('মেসেজ: ' + (siteConfig.siteName || 'Code Bazar') + ' সাইট থেকে সাপোর্ট বা অর্ডার সংক্রান্ত সাহায্য চাই।')}`;

  // Filter Products
  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === 'all' || p.categoryId === selectedCategory;
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !query ||
      p.titleBn.toLowerCase().includes(query) ||
      p.titleEn.toLowerCase().includes(query) ||
      p.shortDescBn.toLowerCase().includes(query) ||
      p.shortDescEn.toLowerCase().includes(query);

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-4">
      
      {/* Image Banner Carousel Slider */}
      <BannerSlider />

      {/* Category Pills Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-500/20'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
            }`}
          >
            <span>{isBn ? cat.nameBn : cat.nameEn}</span>
          </button>
        ))}
      </div>

      {/* Search Input Bar */}
      <div className="relative max-w-md mx-auto w-full">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={isBn ? 'সার্চ করুন...' : 'Search...'}
          className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-900 border border-slate-800 rounded-2xl text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 shadow-inner"
        />
      </div>

      {/* Product Cards Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl space-y-2">
          <Search className="w-8 h-8 text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-slate-300">
            {isBn ? 'কোনো প্রোডাক্ট পাওয়া যায়নি!' : 'No Products Found!'}
          </h3>
          <p className="text-xs text-slate-500">
            {isBn ? 'অন্য কোনো কি-ওয়ার্ড দিয়ে খুঁজুন।' : 'Try searching with different keywords.'}
          </p>
        </div>
      )}

    </div>
  );
};

