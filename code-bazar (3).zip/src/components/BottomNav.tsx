import React from 'react';
import { useStore } from '../context/StoreContext';
import { LayoutGrid, ShoppingBag, Wallet, User, ShieldCheck, Headphones } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    language,
    setIsAdminView,
    isAdminAuthenticated,
    setIsAdminAuthModalOpen,
    isUserLoggedIn,
    setIsAuthModalOpen,
    setIsProfileDrawerOpen,
    addToast
  } = useStore();

  const isBn = language === 'bn';

  const navItems = [
    {
      id: 'marketplace',
      labelBn: 'Store',
      labelEn: 'Store',
      icon: LayoutGrid
    },
    {
      id: 'orders',
      labelBn: 'Orders',
      labelEn: 'Orders',
      icon: ShoppingBag
    },
    {
      id: 'wallet',
      labelBn: 'Add Money',
      labelEn: 'Add Money',
      icon: Wallet
    },
    {
      id: 'profile',
      labelBn: 'Profile',
      labelEn: 'Profile',
      icon: User
    },
    {
      id: 'admin',
      labelBn: 'Admin',
      labelEn: 'Admin',
      icon: ShieldCheck
    }
  ];

  const handleTabClick = (tabId: string) => {
    if (tabId === 'profile') {
      if (!isUserLoggedIn) {
        setIsAuthModalOpen(true);
      } else {
        setIsProfileDrawerOpen(true);
      }
      return;
    }

    if (tabId === 'admin') {
      setIsAdminView(true);
      setActiveTab('admin');
      return;
    }

    if ((tabId === 'orders' || tabId === 'wallet') && !isUserLoggedIn) {
      addToast(isBn ? 'আপনার অর্ডার ও ওয়ালেট দেখতে দয়া করে সাইন আপ/লগইন করুন।' : 'Please login/register to view orders & wallet.', 'info');
      setIsAuthModalOpen(true);
      return;
    }

    setIsAdminView(false);
    setActiveTab(tabId);
  };

  return (
    <div className="sticky bottom-0 z-40 bg-white border-t border-slate-200 px-2 py-1.5 flex items-center justify-around shadow-lg">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;

        return (
          <button
            key={item.id}
            onClick={() => handleTabClick(item.id)}
            className={`relative flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all duration-200 cursor-pointer ${
              isActive
                ? 'text-blue-600 font-black bg-blue-50 border border-blue-200 shadow-xs scale-105'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 font-bold'
            }`}
          >
            <Icon className={`w-5 h-5 ${isActive ? 'text-blue-600' : ''}`} />
            <span className="text-[10px] mt-0.5 tracking-tight">
              {isBn ? item.labelBn : item.labelEn}
            </span>
            {isActive && (
              <span className="absolute -top-1 w-1.5 h-1.5 rounded-full bg-blue-600" />
            )}
          </button>
        );
      })}
    </div>
  );
};
