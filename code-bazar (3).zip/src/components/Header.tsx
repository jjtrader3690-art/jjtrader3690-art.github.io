import React from 'react';
import { useStore } from '../context/StoreContext';
import { Wallet, PlusCircle, User } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    language,
    setActiveTab,
    user,
    setIsAddMoneyModalOpen,
    isUserLoggedIn,
    setIsAuthModalOpen,
    setIsProfileDrawerOpen,
    siteConfig,
    addToast
  } = useStore();

  const isBn = language === 'bn';

  const handleAddMoney = () => {
    if (!isUserLoggedIn) {
      addToast(
        isBn
          ? 'এড মনি করতে দয়া করে প্রথমে অ্যাকাউন্ট রেজিস্ট্রেশন/লগইন করুন।'
          : 'Please register/login first to add money.',
        'info'
      );
      setIsAuthModalOpen(true);
      return;
    }
    setIsAddMoneyModalOpen(true);
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 text-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-4">
        <div className="flex items-center justify-between h-13 sm:h-14 gap-2">
          {/* Logo & Brand Name */}
          <div
            className="flex items-center gap-2 cursor-pointer select-none shrink-0"
            onClick={() => setActiveTab('marketplace')}
          >
            <img
              src={siteConfig.logoUrl || '/favicon.svg'}
              alt="Site Logo"
              className="w-9 h-9 rounded-xl object-cover shrink-0"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = '/favicon.svg';
              }}
            />
            <div className="flex items-center">
              <span className="text-sm sm:text-base font-black tracking-tight text-blue-700 whitespace-nowrap">
                {siteConfig.siteName || 'XS BAZAR'}
              </span>
            </div>
          </div>

          {/* Right Header Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Wallet Balance Pill */}
            <div className="flex items-center bg-slate-50 border border-emerald-200 rounded-xl p-1 shadow-xs gap-1.5">
              <div className="flex items-center gap-1 px-1 text-emerald-700 font-black text-[11px] sm:text-xs">
                <Wallet className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-mono">
                  {siteConfig.currencySymbol || '৳'}
                  {user.walletBalance.toLocaleString()}
                </span>
              </div>
              <button
                id="header-add-money-btn"
                onClick={handleAddMoney}
                className="flex items-center justify-center bg-emerald-600 hover:bg-emerald-700 text-white font-black p-1 sm:p-1 rounded-lg transition-all active:scale-95 cursor-pointer shrink-0 shadow-sm"
                title={isBn ? 'টাকা যোগ করুন' : 'Add Money'}
              >
                <PlusCircle className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>
            </div>

            {/* Auth User Icon / Login Button */}
            {!isUserLoggedIn ? (
              <button
                id="header-login-btn"
                onClick={() => setIsAuthModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shrink-0 transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <User className="w-3.5 h-3.5 text-white" />
                <span>{isBn ? 'লগইন' : 'Login'}</span>
              </button>
            ) : (
              <div
                id="header-profile-badge"
                onClick={() => setIsProfileDrawerOpen(true)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl cursor-pointer transition shrink-0 shadow-xs"
                title={user.name || 'User Profile'}
              >
                <div className="relative flex items-center justify-center w-6.5 h-6.5 rounded-full bg-blue-600 text-white font-black text-[11px] shadow-sm shrink-0">
                  {user.name ? user.name.charAt(0).toUpperCase() : <User className="w-3.5 h-3.5 text-white" />}
                  <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 border-2 border-white shrink-0" />
                </div>
                <span className="hidden sm:inline-block text-xs font-bold text-slate-800 truncate max-w-[90px]">
                  {user.name || 'User'}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
