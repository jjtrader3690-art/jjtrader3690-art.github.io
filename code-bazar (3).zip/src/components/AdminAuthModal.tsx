import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { X, Key, Eye, EyeOff, Lock } from 'lucide-react';

export const AdminAuthModal: React.FC = () => {
  const {
    isAdminAuthModalOpen,
    setIsAdminAuthModalOpen,
    verifyAdminApiKey,
    siteConfig,
    language,
    addToast
  } = useStore();

  const [apiKey, setApiKey] = useState<string>('');
  const [showApiKey, setShowApiKey] = useState<boolean>(false);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);

  const isBn = language === 'bn';

  if (!isAdminAuthModalOpen) return null;

  const handleApiKeySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKey.trim()) return;

    setIsConnecting(true);
    setTimeout(() => {
      const ok = verifyAdminApiKey(apiKey);
      if (ok) {
        addToast(
          isBn ? 'API Key অথরাইজড! সিস্টেম সেশন শুরু হয়েছে।' : 'API Key Authorized! Gateway Session Active.',
          'success'
        );
        setIsAdminAuthModalOpen(false);
        setApiKey('');
      }
      setIsConnecting(false);
    }, 250);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-700/80 shadow-2xl shadow-blue-500/10 rounded-3xl overflow-hidden flex flex-col p-6 sm:p-7 transition-all duration-300">
        
        {/* Close Button */}
        <button
          onClick={() => setIsAdminAuthModalOpen(false)}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-full cursor-pointer transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Brand Header */}
        <div className="flex items-center gap-3.5 border-b border-slate-800 pb-4 mb-4">
          <img
            src={siteConfig.logoUrl || '/favicon.svg'}
            alt="Site Logo"
            className="w-12 h-12 rounded-2xl object-cover border border-slate-700/80 shadow-sm shrink-0 bg-slate-950 p-1"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = '/favicon.svg';
            }}
          />
          <div>
            <h2 className="text-base font-black text-white tracking-tight">
              {siteConfig.siteName || 'XS BAZAR'}
            </h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Secure Access Gateway
            </p>
          </div>
        </div>

        {/* API KEY AUTHENTICATION */}
        <form onSubmit={handleApiKeySubmit} className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-300 block">
                {isBn ? 'সিক্রেট API Key:' : 'Secret API Key:'}
              </label>
              <button
                type="button"
                onClick={() => setShowApiKey(!showApiKey)}
                className="text-[11px] text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1 cursor-pointer"
              >
                {showApiKey ? (
                  <>
                    <EyeOff className="w-3.5 h-3.5" />
                    <span>{isBn ? 'লুকান' : 'Hide'}</span>
                  </>
                ) : (
                  <>
                    <Eye className="w-3.5 h-3.5" />
                    <span>{isBn ? 'দেখুন' : 'Show'}</span>
                  </>
                )}
              </button>
            </div>

            <div className="relative">
              <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-400" />
              <input
                type={showApiKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder=""
                className="w-full pl-10 pr-10 py-3 text-xs font-mono font-bold bg-slate-950 border border-slate-700 focus:border-blue-500 rounded-xl text-blue-300 focus:outline-none focus:ring-1 focus:ring-blue-500 transition"
                autoFocus
                required
              />
              <button
                type="button"
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-400 cursor-pointer p-1"
              >
                {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isConnecting}
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          >
            {isConnecting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>{isBn ? 'ভেরিফাই হচ্ছে...' : 'Authenticating...'}</span>
              </>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>{isBn ? 'প্রবেশ করুন' : 'Enter Panel'}</span>
              </>
            )}
          </button>
        </form>

      </div>
    </div>
  );
};
