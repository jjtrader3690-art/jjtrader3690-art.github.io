import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';
import { PromoBanner } from '../types';

export const BannerSlider: React.FC = () => {
  const { banners, language } = useStore();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const isBn = language === 'bn';
  const activeBanners = banners.filter((b) => b.active);

  useEffect(() => {
    if (activeBanners.length <= 1 || isHovered) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [activeBanners.length, isHovered]);

  const handlePrev = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length);
  };

  const handleNext = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
  };

  const formatTargetUrl = (url?: string) => {
    if (!url) return '';
    const trimmed = url.trim();
    if (
      trimmed.startsWith('http://') ||
      trimmed.startsWith('https://') ||
      trimmed.startsWith('tg://') ||
      trimmed.startsWith('whatsapp://') ||
      trimmed.startsWith('mailto:') ||
      trimmed.startsWith('tel:')
    ) {
      return trimmed;
    }
    if (trimmed.startsWith('t.me/') || trimmed.startsWith('telegram.me/')) {
      return `https://${trimmed}`;
    }
    if (trimmed.startsWith('wa.me/') || trimmed.startsWith('api.whatsapp.com/')) {
      return `https://${trimmed}`;
    }
    if (trimmed.startsWith('youtube.com/') || trimmed.startsWith('youtu.be/')) {
      return `https://${trimmed}`;
    }
    if (/^[0-9+]{8,15}$/.test(trimmed)) {
      const cleanNum = trimmed.replace(/\D/g, '');
      const numWithCountry = cleanNum.startsWith('88') ? cleanNum : '88' + cleanNum;
      return `https://wa.me/${numWithCountry}`;
    }
    if (trimmed.startsWith('/')) {
      return trimmed;
    }
    return `https://${trimmed}`;
  };

  const handleBannerClick = (banner: PromoBanner) => {
    if (!banner.linkUrl?.trim()) return;
    const targetUrl = formatTargetUrl(banner.linkUrl);
    if (targetUrl) {
      window.open(targetUrl, '_blank', 'noopener,noreferrer');
    }
  };

  if (!activeBanners.length) {
    return (
      <div className="relative rounded-2xl overflow-hidden bg-slate-900/60 border border-slate-800 p-5 shadow-lg flex flex-col items-center justify-center text-center space-y-2">
        <ImageIcon className="w-8 h-8 text-slate-600" />
        <p className="text-xs text-slate-400">
          {isBn
            ? 'কোনো ব্যানার ছবি আপলোড করা নেই। অ্যাডমিন প্যানেল থেকে ব্যানার যোগ করুন।'
            : 'No active banners. Add banners from Admin Panel.'}
        </p>
      </div>
    );
  }

  const currentBanner = activeBanners[currentIndex] || activeBanners[0];
  const hasLink = Boolean(currentBanner.linkUrl?.trim());

  return (
    <div
      className={`relative rounded-2xl overflow-hidden border border-slate-800/80 shadow-2xl group bg-slate-950 transition-all ${
        hasLink ? 'cursor-pointer hover:border-blue-500/60' : ''
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => hasLink && handleBannerClick(currentBanner)}
      title={
        hasLink
          ? (isBn ? `লিংক ওপেন করতে ক্লিক করুন` : `Click to open link`)
          : (currentBanner.title || 'Banner')
      }
    >
      {/* Clean Aspect Ratio Image Container */}
      <div className="relative w-full h-44 sm:h-56 md:h-64 overflow-hidden select-none">
        <img
          src={currentBanner.imageUrl}
          alt={currentBanner.title || 'Banner'}
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&auto=format&fit=crop&q=80';
          }}
          className={`w-full h-full object-cover transition-transform duration-500 ease-out ${
            hasLink ? 'group-hover:scale-[1.015]' : ''
          }`}
        />

        {/* Minimal Slide Dots Indicator (Only if more than 1 banner) */}
        {activeBanners.length > 1 && (
          <div
            className="absolute bottom-2.5 left-1/2 -translate-x-1/2 z-10 flex items-center gap-1.5 bg-slate-950/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-slate-800/60"
            onClick={(e) => e.stopPropagation()}
          >
            {activeBanners.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setCurrentIndex(idx);
                }}
                className={`h-1.5 rounded-full transition-all cursor-pointer ${
                  idx === currentIndex ? 'w-4 bg-blue-400' : 'w-1.5 bg-slate-400/50 hover:bg-slate-200'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        )}

        {/* Navigation Arrows (Only if more than 1 banner) */}
        {activeBanners.length > 1 && (
          <>
            <button
              type="button"
              onClick={handlePrev}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-slate-950/70 hover:bg-slate-900 text-white border border-slate-700/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shadow-lg backdrop-blur-md z-20 active:scale-90"
              aria-label="Previous Banner"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={handleNext}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-slate-950/70 hover:bg-slate-900 text-white border border-slate-700/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shadow-lg backdrop-blur-md z-20 active:scale-90"
              aria-label="Next Banner"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}
      </div>
    </div>
  );
};


