import React from 'react';
import { useStore } from '../context/StoreContext';
import { Megaphone, Zap } from 'lucide-react';

export const NoticeBanner: React.FC = () => {
  const { announcements, language } = useStore();
  const activeAnnouncements = announcements.filter(
    (a) =>
      a.active &&
      a.id !== 'ann-2' &&
      !a.textBn?.includes('বিকাশ') &&
      !a.textBn?.includes('ডিপোজিট নম্বর') &&
      !a.textBn?.includes('হোয়াটসঅ্যাপ সাপোর্ট নম্বর')
  );

  if (activeAnnouncements.length === 0) return null;

  return (
    <div className="bg-blue-50 border-b border-blue-100 text-slate-800 text-xs py-2 px-4 shadow-2xs">
      <div className="max-w-7xl mx-auto flex items-center gap-3">
        <div className="flex items-center gap-1.5 font-bold text-white bg-blue-600 px-2.5 py-0.5 rounded-md whitespace-nowrap shadow-2xs">
          <Zap className="w-3.5 h-3.5 text-white" />
          <span>{language === 'bn' ? 'নোটিশ' : 'NOTICE'}</span>
        </div>
        <div className="overflow-hidden whitespace-nowrap flex-1 relative">
          <div className="inline-block animate-marquee font-bold text-slate-700">
            {activeAnnouncements.map((ann, idx) => (
              <span key={ann.id} className="mx-6 inline-flex items-center gap-2">
                <span className="text-blue-600 font-bold">•</span>
                {language === 'bn' ? ann.textBn : ann.textEn}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
