import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import {
  X,
  Zap,
  ShoppingBag,
  Wallet,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  Clock,
  Globe,
  Image as ImageIcon,
  Eye,
  EyeOff,
  Mail,
  Lock,
  Phone,
  MessageCircle,
  ArrowRight,
  ArrowLeft,
  Upload
} from 'lucide-react';

export const QuickBuyModal: React.FC = () => {
  const {
    selectedProductForBuy,
    setSelectedProductForBuy,
    language,
    user,
    isUserLoggedIn,
    setIsAuthModalOpen,
    purchaseProduct,
    setIsAddMoneyModalOpen,
    setActiveTab,
    setSelectedOrderForView,
    addToast
  } = useStore();

  const [step, setStep] = useState<1 | 2 | 3>(1); // Step 1: Site Info, Step 2: Payment Gateway & 30-min Timer, Step 3: Thank You Page
  const [selectedVariantIndex, setSelectedVariantIndex] = useState<number>(0);
  const [customInput, setCustomInput] = useState<string>('');
  const [completedOrder, setCompletedOrder] = useState<any>(null);
  
  // Custom Site Order details
  const [siteName, setSiteName] = useState<string>('');
  const [selectedDomain, setSelectedDomain] = useState<string>('.com');
  const [siteLogoUrl, setSiteLogoUrl] = useState<string>('');
  const [siteAdminEmail, setSiteAdminEmail] = useState<string>('');
  const [siteAdminPassword, setSiteAdminPassword] = useState<string>('');
  const [showAdminPassword, setShowAdminPassword] = useState<boolean>(false);
  const [sitePhone, setSitePhone] = useState<string>('');

  // Payment Mode choice in Step 2: Wallet only
  const [timeLeft, setTimeLeft] = useState<number>(1800);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (!selectedProductForBuy) return;
    setStep(1);
    setTimeLeft(1800);
    setCompletedOrder(null);
  }, [selectedProductForBuy]);

  useEffect(() => {
    if (step !== 2) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [step]);

  if (!selectedProductForBuy) return null;

  const product = selectedProductForBuy;
  const isBn = language === 'bn';
  const variant = product.variants[selectedVariantIndex] || product.variants[0];

  const originalPrice = variant.price;
  const finalPrice = originalPrice;
  const userBalance = Number(user.walletBalance) || 0;
  const hasSufficientBalance = userBalance >= finalPrice && finalPrice > 0;

  // Format countdown minutes and seconds
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSiteLogoUrl(reader.result as string);
        addToast(isBn ? 'লোগো ইমেজ সফলভাবে আপলোড হয়েছে!' : 'Logo image uploaded successfully!', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProceedToOrder = (e: React.FormEvent) => {
    e.preventDefault();

    if (!isUserLoggedIn) {
      addToast(
        isBn ? 'অর্ডার করতে দয়া করে আগে লগইন বা রেজিস্ট্রেশন করুন।' : 'Please login or register to place an order.',
        'info'
      );
      setIsAuthModalOpen(true);
      return;
    }

    if (!siteName.trim()) {
      addToast(isBn ? 'সাইটের নাম লিখুন!' : 'Please enter site name!', 'error');
      return;
    }
    if (!siteAdminEmail.trim() || !siteAdminEmail.includes('@')) {
      addToast(isBn ? 'সঠিক এডমিন জিমেইল/ইমেইল লিখুন!' : 'Please enter valid admin email!', 'error');
      return;
    }
    if (!siteAdminPassword.trim() || siteAdminPassword.length < 4) {
      addToast(isBn ? 'এডমিন পাসওয়ার্ড লিখুন (সর্বনিম্ন ৪ অক্ষরের)!' : 'Please enter admin password!', 'error');
      return;
    }
    if (!sitePhone.trim() || sitePhone.length < 11) {
      addToast(isBn ? 'সঠিক মোবাইল নম্বর লিখুন!' : 'Please enter valid phone number!', 'error');
      return;
    }

    if (!hasSufficientBalance || userBalance < finalPrice) {
      setIsAddMoneyModalOpen(true);
      addToast(
        isBn
          ? `আপনার ওয়ালেটে পর্যাপ্ত টাকা নেই! প্রয়োজন ৳${finalPrice}, বর্তমান ব্যালেন্স ৳${userBalance}। দয়া করে আগে বিকাশ/নগদে টাকা ডিপোজিট (এড) করুন।`
          : `Insufficient wallet balance! Required ৳${finalPrice}, available ৳${userBalance}. Please deposit money first.`,
        'error'
      );
      return;
    }

    const fullSiteName = siteName.trim().endsWith(selectedDomain)
      ? siteName.trim()
      : `${siteName.trim()}${selectedDomain}`;

    const siteDetails = {
      siteName: fullSiteName,
      siteLogoUrl: siteLogoUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80',
      siteAdminEmail,
      siteAdminPassword,
      sitePhone
    };

    setIsSubmitting(true);
    setTimeout(() => {
      const res = purchaseProduct(product, variant, customInput, siteDetails);
      setIsSubmitting(false);
      if (res.success) {
        setCompletedOrder(res.order);
        setStep(3);
        addToast(
          isBn ? 'অর্ডার সফলভাবে কনফার্ম হয়েছে! ওয়ালেট থেকে টাকা কেটে নেওয়া হয়েছে।' : 'Order confirmed! Wallet balance deducted.',
          'success'
        );
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-100 border border-cyan-200 text-cyan-700">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-slate-900">
                {step === 1 && (isBn ? 'সাইটের তথ্য ও অর্ডার কনফার্মেশন' : 'Site Setup & Order Confirmation')}
                {step === 3 && (isBn ? 'অর্ডার সফল! ধন্যবাদ 🎉' : 'Order Placed Successfully! 🎉')}
              </h3>
              <p className="text-[10px] sm:text-[11px] text-slate-500 line-clamp-1">{product.titleBn || product.titleEn}</p>
            </div>
          </div>

          <button
            onClick={() => setSelectedProductForBuy(null)}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          
          {/* Product Summary Mini Banner */}
          <div className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-2xl">
            <img
              src={product.imageUrl}
              alt={product.titleEn}
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80';
              }}
              className="w-12 h-12 object-cover rounded-xl shrink-0 border border-slate-200 shadow-sm"
            />
            <div className="flex-1 min-w-0">
              <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">{isBn ? product.titleBn : product.titleEn}</h4>
              <div className="flex items-center gap-2 mt-0.5 text-[11px]">
                <span className="text-emerald-600 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {isBn ? product.warrantyBn : product.warrantyEn}
                </span>
                <span className="text-slate-300">•</span>
                <span className="text-cyan-700 font-extrabold">৳ {finalPrice}</span>
              </div>
            </div>
          </div>

          {step === 1 ? (
            /* STEP 1: Site Information & Direct Wallet Order Confirmation */
            <form onSubmit={handleProceedToOrder} className="space-y-3.5">
              
              {/* 1. Site Name & Domain Extension Selector */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? '১. আপনার ওয়েবসাইটের নাম ও ডোমেইন:' : '1. Website Name & Domain Extension:'}
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-600" />
                    <input
                      type="text"
                      value={siteName}
                      onChange={(e) => setSiteName(e.target.value)}
                      placeholder={isBn ? "ওয়েবসাইটের নাম লিখুন" : "Enter website name"}
                      className="w-full pl-9 pr-3 py-2.5 text-xs bg-white border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 font-bold"
                      required
                    />
                  </div>
                  <select
                    value={selectedDomain}
                    onChange={(e) => setSelectedDomain(e.target.value)}
                    className="px-3 py-2.5 text-xs font-black bg-white border border-slate-300 text-cyan-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 shrink-0 cursor-pointer"
                  >
                    <option value=".com">.com</option>
                    <option value=".net">.net</option>
                    <option value=".org">.org</option>
                    <option value=".xyz">.xyz</option>
                    <option value=".online">.online</option>
                    <option value=".site">.site</option>
                    <option value=".store">.store</option>
                    <option value=".live">.live</option>
                    <option value=".bet">.bet</option>
                    <option value=".vip">.vip</option>
                    <option value=".tech">.tech</option>
                    <option value=".bd">.bd</option>
                    <option value=".com.bd">.com.bd</option>
                  </select>
                </div>
              </div>

              {/* 2. Site Logo Upload */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? '২. সাইটের লোগো আপলোড করুন (Site Logo):' : '2. Upload Site Logo:'}
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex-1 flex items-center gap-2 px-3 py-2.5 bg-white border border-slate-300 rounded-xl cursor-pointer hover:bg-slate-50 transition-colors">
                    <Upload className="w-4 h-4 text-cyan-600 shrink-0" />
                    <span className="text-xs text-slate-600 truncate">
                      {siteLogoUrl ? (isBn ? 'লোগো ইমেজ যুক্ত হয়েছে ✓' : 'Logo File Selected ✓') : (isBn ? 'লোগো ফাইল নির্বাচন করুন (ঐচ্ছিক)' : 'Choose Logo Image (Optional)')}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                {siteLogoUrl && (
                  <div className="mt-2 flex items-center gap-2.5 p-2 bg-slate-50 border border-slate-200 rounded-xl">
                    <img src={siteLogoUrl} alt="Logo preview" className="w-8 h-8 object-contain rounded bg-white p-1 border border-slate-200 shrink-0" />
                    <span className="text-[11px] text-emerald-600 font-bold">{isBn ? 'লোগো প্রিভিউ প্রস্তুত' : 'Logo Preview Ready'}</span>
                  </div>
                )}
              </div>

              {/* 3. Admin Gmail */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? '৩. এডমিন জিমেইল (Admin Gmail): *' : '3. Admin Gmail: *'}
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-600" />
                  <input
                    type="email"
                    value={siteAdminEmail}
                    onChange={(e) => setSiteAdminEmail(e.target.value)}
                    placeholder={isBn ? "এডমিন জিমেইল লিখুন" : "Enter admin gmail"}
                    className="w-full pl-9 pr-3 py-2.5 text-xs bg-white border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    required
                  />
                </div>
              </div>

              {/* 4. Admin Password */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? '৪. এডমিন পাসওয়ার্ড (Admin Password): *' : '4. Admin Password: *'}
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-600" />
                  <input
                    type={showAdminPassword ? "text" : "password"}
                    value={siteAdminPassword}
                    onChange={(e) => setSiteAdminPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-10 py-2.5 text-xs bg-white border border-slate-300 rounded-xl text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminPassword(!showAdminPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                  >
                    {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* 5. Phone Number */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? '৫. আপনার ফোন নাম্বার (Phone Number): *' : '5. Phone Number: *'}
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-600" />
                  <input
                    type="tel"
                    value={sitePhone}
                    onChange={(e) => setSitePhone(e.target.value)}
                    placeholder="017XXXXXXXX"
                    className="w-full pl-9 pr-3 py-2.5 text-xs bg-white border border-slate-300 rounded-xl text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                    required
                  />
                </div>
              </div>

              {/* WALLET BALANCE & PAYMENT SUMMARY BOX */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2 font-bold text-slate-800">
                    <Wallet className="w-4 h-4 text-cyan-600" />
                    <span>{isBn ? 'আপনার ওয়ালেট ব্যালেন্স:' : 'Wallet Balance:'}</span>
                  </div>
                  <span className={`font-black text-sm px-2.5 py-1 rounded-lg border ${
                    hasSufficientBalance
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : 'bg-rose-50 text-rose-700 border-rose-200'
                  }`}>
                    ৳ {userBalance.toLocaleString()}
                  </span>
                </div>

                {!hasSufficientBalance ? (
                  <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl space-y-2 text-amber-900">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-1.5">
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold text-xs text-amber-900">
                            {isBn ? `ওয়ালেটে ৳${Math.max(0, finalPrice - userBalance)} টাকা কম আছে` : `Need ৳${Math.max(0, finalPrice - userBalance)} more`}
                          </p>
                          <p className="text-[11px] text-amber-800 leading-relaxed mt-0.5">
                            {isBn
                              ? `অর্ডার করতে আগে টাকা ডিপোজিট করুন (প্রয়োজন ৳${finalPrice})`
                              : `Please deposit funds to proceed (Required ৳${finalPrice})`}
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setIsAddMoneyModalOpen(true)}
                        className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white font-bold text-[11px] rounded-lg transition-all shrink-0 cursor-pointer shadow-xs active:scale-95 flex items-center gap-1"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        <span>{isBn ? 'টাকা এড করুন' : 'Add Money'}</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-[11px] font-semibold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{isBn ? `ওয়ালেট থেকে সরাসরি ৳${finalPrice} কেটে নেওয়া হবে।` : `৳${finalPrice} will be deducted directly from wallet.`}</span>
                  </div>
                )}
              </div>

              {/* CONFIRM ORDER SUBMIT BUTTON */}
              <div className="pt-1">
                {hasSufficientBalance ? (
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-black text-sm uppercase tracking-wider rounded-xl shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2.5 cursor-pointer active:scale-95 disabled:opacity-60"
                  >
                    {isSubmitting ? (
                      <span className="animate-pulse">{isBn ? 'অর্ডার প্রসেস হচ্ছে...' : 'Processing Order...'}</span>
                    ) : (
                      <>
                        <Zap className="w-5 h-5 text-amber-300 fill-amber-300 stroke-[2]" />
                        <span>{isBn ? `অর্ডার কনফার্ম করুন (৳${finalPrice})` : `Confirm Order (৳${finalPrice})`}</span>
                      </>
                    )}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setIsAddMoneyModalOpen(true)}
                    className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-black text-sm uppercase tracking-wider rounded-xl shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2.5 cursor-pointer active:scale-95"
                  >
                    <PlusCircle className="w-5 h-5" />
                    <span>{isBn ? `পর্যাপ্ত টাকা নেই - ৳${Math.max(0, finalPrice - userBalance)} এড করুন` : `Insufficient Balance - Deposit ৳${Math.max(0, finalPrice - userBalance)}`}</span>
                  </button>
                )}
              </div>

            </form>
          ) : null}

          {/* STEP 3: Thank You / Success Confirmation Screen */}
          {step === 3 && (
            <div className="py-4 space-y-5 text-center animate-fade-in">
              <div className="relative inline-flex items-center justify-center">
                <div className="absolute inset-0 rounded-full bg-emerald-100 animate-ping" />
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-xl border-2 border-emerald-300 z-10">
                  <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-black text-slate-900">
                  {isBn ? '🎉 ধন্যবাদ! আপনার অর্ডারটি কনফার্ম হয়েছে' : '🎉 Thank You! Your Order Has Been Placed'}
                </h3>
                <p className="text-xs text-emerald-800 font-semibold mt-1.5 max-w-sm mx-auto leading-relaxed bg-emerald-50 border border-emerald-200 p-3 rounded-xl">
                  {isBn
                    ? 'আপনার অর্ডারটা কনফার্ম হয়েছে। কিছুক্ষণের মধ্যে আপনার অর্ডার সম্পূর্ণ কনফার্ম ও প্রসেস হয়ে যাবে।'
                    : 'Thank you! Your order is confirmed and will be processed shortly.'}
                </p>
              </div>

              {/* Order Summary Receipt Box */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl text-left space-y-2.5 text-xs">
                <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                  <span className="text-slate-500 font-semibold">{isBn ? 'অর্ডার নম্বর / ID:' : 'Order ID:'}</span>
                  <span className="font-mono font-black text-cyan-800 bg-cyan-50 px-2 py-0.5 rounded border border-cyan-200">
                    {completedOrder?.orderNumber || completedOrder?.id || 'ORD-SUCCESS'}
                  </span>
                </div>

                <div className="flex justify-between items-center text-slate-700">
                  <span className="text-slate-500">{isBn ? 'প্রোডাক্ট নাম:' : 'Product:'}</span>
                  <span className="font-bold text-slate-900 max-w-[200px] truncate">{isBn ? product.titleBn : product.titleEn}</span>
                </div>

                <div className="flex justify-between items-center text-slate-700">
                  <span className="text-slate-500">{isBn ? 'প্যাকেজ ভারিয়েন্ট:' : 'Package:'}</span>
                  <span className="font-bold text-emerald-600">{isBn ? variant.nameBn : variant.nameEn}</span>
                </div>

                <div className="flex justify-between items-center text-slate-700">
                  <span className="text-slate-500">{isBn ? 'মোট প্রদেয় টাকা:' : 'Total Amount:'}</span>
                  <span className="font-black text-emerald-600 text-sm">৳ {finalPrice}</span>
                </div>

                <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                  <span className="text-slate-500">{isBn ? 'অর্ডার স্ট্যাটাস:' : 'Status:'}</span>
                  <span className="font-bold text-xs bg-amber-100 text-amber-800 border border-amber-300 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                    <Clock className="w-3 h-3 animate-spin text-amber-600" />
                    {isBn ? 'প্রসেসিং (অপেক্ষমান)' : 'Processing (Pending Admin Confirmation)'}
                  </span>
                </div>
              </div>

              {/* Support & Instructions */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-left text-[11px] text-slate-600 space-y-1">
                <p className="font-bold text-slate-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  {isBn ? 'পরবর্তী তথ্য:' : 'Next Steps:'}
                </p>
                <p className="leading-relaxed">
                  {isBn
                    ? 'আপনার অর্ডারের বর্তমান অবস্থা এবং এডমিন কর্তৃক কনফার্মেশনের পর একাউন্ট তথ্য পেতে "আমার অর্ডার সমূহ" অপশন দেখুন।'
                    : 'Check your "Orders" tab to track order progress and credentials after admin confirmation.'}
                </p>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          {step !== 3 && (
            <button
              onClick={() => setSelectedProductForBuy(null)}
              className="w-full py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>
          )}

          {step === 3 && (
            <div className="w-full flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={() => {
                  if (completedOrder) {
                    setSelectedOrderForView(completedOrder);
                  }
                  setSelectedProductForBuy(null);
                  setActiveTab('orders');
                }}
                className="flex-1 py-2.5 px-4 bg-cyan-600 hover:bg-cyan-700 text-white font-black text-xs rounded-xl shadow-md transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{isBn ? 'আমার অর্ডার হিস্টোরি দেখুন' : 'View Order History'}</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedProductForBuy(null)}
                className="py-2.5 px-4 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                {isBn ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
