import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { X, Lock, User, Phone, Mail, ShieldCheck, ArrowRight, Code2, Eye, EyeOff } from 'lucide-react';
import { validateBangladeshiPhone, validateFullName, validateRealEmail } from '../utils/validation';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    registerUser,
    loginUser,
    language,
    addToast,
    siteConfig
  } = useStore();

  const [mode, setMode] = useState<'register' | 'login'>('register');
  const [fullName, setFullName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  if (!isAuthModalOpen) return null;

  const isBn = language === 'bn';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (mode === 'register') {
      const nameCheck = validateFullName(fullName);
      if (!nameCheck.isValid) {
        addToast(isBn ? (nameCheck.errorBn || 'সঠিক নাম লিখুন!') : (nameCheck.errorEn || 'Please enter valid name!'), 'error');
        return;
      }

      const phoneCheck = validateBangladeshiPhone(phone);
      if (!phoneCheck.isValid) {
        addToast(isBn ? (phoneCheck.errorBn || 'সঠিক মোবাইল নম্বর দিন!') : (phoneCheck.errorEn || 'Please enter valid BD phone!'), 'error');
        return;
      }

      const emailCheck = validateRealEmail(email);
      if (!emailCheck.isValid) {
        addToast(isBn ? (emailCheck.errorBn || 'সঠিক ইমেইল লিখুন!') : (emailCheck.errorEn || 'Please enter valid email!'), 'error');
        return;
      }

      if (!password || password.trim().length < 6) {
        addToast(isBn ? 'পাসওয়ার্ড সর্বনিম্ন ৬ ডিজিটের হতে হবে!' : 'Password must be at least 6 characters!', 'error');
        return;
      }

      const success = registerUser(fullName.trim(), phone.trim(), password.trim(), email.trim());
      if (success) {
        setIsAuthModalOpen(false);
      }
    } else {
      const cleanPhoneOrEmail = phone.trim();
      if (!cleanPhoneOrEmail) {
        addToast(isBn ? 'আপনার মোবাইল নম্বর বা ইমেইল লিখুন!' : 'Please enter your mobile number or email!', 'error');
        return;
      }

      if (!password || !password.trim()) {
        addToast(isBn ? 'আপনার পাসওয়ার্ড লিখুন!' : 'Please enter your password!', 'error');
        return;
      }

      const success = loginUser(cleanPhoneOrEmail, password.trim());
      if (success) {
        setIsAuthModalOpen(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-blue-50 via-indigo-50/50 to-white border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black shadow-md shrink-0 overflow-hidden">
              {siteConfig?.logoUrl ? (
                <img src={siteConfig.logoUrl} alt="Logo" className="w-full h-full object-contain" />
              ) : (
                <Code2 className="w-5 h-5 text-white" />
              )}
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900 tracking-tight">
                {siteConfig?.siteName || 'XS BAZAR'} {mode === 'register' ? (isBn ? 'রেজিস্ট্রেশন' : 'Registration') : (isBn ? 'লগইন' : 'Login')}
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                {mode === 'register'
                  ? (isBn ? 'রিয়েল তথ্য দিয়ে অ্যাকাউন্ট তৈরি করুন' : 'Create account with real information')
                  : (isBn ? 'আপনার অ্যাকাউন্টে প্রবেশ করুন' : 'Access your account')}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-slate-50/80 shrink-0">
          <button
            type="button"
            onClick={() => setMode('register')}
            className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              mode === 'register'
                ? 'border-blue-600 text-blue-700 bg-white font-black shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            {isBn ? 'সাইন আপ করুন' : 'Sign Up'}
          </button>
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`flex-1 py-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              mode === 'login'
                ? 'border-blue-600 text-blue-700 bg-white font-black shadow-xs'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            {isBn ? 'লগইন করুন' : 'Already User? Login'}
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 space-y-4 bg-white overflow-y-auto">
          {/* Form Body */}
          <form onSubmit={handleSubmit} className="space-y-3.5">
            
            {mode === 'register' && (
              <>
                <div>
                  <label className="text-xs font-black text-slate-700 block mb-1">
                    {isBn ? 'আপনার পূর্ণ নাম:' : 'Full Name:'}
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={isBn ? 'আপনার নাম লিখুন' : 'Enter your full name'}
                      className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium transition"
                      required={mode === 'register'}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-black text-slate-700 block mb-1">
                    {isBn ? 'আপনার জিমেইল / ইমেইল অ্যাড্রেস:' : 'Gmail / Email Address:'}
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="user@gmail.com"
                      className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-medium transition"
                      required={mode === 'register'}
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="text-xs font-black text-slate-700 block mb-1">
                {mode === 'register' 
                  ? (isBn ? 'মোবাইল নম্বর:' : 'Mobile Number:') 
                  : (isBn ? 'মোবাইল নম্বর অথবা ইমেইল:' : 'Mobile Number or Email:')}
              </label>
              <div className="relative">
                {mode === 'register' || !phone.includes('@') ? (
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                ) : (
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                )}
                <input
                  type={mode === 'register' ? 'tel' : 'text'}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder={mode === 'register' ? '018XXXXXXXX' : (isBn ? '018XXXXXXXX বা user@gmail.com' : '018XXXXXXXX or user@gmail.com')}
                  className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-slate-900 placeholder-slate-400 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-black text-slate-700 mb-1 flex items-center justify-between">
                <span>{isBn ? 'পাসওয়ার্ড (কমপক্ষে ৬ ডিজিট):' : 'Password (min 6 characters):'}</span>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-[11px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
                >
                  {showPassword ? (
                    <>
                      <EyeOff className="w-3.5 h-3.5" />
                      <span>{isBn ? 'পাসওয়ার্ড লুকান' : 'Hide'}</span>
                    </>
                  ) : (
                    <>
                      <Eye className="w-3.5 h-3.5" />
                      <span>{isBn ? 'পাসওয়ার্ড দেখুন' : 'Show'}</span>
                    </>
                  )}
                </button>
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={showPassword ? 'আপনার পাসওয়ার্ড' : '••••••••'}
                  className="w-full pl-9 pr-10 py-2.5 text-xs bg-slate-50 border border-slate-200 focus:bg-white rounded-xl text-slate-900 placeholder-slate-400 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer p-1"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4 text-blue-600" /> : <Eye className="w-4 h-4 text-slate-400" />}
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <span>{mode === 'register' ? (isBn ? 'অ্যাকাউন্ট তৈরি করুন' : 'Create Account Now') : (isBn ? 'লগইন করুন' : 'Login Now')}</span>
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </button>
            </div>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 pt-1 font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{isBn ? '১০০% তথ্য সুরক্ষিত ও গোপনীয়' : '100% Secured & Encrypted'}</span>
            </div>

          </form>

        </div>

      </div>
    </div>
  );
};
