import React, { useState } from 'react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';
import {
  X,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  ShoppingBag,
  Zap,
  ShieldCheck,
  Eye,
  Sparkles,
  CheckCircle2,
  Maximize2
} from 'lucide-react';

interface ProductDemoModalProps {
  product: Product;
  onClose: () => void;
}

export const ProductDemoModal: React.FC<ProductDemoModalProps> = ({
  product,
  onClose
}) => {
  const { language, setSelectedProductForBuy, isUserLoggedIn, setIsAuthModalOpen, addToast } = useStore();
  const isBn = language === 'bn';

  // Default demo images if not specifically provided
  const demoImages = product.demoImages && product.demoImages.length > 0
    ? product.demoImages
    : [
        product.imageUrl,
        'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1596838132731-3301c3fd431b?w=800&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80'
      ];

  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [isFullScreen, setIsFullScreen] = useState<boolean>(false);

  const handlePrev = () => {
    setActiveIndex((prev) => (prev === 0 ? demoImages.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setActiveIndex((prev) => (prev === demoImages.length - 1 ? 0 : prev + 1));
  };

  const handleBuyClick = () => {
    onClose();
    if (!isUserLoggedIn) {
      addToast(
        isBn
          ? 'অর্ডার সম্পন্ন করতে দয়া করে রেজিস্ট্রেশন/লগইন করুন।'
          : 'Please register or login to place an order.',
        'info'
      );
      setIsAuthModalOpen(true);
      return;
    }
    setSelectedProductForBuy(product);
  };

  const startingPrice = product.variants[0]?.price || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/90 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/30 text-cyan-400 shrink-0">
              <Eye className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                  {isBn ? 'ডেমো প্রিভিউ' : 'Demo Preview'}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  {activeIndex + 1} / {demoImages.length}
                </span>
              </div>
              <h3 className="text-xs sm:text-sm font-black text-white truncate mt-0.5">
                {isBn ? product.titleBn : product.titleEn}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          
          {/* Main Screenshot Carousel Viewer */}
          <div className="relative w-full bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 aspect-video sm:aspect-[16/9] group flex items-center justify-center">
            <img
              src={demoImages[activeIndex]}
              alt={`Demo preview ${activeIndex + 1}`}
              className="w-full h-full object-contain transition-all duration-300"
            />

            {/* Navigation Arrows */}
            {demoImages.length > 1 && (
              <>
                <button
                  onClick={handlePrev}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-slate-950/80 hover:bg-slate-900 text-white border border-slate-800 backdrop-blur shadow-lg transition active:scale-95 cursor-pointer opacity-90 group-hover:opacity-100"
                  title="Previous image"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={handleNext}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-slate-950/80 hover:bg-slate-900 text-white border border-slate-800 backdrop-blur shadow-lg transition active:scale-95 cursor-pointer opacity-90 group-hover:opacity-100"
                  title="Next image"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            )}

            {/* Full Screen Button */}
            <button
              onClick={() => setIsFullScreen(true)}
              className="absolute top-3 right-3 p-2 rounded-xl bg-slate-950/80 hover:bg-slate-900 text-slate-200 border border-slate-800 backdrop-blur transition cursor-pointer opacity-80 hover:opacity-100"
              title="Expand View"
            >
              <Maximize2 className="w-4 h-4" />
            </button>

            {/* Live Demo Website Button Overlay Badge */}
            {product.demoUrl && (
              <a
                href={product.demoUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="absolute bottom-3 left-3 px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center gap-1.5 transition active:scale-95"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>{isBn ? 'লাইব সাইট ডেমো দেখুন' : 'Live Website Demo'}</span>
              </a>
            )}
          </div>

          {/* Thumbnails Row */}
          {demoImages.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
              {demoImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveIndex(idx)}
                  className={`relative w-20 sm:w-24 h-14 rounded-xl overflow-hidden border-2 transition-all cursor-pointer shrink-0 bg-slate-950 ${
                    activeIndex === idx
                      ? 'border-cyan-400 ring-2 ring-cyan-500/30 scale-105'
                      : 'border-slate-800 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={img}
                    alt={`Thumb ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                  {activeIndex === idx && (
                    <div className="absolute inset-0 bg-cyan-500/10" />
                  )}
                </button>
              ))}
            </div>
          )}

          {/* Product Info & Feature Summary */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>{isBn ? 'প্রোডাক্ট বিবরণ ও ফিচারসমূহ' : 'Product Features'}</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isBn ? product.shortDescBn : product.shortDescEn}
                </p>
              </div>

              <div className="text-right">
                <span className="text-xs text-slate-400 block">{isBn ? 'মূল্য শুরু:' : 'Starting Price:'}</span>
                <span className="text-lg font-black text-emerald-400">৳ {startingPrice.toLocaleString()}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {isBn ? product.descriptionBn : product.descriptionEn}
            </p>

            {/* Feature Highlights */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{isBn ? 'বিকাশ/নগদ অটো গেটওয়ে' : 'Auto Local Gateway'}</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{isBn ? 'ফুল অ্যাডমিন ড্যাশবোর্ড' : 'Full Admin Dashboard'}</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 flex items-center gap-1.5 col-span-2 sm:col-span-1">
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>{isBn ? product.warrantyBn : product.warrantyEn}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3">
          {product.demoUrl ? (
            <a
              href={product.demoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5"
            >
              <ExternalLink className="w-4 h-4 text-cyan-400" />
              <span>{isBn ? 'লাইভ ডেমো সাইট' : 'Live Demo Site'}</span>
            </a>
          ) : (
            <button
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              {isBn ? 'বন্ধ করুন' : 'Close'}
            </button>
          )}

          <button
            onClick={handleBuyClick}
            className="flex-1 py-2.5 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-xs rounded-xl shadow-lg shadow-blue-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>{isBn ? 'এখনই অর্ডার করুন (Buy Now)' : 'Order Now'}</span>
          </button>
        </div>

      </div>

      {/* Fullscreen Image Lightbox Modal */}
      {isFullScreen && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-2">
          <button
            onClick={() => setIsFullScreen(false)}
            className="absolute top-4 right-4 p-2 bg-slate-800 text-white rounded-full z-10 hover:bg-slate-700"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={demoImages[activeIndex]}
            alt="Fullscreen preview"
            className="max-w-full max-h-full object-contain"
          />
        </div>
      )}
    </div>
  );
};
