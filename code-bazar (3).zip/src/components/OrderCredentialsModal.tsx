import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import {
  X,
  Key,
  Copy,
  Check,
  ShieldCheck,
  Calendar,
  Info,
  Clock,
  Download,
  LifeBuoy,
  Zap,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';

export const OrderCredentialsModal: React.FC = () => {
  const {
    selectedOrderForView,
    setSelectedOrderForView,
    language,
    claimWarranty,
    addToast,
    siteConfig
  } = useStore();

  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [showWarrantyInput, setShowWarrantyInput] = useState<boolean>(false);
  const [warrantyReason, setWarrantyReason] = useState<string>('');

  if (!selectedOrderForView) return null;

  const order = selectedOrderForView;
  const isBn = language === 'bn';
  const creds = order.credentials || {};

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    addToast(isBn ? `${fieldName} কপি করা হয়েছে!` : `Copied ${fieldName}!`, 'success');
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleCopyAll = () => {
    let formattedText = `CODE BAZAR ORDER CREDENTIALS\nOrder ID: ${order.orderNumber}\nProduct: ${order.productTitleEn}\n`;
    if (creds.email) formattedText += `Email: ${creds.email}\n`;
    if (creds.password) formattedText += `Password: ${creds.password}\n`;
    if (creds.pin) formattedText += `Profile PIN: ${creds.pin}\n`;
    if (creds.profileName) formattedText += `Profile Name: ${creds.profileName}\n`;
    if (creds.licenseKey) formattedText += `Key/Link: ${creds.licenseKey}\n`;
    formattedText += `Expiry: ${order.expiryDate}\nWarranty: 30 Days Replacement`;

    navigator.clipboard.writeText(formattedText);
    addToast(isBn ? 'সমস্ত একাউন্ট ইনফো কপি করা হয়েছে!' : 'All credentials copied!', 'success');
  };

  const handleDownloadTxt = () => {
    let formattedText = `===================================\n      CODE BAZAR DIGITAL CREDENTIALS\n===================================\nOrder ID : ${order.orderNumber}\nProduct  : ${order.productTitleEn}\nVariant  : ${order.variantNameEn}\n`;
    if (creds.email) formattedText += `Email    : ${creds.email}\n`;
    if (creds.password) formattedText += `Password : ${creds.password}\n`;
    if (creds.pin) formattedText += `PIN      : ${creds.pin}\n`;
    if (creds.profileName) formattedText += `Profile  : ${creds.profileName}\n`;
    if (creds.licenseKey) formattedText += `License  : ${creds.licenseKey}\n`;
    formattedText += `Expiry   : ${order.expiryDate}\n\nINSTRUCTIONS:\n${order.instructionsEn}\n`;

    const blob = new Blob([formattedText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${order.orderNumber}_Credentials.txt`;
    link.click();
  };

  const handleWarrantySubmit = () => {
    if (!warrantyReason.trim()) {
      addToast(isBn ? 'সমস্যার কারণ বিস্তার লিখুন।' : 'Please specify the issue.', 'error');
      return;
    }
    claimWarranty(order.id, warrantyReason);
    setShowWarrantyInput(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl border ${order.status === 'processing' ? 'bg-amber-100 border-amber-300 text-amber-800' : 'bg-emerald-100 border-emerald-300 text-emerald-800'}`}>
              <Key className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900">{isBn ? 'ডিজিটাল অ্যাকাউন্টের বিবরণ' : 'Digital Credentials & Key'}</h3>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  order.status === 'processing' 
                    ? 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse' 
                    : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                }`}>
                  {order.status === 'processing' ? (isBn ? 'প্রসেসিং (অপেক্ষমান)' : 'PROCESSING') : (isBn ? 'কনফার্মকৃত (ACTIVE)' : 'ACTIVE')}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-mono">{order.orderNumber}</p>
            </div>
          </div>

          <button
            onClick={() => setSelectedOrderForView(null)}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Credentials Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          
          {/* Item Header */}
          <div className="flex items-center gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
            <img
              src={order.productImage}
              alt={order.productTitleEn}
              className="w-12 h-12 object-cover rounded-lg border border-slate-200 shadow-sm"
            />
            <div className="flex-1">
              <h4 className="text-sm font-bold text-slate-900">{isBn ? order.productTitleBn : order.productTitleEn}</h4>
              <p className="text-xs text-cyan-700 font-semibold">{isBn ? order.variantNameBn : order.variantNameEn}</p>
            </div>
            <div className="text-right">
              <span className="text-xs font-bold text-emerald-600 block">৳ {order.price}</span>
              <span className="text-[10px] text-slate-500">{order.purchaseDate}</span>
            </div>
          </div>

          {/* Submitted Site Details */}
          {(order.siteName || order.siteAdminEmail) && (
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1.5">
              <span className="text-[11px] font-bold text-slate-600 block border-b border-slate-200 pb-1">
                {isBn ? 'আপনার সাবমিটকৃত সাইট তথ্য:' : 'Submitted Site Details:'}
              </span>
              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono pt-0.5">
                {order.siteName && (
                  <div>
                    <span className="text-slate-500 block text-[10px]">{isBn ? 'সাইটের নাম:' : 'Site Name:'}</span>
                    <span className="text-slate-900 font-bold">{order.siteName}</span>
                  </div>
                )}
                {order.sitePhone && (
                  <div>
                    <span className="text-slate-500 block text-[10px]">{isBn ? 'মোবাইল নাম্বার:' : 'Phone:'}</span>
                    <span className="text-slate-900 font-bold">{order.sitePhone}</span>
                  </div>
                )}
                {order.siteAdminEmail && (
                  <div>
                    <span className="text-slate-500 block text-[10px]">{isBn ? 'এডমিন জিমেইল:' : 'Admin Gmail:'}</span>
                    <span className="text-cyan-700 font-bold">{order.siteAdminEmail}</span>
                  </div>
                )}
                {order.siteAdminPassword && (
                  <div>
                    <span className="text-slate-500 block text-[10px]">{isBn ? 'এডমিন পাসওয়ার্ড:' : 'Admin Password:'}</span>
                    <span className="text-emerald-700 font-bold">{order.siteAdminPassword}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* If Processing: Show Pending Status Box */}
          {order.status === 'processing' ? (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-2 text-center">
              <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto border border-amber-300 animate-pulse">
                <Clock className="w-5 h-5 animate-spin" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-amber-900">
                  {isBn ? 'আপনার অর্ডারটি প্রসেসিং অবস্থায় রয়েছে' : 'Order Processing in Progress'}
                </h4>
              </div>
            </div>
          ) : (
            /* Credentials Card Box when Active */
            <div className="p-4 bg-gradient-to-br from-slate-50 via-white to-slate-50 border border-cyan-300 rounded-2xl space-y-3 relative overflow-hidden shadow-sm">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <span className="text-xs font-bold text-cyan-800 flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                  {isBn ? 'আপনার অ্যাক্সেস ও লগইন তথ্য:' : 'Your Login / Key Details:'}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyAll}
                    className="px-2.5 py-1 text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg flex items-center gap-1 border border-slate-300 cursor-pointer"
                  >
                    <Copy className="w-3 h-3 text-cyan-600" />
                    <span>{isBn ? 'কপি অল' : 'Copy All'}</span>
                  </button>
                  <button
                    onClick={handleDownloadTxt}
                    className="px-2.5 py-1 text-[11px] font-bold bg-cyan-100 hover:bg-cyan-200 text-cyan-800 rounded-lg flex items-center gap-1 border border-cyan-300 cursor-pointer"
                  >
                    <Download className="w-3 h-3 text-cyan-700" />
                    <span>TXT</span>
                  </button>
                </div>
              </div>

              {/* Email Field */}
              {creds.email && (
                <div className="flex items-center justify-between bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 font-medium block uppercase tracking-wider">{isBn ? 'ইমেইল / ইউজারনেম' : 'Email / Username'}</span>
                    <span className="text-xs font-mono font-bold text-slate-900 select-all">{creds.email}</span>
                  </div>
                  <button
                    onClick={() => handleCopy(creds.email!, 'Email')}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-cyan-700 cursor-pointer"
                  >
                    {copiedField === 'Email' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              )}

              {/* Password Field */}
              {creds.password && (
                <div className="flex items-center justify-between bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 font-medium block uppercase tracking-wider">{isBn ? 'পাসওয়ার্ড' : 'Password'}</span>
                    <span className="text-xs font-mono font-bold text-emerald-700 select-all">{creds.password}</span>
                  </div>
                  <button
                    onClick={() => handleCopy(creds.password!, 'Password')}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-cyan-700 cursor-pointer"
                  >
                    {copiedField === 'Password' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              )}

              {/* PIN / Profile Field */}
              {(creds.pin || creds.profileName) && (
                <div className="grid grid-cols-2 gap-2">
                  {creds.profileName && (
                    <div className="bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs">
                      <span className="text-[10px] text-slate-500 block uppercase tracking-wider">{isBn ? 'প্রোফাইল নেম' : 'Profile Name'}</span>
                      <span className="text-xs font-bold text-amber-800">{creds.profileName}</span>
                    </div>
                  )}
                  {creds.pin && (
                    <div className="flex items-center justify-between bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 block uppercase tracking-wider">{isBn ? 'প্রোফাইল পিন' : 'Profile PIN'}</span>
                        <span className="text-xs font-mono font-extrabold text-amber-800">{creds.pin}</span>
                      </div>
                      <button
                        onClick={() => handleCopy(creds.pin!, 'PIN')}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-cyan-700 cursor-pointer"
                      >
                        {copiedField === 'PIN' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* License Key / Invite Link */}
              {creds.licenseKey && (
                <div className="flex items-center justify-between bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs">
                  <div className="overflow-hidden flex-1 mr-2">
                    <span className="text-[10px] text-slate-500 block uppercase tracking-wider">{isBn ? 'লাইসেন্স কী / ইনভাইটেশন লিংক' : 'License Key / Invitation Link'}</span>
                    <span className="text-xs font-mono font-bold text-cyan-700 truncate block">{creds.licenseKey}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {creds.licenseKey.startsWith('http') && (
                      <a
                        href={creds.licenseKey}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg bg-cyan-100 text-cyan-800 hover:bg-cyan-200"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                    <button
                      onClick={() => handleCopy(creds.licenseKey!, 'License Key')}
                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-cyan-700 cursor-pointer"
                    >
                      {copiedField === 'License Key' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              )}

              {/* Additional Info */}
              {creds.additionalInfo && (
                <div className="bg-white border border-slate-200 p-2.5 rounded-xl shadow-xs">
                  <span className="text-[10px] text-slate-500 block uppercase tracking-wider">{isBn ? 'অতিরিক্ত ইনফরমেশন' : 'Additional Note'}</span>
                  <span className="text-xs text-slate-800">{creds.additionalInfo}</span>
                </div>
              )}

            </div>
          )}

          {/* Warranty & Support Contact Section */}
          {order.warrantyClaimed ? (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{isBn ? 'এই অর্ডারের জন্য সাপোর্ট রিকোয়েস্ট গ্রহণ করা হয়েছে। এডমিন বিষয়টি রিভিউ করছেন।' : 'Support request received for this order.'}</span>
            </div>
          ) : (
            <div className="space-y-2">
              <a
                href={`https://wa.me/${(() => {
                  const rawNum = (siteConfig?.whatsappNumber || '01836828065').replace(/\D/g, '');
                  return rawNum.startsWith('88') ? rawNum : '88' + rawNum;
                })()}?text=${encodeURIComponent(
                  `হ্যালো সাপোর্ট টিম, আমার অর্ডার নম্বর: ${order.orderNumber} (${order.productTitleEn}) নিয়ে সহায়তা বা আপডেট প্রয়োজন।`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
              >
                <LifeBuoy className="w-4 h-4 text-white" />
                <span>
                  {isBn
                    ? 'অর্ডারে সাহায্য বা সমস্যা? সরাসরি হোয়াটসঅ্যাপ সাপোর্টে কথা বলুন'
                    : 'Need help with this order? Contact WhatsApp Support'}
                </span>
              </a>

              {!showWarrantyInput ? (
                <button
                  onClick={() => setShowWarrantyInput(true)}
                  className="w-full py-1.5 text-slate-500 hover:text-slate-800 text-[11px] font-medium underline text-center cursor-pointer block"
                >
                  {isBn ? 'অথবা ওয়েবসাইট মেসেজ দিয়ে এডমিনকে ইস্যু জানান' : 'Or send inline message to admin'}
                </button>
              ) : (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                  <span className="font-bold text-slate-700 block">{isBn ? 'অর্ডারের সমস্যার মেসেজ লিখুন:' : 'Describe Order Issue:'}</span>
                  <input
                    type="text"
                    value={warrantyReason}
                    onChange={(e) => setWarrantyReason(e.target.value)}
                    placeholder={isBn ? 'e.g. পাসওয়ার্ড পরিবর্তন বা কনফিগারেশন আপডেট সহায়তা' : 'e.g. Password update support needed'}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  />
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      onClick={() => setShowWarrantyInput(false)}
                      className="px-3 py-1 bg-slate-200 text-slate-700 text-xs rounded-md hover:bg-slate-300 cursor-pointer"
                    >
                      {isBn ? 'বাতিল' : 'Cancel'}
                    </button>
                    <button
                      onClick={handleWarrantySubmit}
                      className="px-3 py-1 bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs rounded-md cursor-pointer"
                    >
                      {isBn ? 'মেসেজ পাঠান' : 'Send Message'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
