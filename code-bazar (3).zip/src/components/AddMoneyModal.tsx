import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { PaymentMethod } from '../types';
import {
  X,
  Copy,
  Check,
  HelpCircle,
  Info,
  ArrowLeft,
  Hash
} from 'lucide-react';
import { validateTransactionId } from '../utils/validation';

// Brand Logo SVGs for authentic representation if no custom image is uploaded
const BkashLogoSVG: React.FC = () => (
  <div className="flex items-center gap-1.5 justify-center">
    <svg className="h-8 w-auto" viewBox="0 0 160 50" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M15 10L35 30L20 40L15 10Z" fill="#E2136E" />
      <path d="M35 30L55 10L40 38L35 30Z" fill="#D10056" />
      <path d="M35 30L25 5L15 10L35 30Z" fill="#FA2580" />
      <text x="60" y="34" fill="#E2136E" fontSize="26" fontWeight="900" fontFamily="sans-serif">bKash</text>
    </svg>
  </div>
);

const NagadLogoSVG: React.FC = () => (
  <div className="flex items-center gap-1.5 justify-center">
    <svg className="h-8 w-auto" viewBox="0 0 160 50" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="22" cy="25" r="18" fill="#F7921E" />
      <path d="M16 18C18 14 26 14 28 20C30 26 20 28 22 34C24 38 30 36 30 36" stroke="#FFFFFF" strokeWidth="4" strokeLinecap="round" fill="none" />
      <text x="48" y="34" fill="#F7921E" fontSize="24" fontWeight="900" fontFamily="sans-serif">নগদ</text>
    </svg>
  </div>
);

export const AddMoneyModal: React.FC = () => {
  const {
    isAddMoneyModalOpen,
    setIsAddMoneyModalOpen,
    language,
    addMoneyRequest,
    addToast,
    paymentNumbers,
    siteConfig,
    user,
    transactions
  } = useStore();

  const [step, setStep] = useState<1 | 2>(1);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('bkash');
  const [amount, setAmount] = useState<string>('');
  const [trxId, setTrxId] = useState<string>('');
  const [copiedNumber, setCopiedNumber] = useState<boolean>(false);
  const [copiedAmount, setCopiedAmount] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const isBn = language === 'bn';

  const isMethodEnabled = (method: PaymentMethod) => {
    if (method === 'bkash') return paymentNumbers.bkashEnabled ?? true;
    if (method === 'nagad') return paymentNumbers.nagadEnabled ?? true;
    return true;
  };

  const enabledMethods = (['bkash', 'nagad'] as PaymentMethod[]).filter(isMethodEnabled);

  useEffect(() => {
    if (enabledMethods.length > 0 && !enabledMethods.includes(selectedMethod)) {
      setSelectedMethod(enabledMethods[0]);
    }
  }, [paymentNumbers, selectedMethod]);

  if (!isAddMoneyModalOpen) return null;

  const methodDetails: Record<
    PaymentMethod,
    {
      number: string;
      brandName: string;
      displayName: string;
      logoUrl?: string;
      renderDefaultLogo: () => JSX.Element;
    }
  > = {
    bkash: {
      number: paymentNumbers.bkash || '01879940191',
      brandName: 'bKash',
      displayName: 'Bkash Personal',
      logoUrl: paymentNumbers.bkashLogo,
      renderDefaultLogo: () => <BkashLogoSVG />
    },
    nagad: {
      number: paymentNumbers.nagad || '01879940191',
      brandName: 'Nagad',
      displayName: 'Nagad Personal',
      logoUrl: paymentNumbers.nagadLogo,
      renderDefaultLogo: () => <NagadLogoSVG />
    }
  };

  const currentInfo = methodDetails[selectedMethod];

  const handleCopyNumber = () => {
    const cleanNum = currentInfo.number.split('-')[0].trim();
    navigator.clipboard.writeText(cleanNum);
    setCopiedNumber(true);
    addToast(isBn ? 'নম্বর কপি করা হয়েছে!' : 'Number copied!', 'success');
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleCopyAmount = () => {
    navigator.clipboard.writeText(amount);
    setCopiedAmount(true);
    addToast(isBn ? 'টাকার পরিমাণ কপি করা হয়েছে!' : 'Amount copied!', 'success');
    setTimeout(() => setCopiedAmount(false), 2000);
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      addToast(isBn ? 'যত টাকা পাঠাতে চান সেই পরিমাণটি লিখুন।' : 'Please enter the amount you want to deposit.', 'error');
      return;
    }
    setStep(2);
  };

  const handleSubmitDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);

    if (isNaN(numAmount) || numAmount <= 0) {
      addToast(isBn ? 'সঠিক টাকার পরিমাণ দিন।' : 'Enter valid deposit amount.', 'error');
      setStep(1);
      return;
    }

    // Validate Real Transaction ID
    const existingTrxList = transactions.map((t) => t.trxId || '');
    const trxCheck = validateTransactionId(trxId, existingTrxList, selectedMethod);
    if (!trxCheck.isValid) {
      addToast(
        isBn ? (trxCheck.errorBn || '❌ ভুল বা অকার্যকর Transaction ID!') : (trxCheck.errorEn || '❌ Invalid Transaction ID!'),
        'error'
      );
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const senderPhoneToUse = user.phone || 'N/A';
      const ok = addMoneyRequest(numAmount, selectedMethod, senderPhoneToUse, trxCheck.normalizedTrx);
      setIsSubmitting(false);
      if (ok) {
        setIsAddMoneyModalOpen(false);
        setTrxId('');
        setStep(1);
      }
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-white text-slate-900 border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* STEP 1: Gateway Selection */}
        {step === 1 ? (
          <form onSubmit={handleNextStep} className="p-4 sm:p-5 overflow-y-auto space-y-4">
            
            {/* Header with Store Logo & Title */}
            <div className="text-center pt-1 pb-1 relative">
              <button
                type="button"
                onClick={() => {
                  setIsAddMoneyModalOpen(false);
                  setStep(1);
                }}
                className="absolute top-0 right-0 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Center Logo Circle */}
              <div className="w-20 h-20 mx-auto rounded-full border-2 border-blue-400 bg-white p-1 shadow-md flex items-center justify-center overflow-hidden">
                {siteConfig?.logoUrl ? (
                  <img src={siteConfig.logoUrl} alt="Store Logo" className="w-full h-full object-contain rounded-full" />
                ) : (
                  <div className="w-full h-full rounded-full bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white font-black text-xl">
                    XS
                  </div>
                )}
              </div>

              <h3 className="text-xl font-black text-slate-800 mt-2">
                {siteConfig?.siteName || 'XS BAZAR'}
              </h3>

              {/* 2 Action Buttons */}
              <div className="flex items-center justify-center gap-3 mt-2.5">
                <button
                  type="button"
                  onClick={() => {
                    addToast(isBn ? 'যেকোনো সমস্যায় সেন্ড মানি করার পর TrxID দিয়ে VERIFY করুন।' : 'Send money then enter TrxID to verify.', 'info');
                  }}
                  title="Help"
                  className="p-2.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-600 text-slate-700 rounded-full border border-slate-200 transition cursor-pointer"
                >
                  <HelpCircle className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    addToast(isBn ? 'ডিপোজিট করার পর অ্যাডমিন যাচাই করে আপনার ব্যালেন্সে টাকা যুক্ত করবেন।' : 'Admin will verify deposit and add balance.', 'info');
                  }}
                  title="Info"
                  className="p-2.5 bg-slate-100 hover:bg-blue-50 hover:text-blue-600 text-slate-700 rounded-full border border-slate-200 transition cursor-pointer"
                >
                  <Info className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Deposit Amount Input */}
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-2.5">
              <div className="flex justify-between items-center text-xs font-bold text-slate-700">
                <span>{isBn ? 'যত টাকা পাঠাবেন লিখুন (BDT):' : 'Enter Amount to Deposit (BDT):'}</span>
                {amount && <span className="text-blue-600 font-mono font-black text-sm">৳{amount} BDT</span>}
              </div>

              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-black text-slate-400 text-lg">৳</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder={isBn ? "টাকার পরিমাণ লিখুন" : "Enter amount"}
                  className="w-full pl-9 pr-3.5 py-3 text-center text-xl font-black bg-white border-2 border-slate-300 focus:border-blue-500 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 shadow-xs placeholder:text-slate-400 placeholder:text-sm placeholder:font-medium"
                  required
                />
              </div>
            </div>

            {/* Green Header Banner */}
            <div className="bg-emerald-700 text-white font-black text-xs sm:text-sm py-2.5 px-4 rounded-xl text-center shadow-xs uppercase tracking-wide">
              {isBn ? 'পেমেন্ট মেথড সিলেক্ট করুন' : 'Select Payment Method'}
            </div>

            {/* Payment Gateway Grid */}
            <div className="grid grid-cols-2 gap-3">
              {enabledMethods.length === 0 ? (
                <div className="col-span-2 p-4 bg-rose-50 border border-rose-200 rounded-2xl text-center text-rose-700 text-xs font-bold space-y-2">
                  <p>{isBn ? 'বর্তমানে সকল পেমেন্ট গেটওয়ে নিষ্ক্রিয় আছে।' : 'All payment gateways are currently disabled.'}</p>
                  <p className="text-[11px] text-slate-600">{isBn ? 'সরাসরি হোয়াটসঅ্যাপে যোগাযোগ করুন।' : 'Please contact admin via WhatsApp support.'}</p>
                </div>
              ) : (
                enabledMethods.map((method) => {
                  const isSelected = selectedMethod === method;
                  const details = methodDetails[method];
                  return (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setSelectedMethod(method)}
                      className={`rounded-2xl border-2 overflow-hidden transition-all duration-200 flex flex-col items-center cursor-pointer relative bg-white ${
                        isSelected
                          ? 'border-blue-600 ring-2 ring-blue-500/40 shadow-md scale-[1.02]'
                          : 'border-slate-200 hover:border-slate-300 hover:shadow-sm'
                      }`}
                    >
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center z-10 shadow-sm">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}

                      {/* Logo Section */}
                      <div className="w-full py-4 px-2 flex items-center justify-center min-h-[72px] bg-white border-b border-slate-100">
                        {details.logoUrl ? (
                          <img src={details.logoUrl} alt={details.brandName} className="h-9 object-contain max-w-[130px]" />
                        ) : (
                          details.renderDefaultLogo()
                        )}
                      </div>

                      {/* Label Section */}
                      <div className={`w-full py-2 px-1 text-center font-bold text-xs ${
                        isSelected ? 'bg-blue-50 text-blue-800' : 'bg-slate-50 text-slate-700'
                      }`}>
                        {details.displayName}
                      </div>
                    </button>
                  );
                })
              )}
            </div>

            {/* Submit Action Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-base uppercase tracking-wider rounded-2xl shadow-lg shadow-blue-500/20 transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{isBn ? (amount ? `৳${amount} পেমেন্ট করতে এগিয়ে যান` : 'পেমেন্টে এগিয়ে যান') : `Pay ${amount ? `${amount} BDT` : 'Now'}`}</span>
              </button>
            </div>

          </form>
        ) : (
          /* STEP 2: Instruction & TrxID Verification */
          <form onSubmit={handleSubmitDeposit} className="p-4 sm:p-5 overflow-y-auto space-y-3.5">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full border-2 border-blue-400 bg-white p-0.5 shadow-sm flex items-center justify-center overflow-hidden">
                  {siteConfig?.logoUrl ? (
                    <img src={siteConfig.logoUrl} alt="Store Logo" className="w-full h-full object-contain rounded-full" />
                  ) : (
                    <div className="w-full h-full rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center">
                      XS
                    </div>
                  )}
                </div>
                <span className="font-black text-base text-slate-800">{siteConfig?.siteName || 'XS BAZAR'}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddMoneyModalOpen(false);
                    setStep(1);
                  }}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Amount Badge */}
            <div className="py-2.5 px-4 bg-slate-50 border border-slate-200 rounded-2xl text-center shadow-inner">
              <span className="text-2xl sm:text-3xl font-black text-slate-800 font-mono tracking-tight">
                {amount} BDT
              </span>
            </div>

            {/* Step-by-Step Payment Instructions */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-2.5 text-xs sm:text-sm text-slate-800 leading-relaxed shadow-sm">
              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-bold text-base leading-none">•</span>
                <div>
                  আপনার <strong className="font-black text-slate-900">{currentInfo.brandName}</strong> মোবাইল অ্যাপে যান।
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-bold text-base leading-none">•</span>
                <div>
                  <strong className="font-black text-slate-900">Send Money</strong> -এ ক্লিক করুন।
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-bold text-base leading-none">•</span>
                <div className="flex flex-wrap items-center gap-1.5">
                  <span>প্রাপক নম্বর হিসেবে এই নম্বরটি লিখুন:</span>
                  <span className="font-mono font-black text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    {currentInfo.number}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyNumber}
                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md shadow-sm transition flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    {copiedNumber ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedNumber ? 'কপি হয়েছে' : 'কপি করুন'}</span>
                  </button>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-bold text-base leading-none">•</span>
                <div className="flex flex-wrap items-center gap-1.5">
                  <span>টাকার পরিমাণ:</span>
                  <span className="font-mono font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {amount}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyAmount}
                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-md shadow-sm transition flex items-center gap-1 cursor-pointer active:scale-95"
                  >
                    {copiedAmount ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedAmount ? 'কপি হয়েছে' : 'কপি করুন'}</span>
                  </button>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-bold text-base leading-none">•</span>
                <div>
                  নিশ্চিত করতে এখন আপনার <strong className="font-black text-slate-900">{currentInfo.brandName}</strong> পিন লিখুন।
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="text-blue-600 font-bold text-base leading-none">•</span>
                <div>
                  সেন্ড মানি সফল হলে আপনার <strong className="font-black text-blue-600">Transaction ID (TrxID)</strong> নিচের বক্সে লিখে Verify বাটনে ক্লিক করুন।
                </div>
              </div>
            </div>

            {/* Transaction ID Input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-black text-slate-800">
                {isBn ? 'Transaction ID (TrxID):' : 'Transaction ID (TrxID):'}
              </label>

              <div className="relative">
                <Hash className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value.toUpperCase())}
                  placeholder={isBn ? 'ট্রানজেকশন আইডি লিখুন' : 'Enter Transaction ID'}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border-2 border-slate-300 focus:border-blue-500 focus:bg-white rounded-xl font-mono font-black text-slate-900 uppercase placeholder-slate-400 focus:outline-none text-base transition shadow-xs"
                  required
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 space-y-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-base uppercase tracking-wider rounded-2xl shadow-lg transition active:scale-95 cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isSubmitting ? (
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>{isBn ? 'যাচাই করা হচ্ছে...' : 'Verifying...'}</span>
                  </div>
                ) : (
                  <span>VERIFY DEPOSIT</span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setStep(1)}
                className="w-full py-2 text-xs font-bold text-slate-500 hover:text-slate-800 transition cursor-pointer flex items-center justify-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{isBn ? 'মেথড বা অ্যামাউন্ট পরিবর্তন করুন' : 'Change Method or Amount'}</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};


