import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import {
  User,
  ArrowLeftRight,
  ShoppingCart,
  Wallet,
  Headphones,
  X,
  LogOut,
  Copy,
  Check,
  ShieldCheck,
  Calendar,
  Phone,
  Mail,
  XCircle
} from 'lucide-react';

export const ProfileDrawer: React.FC = () => {
  const {
    isProfileDrawerOpen,
    setIsProfileDrawerOpen,
    user,
    logoutUser,
    setActiveTab,
    setIsAddMoneyModalOpen,
    language,
    siteConfig,
    addToast
  } = useStore();

  const [showProfileDetails, setShowProfileDetails] = useState<boolean>(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  if (!isProfileDrawerOpen) return null;

  const isBn = language === 'bn';

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    addToast(isBn ? `${label} কপি করা হয়েছে` : `${label} copied`, 'success');
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleLogout = () => {
    logoutUser();
    setIsProfileDrawerOpen(false);
    addToast(isBn ? 'সফলভাবে লগআউট করা হয়েছে।' : 'Successfully logged out.', 'info');
  };

  const handleOpenSupport = () => {
    const rawNum = (siteConfig?.whatsappNumber || '01836828065').replace(/\D/g, '');
    const cleanWaNumber = rawNum.startsWith('88') ? rawNum : '88' + rawNum;
    const waUrl = `https://wa.me/${cleanWaNumber}?text=${encodeURIComponent('হেলো ' + (siteConfig?.siteName || 'XS BAZAR') + ', প্রোফাইল অ্যাকাউন্ট সাপোর্ট প্রয়োজন।')}`;
    window.open(waUrl, '_blank');
    setIsProfileDrawerOpen(false);
  };

  const username = user.email ? user.email.split('@')[0] : (user.phone || 'user007');

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-xs animate-fade-in">
      {/* Background overlay click to close */}
      <div
        className="fixed inset-0"
        onClick={() => setIsProfileDrawerOpen(false)}
      />

      {/* Slide-over Drawer Panel */}
      <div className="relative w-[300px] sm:w-[340px] max-w-[85vw] h-full bg-white text-slate-800 shadow-2xl flex flex-col z-10 animate-slide-in-right overflow-y-auto">
        
        {/* Drawer Header with Close button & Watermark */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-blue-600 text-white font-black text-xs flex items-center justify-center shadow-sm">
              {siteConfig?.siteName ? siteConfig.siteName.charAt(0) : 'X'}
            </div>
            <span className="font-black text-slate-800 text-sm tracking-tight">
              {siteConfig?.siteName || 'XS BAZAR'}
            </span>
          </div>

          <button
            onClick={() => setIsProfileDrawerOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Info Header Section */}
        <div className="p-5 border-b border-slate-100 flex items-start gap-3.5 bg-gradient-to-b from-blue-50/40 to-white">
          {/* Avatar Circle */}
          <div className="w-14 h-14 rounded-full bg-slate-700 text-white font-bold text-2xl flex items-center justify-center shrink-0 shadow-md border-2 border-white">
            {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
          </div>

          {/* User Details & Logout Button */}
          <div className="flex-1 min-w-0">
            <h4 className="font-black text-slate-900 text-base truncate leading-tight">
              {username}
            </h4>
            <p className="text-xs text-slate-500 truncate mb-2 mt-0.5">
              {user.email || user.phone || 'user@example.com'}
            </p>

            <button
              onClick={handleLogout}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm transition active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{isBn ? 'লগআউট' : 'Logout'}</span>
            </button>
          </div>
        </div>

        {/* Menu Items List */}
        <div className="flex-1 p-3 space-y-1">
          
          {/* 1. My Profile */}
          <button
            onClick={() => setShowProfileDetails(!showProfileDetails)}
            className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl transition text-left cursor-pointer font-bold text-sm ${
              showProfileDetails
                ? 'bg-blue-50 text-blue-700 font-black'
                : 'text-slate-700 hover:bg-slate-100/80 hover:text-slate-900'
            }`}
          >
            <User className="w-5 h-5 text-slate-500" />
            <span>My Profile</span>
          </button>

          {/* Expandable Profile Info Details */}
          {showProfileDetails && (
            <div className="mx-2 my-1 p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs text-slate-700 animate-fade-in">
              <div className="flex justify-between items-center py-1 border-b border-slate-200/80">
                <span className="text-slate-500">{isBn ? 'নাম:' : 'Name:'}</span>
                <span className="font-bold text-slate-900">{user.name || 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-200/80">
                <span className="text-slate-500">{isBn ? 'ফোন:' : 'Phone:'}</span>
                <span className="font-mono font-bold text-slate-900">{user.phone || 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-200/80">
                <span className="text-slate-500">{isBn ? 'ইমেইল:' : 'Email:'}</span>
                <span className="font-mono font-bold text-slate-900 truncate max-w-[150px]">{user.email || 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-slate-500">{isBn ? 'ওয়ালেট ব্যালেন্স:' : 'Wallet:'}</span>
                <span className="font-mono font-black text-emerald-600 text-sm">৳{user.walletBalance.toLocaleString()}</span>
              </div>
            </div>
          )}

          {/* 2. Add Money */}
          <button
            onClick={() => {
              setIsProfileDrawerOpen(false);
              setIsAddMoneyModalOpen(true);
            }}
            className="w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-slate-700 hover:bg-slate-100/80 hover:text-slate-900 transition text-left cursor-pointer font-bold text-sm"
          >
            <ArrowLeftRight className="w-5 h-5 text-slate-500" />
            <span>Add Money</span>
          </button>

          {/* 3. My Orders */}
          <button
            onClick={() => {
              setIsProfileDrawerOpen(false);
              setActiveTab('orders');
            }}
            className="w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-slate-700 hover:bg-blue-50/80 hover:text-blue-700 transition text-left cursor-pointer font-bold text-sm"
          >
            <ShoppingCart className="w-5 h-5 text-slate-500" />
            <span>My Orders</span>
          </button>

          {/* 4. My Transaction */}
          <button
            onClick={() => {
              setIsProfileDrawerOpen(false);
              setActiveTab('wallet');
            }}
            className="w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-slate-700 hover:bg-slate-100/80 hover:text-slate-900 transition text-left cursor-pointer font-bold text-sm"
          >
            <Wallet className="w-5 h-5 text-slate-500" />
            <span>My Transactions</span>
          </button>
        </div>

        {/* Bottom Prominent Blue Support Button */}
        <div className="p-4 border-t border-slate-100 mt-auto bg-slate-50/50">
          <button
            onClick={handleOpenSupport}
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-base rounded-2xl shadow-lg shadow-blue-500/20 transition active:scale-95 cursor-pointer flex items-center justify-center gap-2.5 uppercase tracking-wide"
          >
            <Headphones className="w-5 h-5 stroke-[2.5]" />
            <span>{isBn ? 'সাপোর্ট' : 'Support'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
