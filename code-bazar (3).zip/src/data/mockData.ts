import { Category, Product, Order, WalletTransaction, UserProfile, Announcement, SupportTicket } from '../types';

export const CATEGORIES: Category[] = [
  { id: 'all', nameBn: 'সকল আইটেম', nameEn: 'All Products', icon: 'LayoutGrid' },
  { id: 'betting_scripts', nameBn: 'রেডিমেড বেটিং ও ক্যাসিনো সাইট', nameEn: 'Ready Betting & Casino Sites', icon: 'Code2' },
  { id: 'agent_accounts', nameBn: 'মাস্টার এজেন্ট ও ড্যাশবোর্ড', nameEn: 'Master Agent Accounts', icon: 'ShieldCheck' },
  { id: 'betting_accounts', nameBn: 'প্লেয়ার ও ভিআইপি অ্যাকাউন্ট', nameEn: 'Verified Player Accounts', icon: 'UserCheck' },
  { id: 'betting_topup', nameBn: 'পয়েন্ট, চিপস ও ভাউচার', nameEn: 'Points & Deposit TopUp', icon: 'Coins' },
  { id: 'verified_wallets', nameBn: 'ভেরিফায়েড পেমেন্ট ওয়ালেট', nameEn: 'Verified Payment Wallets', icon: 'Wallet' },
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-def-1',
    categoryId: 'betting_scripts',
    titleBn: '1xBet & Melbet টাইপ রেডিমেড বেটিং সাইট + ফুল এডমিন প্যানেল',
    titleEn: '1xBet & Melbet Type Ready Betting Site + Admin Panel',
    shortDescBn: 'সম্পূর্ণ প্রফেশনাল অটোমেটেড বেটিং ওয়েবসাইট ও সুপার এডমিন মাস্টার প্যানেল।',
    shortDescEn: 'Professional automated betting site & super admin master panel.',
    descriptionBn: 'লাইভ ক্যাসিনো, স্পোর্টস বেটিং, বিকাশ/নগদ অটো পেমেন্ট ও সম্পূর্ণ কাস্টমাইজেবল এডমিন প্যানেল সহ ডেলিভারি।',
    descriptionEn: 'Live Casino, Sportsbook, bKash/Nagad Auto Payment & fully customizable Admin Panel.',
    imageUrl: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80',
    bgGradient: 'from-blue-700 to-indigo-950',
    deliveryType: 'instant',
    warrantyBn: 'লাইফটাইম টেকনিক্যাল সাপোর্ট',
    warrantyEn: 'Lifetime Technical Support',
    rating: 5.0,
    soldCount: 42,
    instructionsBn: 'অর্ডার করার পর আপনার এডমিন ইমেইল ও পাসওয়ার্ড সাথে সাথে প্রদান করা হবে।',
    instructionsEn: 'Instant access credentials delivered upon checkout.',
    variants: [
      {
        id: 'var-def-1',
        nameBn: 'ফুল ওয়েবসাইট + এডমিন প্যানেল এক্সেস',
        nameEn: 'Full Website + Admin Panel Access',
        durationBn: 'লাইফটাইম',
        durationEn: 'Lifetime',
        price: 3500,
        originalPrice: 7000,
        inStock: true,
        stockCount: 15
      }
    ]
  },
  {
    id: 'prod-def-2',
    categoryId: 'agent_accounts',
    titleBn: 'Velki & Baji Live ভেরিফায়েড মাস্টার এজেন্ট অ্যাকাউন্ট (Admin Master)',
    titleEn: 'Velki & Baji Live Verified Master Agent Account',
    shortDescBn: '১০০% ভেরিফায়েড এজেন্ট প্যানেল পয়েন্ট ক্রিয়েট ও ইউজার কন্ট্রোল সুবিধা।',
    shortDescEn: '100% Verified Master Agent Panel with point management & user control.',
    descriptionBn: 'লাইভ মাস্টার এজেন্ট প্যানেল যা দিয়ে আনলিমিটেড ইউজার ও সাব-এজেন্ট অ্যাকাউন্ট তৈরি করা যাবে।',
    descriptionEn: 'Live master agent panel for managing unlimited users and sub-agents.',
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=500&auto=format&fit=crop&q=80',
    bgGradient: 'from-emerald-700 to-teal-950',
    deliveryType: 'instant',
    warrantyBn: '৩০ দিনের ওয়ারেন্টি',
    warrantyEn: '30 Days Warranty',
    rating: 4.9,
    soldCount: 88,
    instructionsBn: 'ডেলিভারির পর আইডি এবং পাসওয়ার্ড আপনার ড্যাশবোর্ডে শো করবে।',
    instructionsEn: 'Credentials will be visible in your order dashboard instantly.',
    variants: [
      {
        id: 'var-def-2',
        nameBn: 'মাস্টার এজেন্ট ড্যাশবোর্ড প্যানেল',
        nameEn: 'Master Agent Dashboard Panel',
        durationBn: '১ মাস',
        durationEn: '1 Month',
        price: 2500,
        originalPrice: 4000,
        inStock: true,
        stockCount: 20
      }
    ]
  },
  {
    id: 'prod-def-3',
    categoryId: 'betting_accounts',
    titleBn: 'Bet365 & Stake Fully Verified VIP Player Account',
    titleEn: 'Bet365 & Stake Fully Verified VIP Player Account',
    shortDescBn: 'সম্পূর্ণ ভেরিফায়েড প্লেয়ার অ্যাকাউন্ট ইনস্ট্যান্ট উইথড্রয়াল সুবিধা সহ।',
    shortDescEn: 'Fully verified VIP account with instant withdrawal access.',
    descriptionBn: 'পাসপোর্ট ও ব্যাংক ডকুমেন্ট সহ এনআইডি ভেরিফায়েড প্রিমিয়াম প্লেয়ার অ্যাকাউন্ট।',
    descriptionEn: 'NID and Passport verified player account ready for high limit bets.',
    imageUrl: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=500&auto=format&fit=crop&q=80',
    bgGradient: 'from-amber-700 to-amber-950',
    deliveryType: 'instant',
    warrantyBn: '৬০ দিনের গ্যারান্টি',
    warrantyEn: '60 Days Guarantee',
    rating: 4.8,
    soldCount: 65,
    instructionsBn: 'অর্ডারের সাথে সাথে ইমেইল, পাসওয়ার্ড ও ডকুমেন্ট দেওয়া হবে।',
    instructionsEn: 'Login credentials and docs delivered immediately.',
    variants: [
      {
        id: 'var-def-3',
        nameBn: 'ভিআইপি ফুল ভেরিফায়েড অ্যাকাউন্ট',
        nameEn: 'VIP Fully Verified Account',
        durationBn: 'লাইফটাইম',
        durationEn: 'Lifetime',
        price: 1800,
        originalPrice: 3000,
        inStock: true,
        stockCount: 12
      }
    ]
  },
  {
    id: 'prod-def-4',
    categoryId: 'betting_topup',
    titleBn: '১০০০০ পয়েন্ট ও ডিপোজিট চিপস ভাউচার (Instant Auto TopUp)',
    titleEn: '10,000 Points & Chips Deposit Voucher',
    shortDescBn: 'সবাইকে ইনস্ট্যান্ট পয়েন্ট ও চিপস পাঠানোর রিচার্জ ভাউচার কোড।',
    shortDescEn: 'Instant points & chips deposit code for fast balance refill.',
    descriptionBn: '১০০০০ পয়েন্ট ইনস্ট্যান্ট ট্রান্সফার ভাউচার কোড যা যেকোনো অ্যাকাউন্টে অ্যাড করা যায়।',
    descriptionEn: '10,000 points instant deposit voucher code redeemable on betting sites.',
    imageUrl: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=500&auto=format&fit=crop&q=80',
    bgGradient: 'from-purple-700 to-indigo-950',
    deliveryType: 'instant',
    warrantyBn: 'ইনস্ট্যান্ট ভ্যালিডেশন',
    warrantyEn: 'Instant Validation',
    rating: 5.0,
    soldCount: 120,
    instructionsBn: 'ভাউচার কোড আপনার অর্ডার বক্সে দেখাবে।',
    instructionsEn: 'Voucher code will be displayed in your order box.',
    variants: [
      {
        id: 'var-def-4',
        nameBn: '১০০০০ পয়েন্ট ভাউচার প্যাক',
        nameEn: '10,000 Points Voucher Pack',
        durationBn: 'ইনস্ট্যান্ট',
        durationEn: 'Instant',
        price: 1000,
        originalPrice: 1500,
        inStock: true,
        stockCount: 50
      }
    ]
  },
  {
    id: 'prod-def-5',
    categoryId: 'verified_wallets',
    titleBn: 'Binance & Skrill Fully Verified Wallet Account',
    titleEn: 'Binance & Skrill Fully Verified Wallet Account',
    shortDescBn: '১০০% এনআইডি ও এড্রেস ভেরিফায়েড আন্তর্জাতিক পেমেন্ট ওয়ালেট।',
    shortDescEn: '100% NID & Address verified international payment wallet.',
    descriptionBn: 'উইথড্র ও ডিপোজিট করার জন্য ফুল ভেরিফায়েড বাইন্যান্স ও স্ক্রিল মাস্টার অ্যাকাউন্ট।',
    descriptionEn: 'Fully verified Binance & Skrill wallet account ready for transactions.',
    imageUrl: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1bd?w=500&auto=format&fit=crop&q=80',
    bgGradient: 'from-cyan-700 to-slate-950',
    deliveryType: 'instant',
    warrantyBn: '৩০ দিনের রিপ্লেসমেন্ট ওয়ারেন্টি',
    warrantyEn: '30 Days Replacement Warranty',
    rating: 4.9,
    soldCount: 95,
    instructionsBn: 'লগইন ইমেইল, পাসওয়ার্ড ও সিকিউরিটি ব্যাকআপ কী প্রদান করা হবে।',
    instructionsEn: 'Login email, password, and security backup keys provided.',
    variants: [
      {
        id: 'var-def-5',
        nameBn: 'ফুল ভেরিফায়েড ওয়ালেট এক্সেস',
        nameEn: 'Fully Verified Wallet Access',
        durationBn: 'লাইফটাইম',
        durationEn: 'Lifetime',
        price: 2200,
        originalPrice: 3500,
        inStock: true,
        stockCount: 18
      }
    ]
  }
];

export const INITIAL_USER: UserProfile = {
  name: 'Tanvir Hossain',
  email: 'tanvir.dev@gmail.com',
  phone: '01879940191',
  walletBalance: 0,
  pendingBalance: 0,
  rewardPoints: 420,
  tier: {
    nameBn: 'ভিআইপি রিসেলার (VIP)',
    nameEn: 'VIP Reseller',
    level: 'gold',
    discountPercent: 0,
    minMonthlySpend: 5000,
    badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  },
  apiKey: 'cb_live_981a2f990142bc88a109',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
};

export const INITIAL_ORDERS: Order[] = [];

export const INITIAL_TRANSACTIONS: WalletTransaction[] = [];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    textBn: '⚡ CODE BAZAR রেডিমেড ক্যাসিনো ও বেটিং সাইট ডেলিভারি, এডমিন প্যানেল ও লাইভ মাস্টার এজেন্ট অ্যাকাউন্ট সার্ভিস চালু! 🔥',
    textEn: '⚡ Ready-made Casino & Betting Sites, Admin Panels & Live Master Agent Accounts Live on CODE BAZAR! 🔥',
    type: 'success',
    active: true
  }
];

export const INITIAL_TICKETS: SupportTicket[] = [];


