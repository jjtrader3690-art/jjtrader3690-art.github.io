import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { NoticeBanner } from './components/NoticeBanner';
import { ToastContainer } from './components/ToastContainer';
import { QuickBuyModal } from './components/QuickBuyModal';
import { OrderCredentialsModal } from './components/OrderCredentialsModal';
import { AddMoneyModal } from './components/AddMoneyModal';
import { ProfileDrawer } from './components/ProfileDrawer';
import { AuthModal } from './components/AuthModal';
import { AdminAuthModal } from './components/AdminAuthModal';
import { BottomNav } from './components/BottomNav';

import { MarketplaceTab } from './components/tabs/MarketplaceTab';
import { OrdersTab } from './components/tabs/OrdersTab';
import { WalletTab } from './components/tabs/WalletTab';
import { SubscriptionsTab } from './components/tabs/SubscriptionsTab';
import { ResellerTab } from './components/tabs/ResellerTab';
import { SupportTab } from './components/tabs/SupportTab';
import { AdminTab } from './components/tabs/AdminTab';
import { Zap, ShieldCheck, MessageCircle, Wifi, Battery, Signal, Smartphone, Monitor, MessageSquareCode } from 'lucide-react';

const MainContent: React.FC = () => {
  const { activeTab, language, viewMode, setViewMode, siteConfig, addToast } = useStore();
  const isBn = language === 'bn';

  // Global protection: Prevent image downloading, dragging, and right-click on images/content
  React.useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'IMG' || target.closest('img') || target.classList.contains('protected-content'))) {
        e.preventDefault();
        addToast(
          isBn
            ? '⚠️ কপিরাইট ও ওয়েবসাইট প্রোটেকশন: সাইটের ছবি বা কনটেন্ট ডাউনলোড করা সংরক্ষিত।'
            : '⚠️ Content Protected: Image downloading is disabled.',
          'error'
        );
      }
    };

    const handleDragStart = (e: DragEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'IMG' || target.closest('img'))) {
        e.preventDefault();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent Ctrl+S / Cmd+S save webpage/images
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        addToast(
          isBn ? '⚠️ ওয়েবসাইট পেজ ও ছবি সেভ করা যাবে না।' : '⚠️ Saving page/images is disabled.',
          'error'
        );
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('dragstart', handleDragStart);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('dragstart', handleDragStart);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isBn, addToast]);

  const cleanWaNumber = (siteConfig.whatsappNumber || '01836828065').replace(/\D/g, '');
  const waUrl = `https://wa.me/${cleanWaNumber.startsWith('88') ? cleanWaNumber : '88' + cleanWaNumber}`;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col items-center justify-center font-sans selection:bg-blue-500 selection:text-white py-0 sm:py-4 relative">
      
      {/* Smartphone Frame Container when viewMode === 'mobile' */}
      <div
        className={`w-full transition-all duration-300 ${
          viewMode === 'mobile'
            ? 'max-w-[440px] bg-white sm:rounded-[36px] sm:border-[8px] sm:border-slate-300 sm:shadow-2xl overflow-hidden min-h-screen sm:min-h-[850px] flex flex-col relative'
            : 'max-w-7xl mx-auto min-h-screen flex flex-col bg-white shadow-xl'
        }`}
      >
        {/* Smartphone Top Notch & Status Bar (Only in Mobile Frame mode on Desktop screens) */}
        {viewMode === 'mobile' && (
          <div className="hidden sm:flex items-center justify-between px-6 py-2 bg-slate-50 text-slate-600 text-[11px] font-bold border-b border-slate-200 select-none">
            <span>09:41</span>
            {/* Camera cutout pill */}
            <div className="w-20 h-4 bg-slate-200 rounded-full border border-slate-300 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-slate-400 border border-slate-300" />
            </div>
            <div className="flex items-center gap-1.5">
              <Signal className="w-3 h-3 text-slate-600" />
              <Wifi className="w-3 h-3 text-slate-600" />
              <div className="flex items-center gap-0.5 text-emerald-600 font-mono text-[10px]">
                <span>98%</span>
                <Battery className="w-3.5 h-3.5 text-emerald-600 fill-emerald-600/30" />
              </div>
            </div>
          </div>
        )}

        {/* Top Header */}
        <Header />

        {/* Scrolling Announcement Ticker */}
        <NoticeBanner />

        {/* Main Active Tab Content */}
        <main className="flex-1 w-full px-3 sm:px-4 py-4 overflow-y-auto bg-slate-50/60">
          {activeTab === 'marketplace' && <MarketplaceTab />}
          {activeTab === 'orders' && <OrdersTab />}
          {activeTab === 'wallet' && <WalletTab />}
          {activeTab === 'subscriptions' && <SubscriptionsTab />}
          {activeTab === 'reseller' && <ResellerTab />}
          {activeTab === 'support' && <SupportTab />}
          {activeTab === 'admin' && <AdminTab />}
        </main>

        {/* Mobile Native Bottom Navigation Bar */}
        <BottomNav />

        {/* Footer with Copyright & Site Info */}
        <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs py-4 px-4 text-center space-y-1.5">
          <div className="flex items-center justify-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-white font-black tracking-wide uppercase">{siteConfig.siteName || 'CODE BAZAR'} OFFICIAL STORE</span>
          </div>
          
          <p className="text-[11px] text-slate-300 max-w-md mx-auto leading-relaxed">
            {isBn ? siteConfig.footerAboutBn : (siteConfig.siteTaglineEn || 'Bangladesh #1 Web Services Marketplace')}
          </p>

          <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-400 font-medium">
            {siteConfig.copyrightText || `© 2026 ${siteConfig.siteName || 'CODE BAZAR'}. All Rights Reserved.`}
          </div>
        </footer>
      </div>

      {/* Floating WhatsApp Support Button */}
      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-16 right-4 sm:bottom-6 sm:right-6 z-40 p-2 sm:p-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-full shadow-2xl shadow-emerald-600/40 flex items-center gap-2 hover:scale-105 transition-all cursor-pointer border-2 border-emerald-400 group"
        title={`WhatsApp Support: ${siteConfig.whatsappNumber || '01836828065'}`}
      >
        <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white flex items-center justify-center p-0.5 shadow-inner shrink-0 overflow-hidden ring-2 ring-white/60">
          <img
            src={siteConfig.whatsappIconUrl || 'https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg'}
            alt="WhatsApp"
            className="w-full h-full object-cover rounded-full"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg';
            }}
          />
        </div>
        <span className="text-xs font-black hidden sm:inline pr-1.5 tracking-wide">{siteConfig.whatsappNumber || '01836828065'}</span>
      </a>

      {/* Floating View Switcher Banner for Desktop Users */}
      <div className="hidden sm:flex items-center gap-3 mt-3 bg-white border border-slate-200 px-4 py-2 rounded-full text-xs text-slate-700 shadow-xl">
        <span>{isBn ? 'স্ক্রিন সাইজ মোড:' : 'Screen Frame Mode:'}</span>
        <button
          onClick={() => setViewMode('mobile')}
          className={`px-3 py-1 rounded-full font-bold flex items-center gap-1.5 transition cursor-pointer ${
            viewMode === 'mobile'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-slate-100 text-slate-600 hover:text-slate-900'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>{isBn ? 'মোবাইল সাইজ (Phone UI)' : 'Mobile Phone'}</span>
        </button>
        <button
          onClick={() => setViewMode('responsive')}
          className={`px-3 py-1 rounded-full font-bold flex items-center gap-1.5 transition cursor-pointer ${
            viewMode === 'responsive'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-slate-100 text-slate-600 hover:text-slate-900'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>{isBn ? 'কম্পিউটার/ফুল স্ক্রিন' : 'Desktop Full'}</span>
        </button>
      </div>

      {/* Modals & Toasts */}
      <QuickBuyModal />
      <OrderCredentialsModal />
      <AddMoneyModal />
      <ProfileDrawer />
      <AuthModal />
      <AdminAuthModal />
      <ToastContainer />

    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <MainContent />
    </StoreProvider>
  );
}
