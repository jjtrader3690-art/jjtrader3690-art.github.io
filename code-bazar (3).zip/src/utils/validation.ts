/**
 * Real-world validation utilities for Bangladeshi eCommerce & Digital Platform
 * Rejects fake registrations, invalid phone numbers, dummy emails, and fake deposit requests.
 */

// Valid Bangladeshi Mobile Operator 3-digit prefixes
const VALID_BD_PREFIXES = ['013', '014', '015', '016', '017', '018', '019'];

// Obvious spam/dummy names
const FAKE_NAME_PATTERNS = [
  'test', 'testing', 'fake', 'asdf', 'qwerty', 'admin', 'administrator',
  'null', 'undefined', 'anonymous', 'dummy', 'temp', 'demo', 'sample',
  'xyz', 'abc', 'xxxx', 'yyyy', 'zzzz', 'root', 'user', 'unknown'
];

// Obvious dummy emails
const FAKE_EMAIL_PREFIXES = [
  'test', 'fake', 'asdf', 'qwerty', 'dummy', 'temp', 'demo',
  'sample', 'xyz', 'admin', 'null', 'undefined', 'user', 'noemail',
  'testuser', 'fakemail', 'abc'
];

const FAKE_EMAIL_DOMAINS = [
  'test.com', 'test.net', 'fake.com', 'example.com', 'example.org',
  'asdf.com', 'qwerty.com', 'dummy.com', 'xyz.com', 'temp.com',
  'sample.com', 'domain.com', 'mail.com', 'email.com', 'abc.com'
];

// Fake TrxID patterns and banned keywords
const FAKE_TRX_PATTERNS = [
  '123456', '000000', '111111', '12345678', 'ABCDEF', 'TEST123', 'TRXID',
  'ASDFGH', '1234567', '9999999', '123456789', '987654321', 'A1B2C3D4',
  '11223344', '12121212', 'QWERTYUI', 'ASDFGHJK', 'ZXCVBNM', 'TEST1234',
  'BKASH123', 'NAGAD123', 'TRX12345', 'DUMMYTRX', 'PAYMENT1', 'PAYMENT2',
  '00000000', '11111111', '22222222', '33333333', '44444444', '55555555',
  '66666666', '77777777', '88888888', '99999999', 'AAAAAAAA', 'BBBBBBBB',
  'CCCCCCCC', 'DDDDDDDD', '1234567890', '0123456789', '9876543210',
  'ABCDEFGHIJ', 'QWERTYUIOP', 'ASDFGHJKLP', 'ZXCVBNMASD'
];

const FAKE_TRX_KEYWORDS = [
  'TEST', 'FAKE', 'DEMO', 'DUMMY', 'SAMPLE', 'ADMIN', 'ROOT', 'USER', 'GUEST',
  'BKASH', 'NAGAD', 'ROCKET', 'UPAY', 'PAYMENT', 'WALLET', 'MONEY', 'DEPOSIT',
  'QWERTY', 'ASDFG', 'ZXCVB', 'POIUY', 'LKJH', 'MNBVC', 'TRXID'
];

const DEFAULT_TRX_ERROR_BN = 'দুঃখিত, আপনার ট্রানজেকশন আইডি খুঁজে পাওয়া যায়নি। অনুগ্রহ করে আপনার ট্রানজেকশন আইডি সহ আমাদের সাপোর্টে যোগাযোগ করুন।';
const DEFAULT_TRX_ERROR_EN = 'Sorry, your transaction ID was not found. Please contact our support with your transaction ID.';

/**
 * Converts Bengali digits to standard English ASCII digits
 */
export const normalizeBnDigits = (str: string): string => {
  if (!str) return '';
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  let res = str.toString();
  for (let i = 0; i < 10; i++) {
    res = res.split(bnDigits[i]).join(String(i));
  }
  return res;
};

/**
 * Normalizes any Bangladeshi phone number format to standard 01XXXXXXXXX
 */
export const normalizePhoneNumber = (raw: string): string => {
  if (!raw) return '';
  let cleaned = normalizeBnDigits(raw.toString()).replace(/[\s\-\(\)\+]/g, '').trim();
  if (cleaned.startsWith('880')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('88') && cleaned.length === 13) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.length === 10 && cleaned.startsWith('1')) {
    cleaned = '0' + cleaned;
  }
  return cleaned;
};

/**
 * Validates and normalizes Bangladeshi phone numbers
 */
export const validateBangladeshiPhone = (
  rawPhone: string
): { isValid: boolean; normalizedPhone: string; errorBn?: string; errorEn?: string } => {
  if (!rawPhone || typeof rawPhone !== 'string') {
    return {
      isValid: false,
      normalizedPhone: '',
      errorBn: 'মোবাইল নম্বর লিখুন!',
      errorEn: 'Please enter a mobile number!'
    };
  }

  const cleaned = normalizePhoneNumber(rawPhone);

  // Must be strictly 11 digits starting with 01
  if (!/^\d{11}$/.test(cleaned)) {
    return {
      isValid: false,
      normalizedPhone: cleaned,
      errorBn: 'মোবাইল নম্বরটি অবশ্যই সঠিক ১১ ডিজিটের হতে হবে (যেমনঃ 018XXXXXXXX)',
      errorEn: 'Mobile number must be exactly 11 digits (e.g. 018XXXXXXXX)'
    };
  }

  // Check valid Bangladeshi operator prefix
  const prefix = cleaned.substring(0, 3);
  if (!VALID_BD_PREFIXES.includes(prefix)) {
    return {
      isValid: false,
      normalizedPhone: cleaned,
      errorBn: 'অবৈধ অপারেটর কোড! নম্বরটি 013, 014, 015, 016, 017, 018 অথবা 019 দিয়ে শুরু হতে হবে।',
      errorEn: 'Invalid operator! Must start with 013, 014, 015, 016, 017, 018, or 019.'
    };
  }

  // Check for repeated digits after prefix (e.g. 01700000000, 01811111111)
  const remainingDigits = cleaned.substring(3);
  if (/^(\d)\1{7}$/.test(remainingDigits)) {
    return {
      isValid: false,
      normalizedPhone: cleaned,
      errorBn: 'ফেক বা ডামি মোবাইল নম্বর গ্রহণযোগ্য নয়! আপনার আসল মোবাইল নম্বর দিন।',
      errorEn: 'Fake or dummy mobile number is not allowed! Please enter real number.'
    };
  }

  // Check for sequential fake digits (e.g. 12345678, 87654321)
  if (remainingDigits === '12345678' || remainingDigits === '87654321' || remainingDigits === '01234567') {
    return {
      isValid: false,
      normalizedPhone: cleaned,
      errorBn: 'অনুগ্রহ করে আপনার আসল ব্যক্তিগত মোবাইল নম্বরটি প্রদান করুন।',
      errorEn: 'Please provide your genuine personal mobile number.'
    };
  }

  return {
    isValid: true,
    normalizedPhone: cleaned
  };
};

/**
 * Validates real full name (Bengali and English letters supported)
 */
export const validateFullName = (
  rawName: string
): { isValid: boolean; normalizedName: string; errorBn?: string; errorEn?: string } => {
  if (!rawName || typeof rawName !== 'string') {
    return {
      isValid: false,
      normalizedName: '',
      errorBn: 'আপনার সম্পূর্ণ আসল নাম লিখুন!',
      errorEn: 'Please enter your full genuine name!'
    };
  }

  const cleaned = rawName.trim().replace(/\s+/g, ' ');

  if (cleaned.length < 3) {
    return {
      isValid: false,
      normalizedName: cleaned,
      errorBn: 'নাম সর্বনিম্ন ৩ অক্ষরের হতে হবে!',
      errorEn: 'Full name must be at least 3 characters!'
    };
  }

  // Must contain letters (English or Bengali)
  const hasLetters = /[a-zA-Z\u0980-\u09FF]/.test(cleaned);
  if (!hasLetters) {
    return {
      isValid: false,
      normalizedName: cleaned,
      errorBn: 'নামে অবশ্যই বাংলা বা ইংরেজি বর্ণ থাকতে হবে!',
      errorEn: 'Name must contain valid letters!'
    };
  }

  // Reject all numbers or symbols
  if (/^[\d\s\-_.,!@#$%^&*()]+$/.test(cleaned)) {
    return {
      isValid: false,
      normalizedName: cleaned,
      errorBn: 'শুধুমাত্র সংখ্যা বা প্রতীক দিয়ে নাম গ্রহণযোগ্য নয়!',
      errorEn: 'Numbers or symbols only cannot be a name!'
    };
  }

  // Check for known fake names
  const lower = cleaned.toLowerCase();
  if (FAKE_NAME_PATTERNS.some((pattern) => lower === pattern || lower.startsWith(pattern + ' '))) {
    return {
      isValid: false,
      normalizedName: cleaned,
      errorBn: 'অনুগ্রহ করে আপনার প্রকৃত নাম লিখুন (ফেক নাম গ্রহণযোগ্য নয়)।',
      errorEn: 'Please enter your real full name (dummy names rejected).'
    };
  }

  return {
    isValid: true,
    normalizedName: cleaned
  };
};

/**
 * Validates real email address
 */
export const validateRealEmail = (
  rawEmail: string
): { isValid: boolean; normalizedEmail: string; errorBn?: string; errorEn?: string } => {
  if (!rawEmail || typeof rawEmail !== 'string') {
    return {
      isValid: false,
      normalizedEmail: '',
      errorBn: 'সঠিক ইমেইল বা জিমেইল অ্যাড্রেস লিখুন!',
      errorEn: 'Please enter a valid email or Gmail address!'
    };
  }

  const cleaned = rawEmail.trim().toLowerCase();

  // Strict email regex with TLD check (at least 2 chars TLD like .com, .net, .bd)
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,63}$/;
  if (!emailRegex.test(cleaned)) {
    return {
      isValid: false,
      normalizedEmail: cleaned,
      errorBn: 'অবৈধ ইমেইল ফরম্যাট! যেমন: user@gmail.com',
      errorEn: 'Invalid email format! e.g., user@gmail.com'
    };
  }

  const [prefix, domain] = cleaned.split('@');

  // Check prefix length & fake patterns
  if (prefix.length < 2) {
    return {
      isValid: false,
      normalizedEmail: cleaned,
      errorBn: 'ইমেইল ইউজারনেম অত্যন্ত ছোট!',
      errorEn: 'Email username is too short!'
    };
  }

  if (FAKE_EMAIL_PREFIXES.includes(prefix) && FAKE_EMAIL_DOMAINS.includes(domain)) {
    return {
      isValid: false,
      normalizedEmail: cleaned,
      errorBn: 'ফেক বা ডামি ইমেইল গ্রহণযোগ্য নয়! আপনার আসল সচল ইমেইল দিন।',
      errorEn: 'Dummy email address not allowed! Please provide genuine active email.'
    };
  }

  if (FAKE_EMAIL_DOMAINS.includes(domain)) {
    return {
      isValid: false,
      normalizedEmail: cleaned,
      errorBn: 'সচল এবং আসল ডোমেইনের ইমেইল দিন (যেমন @gmail.com, @yahoo.com ইত্যাদি)',
      errorEn: 'Please provide email with real active domain (e.g. @gmail.com).'
    };
  }

  return {
    isValid: true,
    normalizedEmail: cleaned
  };
};

/**
 * Validates Transaction ID for bKash & Nagad deposits strictly
 */
export const validateTransactionId = (
  rawTrx: string,
  existingTrxList: string[] = [],
  method: 'bkash' | 'nagad' | string = 'bkash'
): { isValid: boolean; normalizedTrx: string; errorBn?: string; errorEn?: string } => {
  if (!rawTrx || typeof rawTrx !== 'string') {
    return {
      isValid: false,
      normalizedTrx: '',
      errorBn: 'Transaction ID (TrxID) লিখুন!',
      errorEn: 'Please enter Transaction ID (TrxID)!'
    };
  }

  const cleanTrx = rawTrx.trim().toUpperCase().replace(/[\s\-_.,#:]/g, '');

  // 1. Minimum & Maximum length rules
  if (method === 'bkash') {
    if (cleanTrx.length !== 10) {
      return {
        isValid: false,
        normalizedTrx: cleanTrx,
        errorBn: DEFAULT_TRX_ERROR_BN,
        errorEn: DEFAULT_TRX_ERROR_EN
      };
    }
  } else if (method === 'nagad') {
    if (cleanTrx.length !== 8) {
      return {
        isValid: false,
        normalizedTrx: cleanTrx,
        errorBn: DEFAULT_TRX_ERROR_BN,
        errorEn: DEFAULT_TRX_ERROR_EN
      };
    }
  } else {
    if (cleanTrx.length < 8 || cleanTrx.length > 12) {
      return {
        isValid: false,
        normalizedTrx: cleanTrx,
        errorBn: DEFAULT_TRX_ERROR_BN,
        errorEn: DEFAULT_TRX_ERROR_EN
      };
    }
  }

  // 2. Must be alphanumeric only [A-Z0-9]
  if (!/^[A-Z0-9]+$/.test(cleanTrx)) {
    return {
      isValid: false,
      normalizedTrx: cleanTrx,
      errorBn: DEFAULT_TRX_ERROR_BN,
      errorEn: DEFAULT_TRX_ERROR_EN
    };
  }

  // 3. Count letters and digits
  const lettersCount = (cleanTrx.match(/[A-Z]/g) || []).length;
  const digitsCount = (cleanTrx.match(/[0-9]/g) || []).length;

  // Real bKash and Nagad TrxIDs ALWAYS contain a combination of BOTH letters AND digits
  if (lettersCount === 0 || digitsCount === 0) {
    return {
      isValid: false,
      normalizedTrx: cleanTrx,
      errorBn: DEFAULT_TRX_ERROR_BN,
      errorEn: DEFAULT_TRX_ERROR_EN
    };
  }

  // 4. Reject known fake/dummy patterns
  if (FAKE_TRX_PATTERNS.includes(cleanTrx)) {
    return {
      isValid: false,
      normalizedTrx: cleanTrx,
      errorBn: DEFAULT_TRX_ERROR_BN,
      errorEn: DEFAULT_TRX_ERROR_EN
    };
  }

  // 5. Reject if it contains fake keywords (like TEST, FAKE, DEMO, BKASH, etc.)
  for (const kw of FAKE_TRX_KEYWORDS) {
    if (cleanTrx.includes(kw)) {
      return {
        isValid: false,
        normalizedTrx: cleanTrx,
        errorBn: DEFAULT_TRX_ERROR_BN,
        errorEn: DEFAULT_TRX_ERROR_EN
      };
    }
  }

  // 6. Check for repetitive characters (e.g. AAAA, 0000, 1111 or repeating 2-char chunks like ABABAB)
  if (/([A-Z0-9])\1\1\1/.test(cleanTrx)) {
    return {
      isValid: false,
      normalizedTrx: cleanTrx,
      errorBn: DEFAULT_TRX_ERROR_BN,
      errorEn: DEFAULT_TRX_ERROR_EN
    };
  }

  if (/^(.{2})\1{3,}$/.test(cleanTrx) || /^(.{3})\1{2,}$/.test(cleanTrx)) {
    return {
      isValid: false,
      normalizedTrx: cleanTrx,
      errorBn: DEFAULT_TRX_ERROR_BN,
      errorEn: DEFAULT_TRX_ERROR_EN
    };
  }

  // 7. Check for sequential digits/letters
  if (/^12345|^23456|^34567|^45678|^56789|^98765|^87654|^ABCDE|^BCDEF/.test(cleanTrx)) {
    return {
      isValid: false,
      normalizedTrx: cleanTrx,
      errorBn: DEFAULT_TRX_ERROR_BN,
      errorEn: DEFAULT_TRX_ERROR_EN
    };
  }

  // 8. Check for duplicate TrxID in already submitted transactions
  const isDuplicate = existingTrxList.some(
    (existing) => existing && existing.trim().toUpperCase() === cleanTrx
  );
  if (isDuplicate) {
    return {
      isValid: false,
      normalizedTrx: cleanTrx,
      errorBn: DEFAULT_TRX_ERROR_BN,
      errorEn: DEFAULT_TRX_ERROR_EN
    };
  }

  return {
    isValid: true,
    normalizedTrx: cleanTrx
  };
};

