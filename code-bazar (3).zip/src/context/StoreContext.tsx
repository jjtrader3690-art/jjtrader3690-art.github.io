import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { db, auth, googleProvider } from '../firebase';
import { signInWithPopup } from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  deleteDoc
} from 'firebase/firestore';
import {
  validateBangladeshiPhone,
  validateFullName,
  validateRealEmail,
  validateTransactionId,
  normalizePhoneNumber,
  normalizeBnDigits
} from '../utils/validation';
import {
  Language,
  Product,
  Order,
  OrderStatus,
  WalletTransaction,
  UserProfile,
  Announcement,
  SupportTicket,
  PaymentMethod,
  CategoryId,
  ProductVariant,
  Category,
  RegisteredUser,
  PromoBanner,
  SiteConfig,
  VisitorStats,
  PushBroadcast
} from '../types';
import {
  CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_USER,
  INITIAL_ORDERS,
  INITIAL_TRANSACTIONS,
  INITIAL_ANNOUNCEMENTS,
  INITIAL_TICKETS
} from '../data/mockData';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface StoreContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: CategoryId;
  setSelectedCategory: (cat: CategoryId) => void;
  categories: Category[];
  registeredUsers: RegisteredUser[];
  banners: PromoBanner[];
  viewMode: 'mobile' | 'responsive';
  setViewMode: (mode: 'mobile' | 'responsive') => void;
  
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  orders: Order[];
  transactions: WalletTransaction[];
  announcements: Announcement[];
  paymentNumbers: {
    bkash: string;
    nagad: string;
    rocket: string;
    upay: string;
    bkashLogo?: string;
    nagadLogo?: string;
    rocketLogo?: string;
    upayLogo?: string;
    bkashEnabled?: boolean;
    nagadEnabled?: boolean;
    rocketEnabled?: boolean;
    upayEnabled?: boolean;
    quickDepositAmounts?: number[];
  };
  siteConfig: SiteConfig;
  visitorStats: VisitorStats;
  tickets: SupportTicket[];
  toasts: ToastMessage[];
  
  // Actions
  addToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  adminUpdateSiteConfig: (newSettings: Partial<SiteConfig>) => void;
  adminResetVisitorStats: () => void;
  adminUpdateVisitorStats: (newStats: Partial<VisitorStats>) => void;
  
  // Wallet & Orders
  addMoneyRequest: (amount: number, method: PaymentMethod, param3: string, param4?: string) => boolean;
  purchaseProduct: (
    product: Product,
    variant: ProductVariant,
    customInput?: string,
    siteDetails?: {
      siteName?: string;
      siteLogoUrl?: string;
      siteAdminEmail?: string;
      siteAdminPassword?: string;
      sitePhone?: string;
    }
  ) => { success: boolean; order?: Order; message?: string };
  purchaseProductDirect: (
    product: Product,
    variant: ProductVariant,
    method: PaymentMethod,
    senderMobile: string,
    trxId: string,
    customInput?: string,
    siteDetails?: {
      siteName?: string;
      siteLogoUrl?: string;
      siteAdminEmail?: string;
      siteAdminPassword?: string;
      sitePhone?: string;
    }
  ) => { success: boolean; order?: Order; message?: string };
  claimWarranty: (orderId: string, reason: string) => boolean;
  createSupportTicket: (subject: string, category: any, message: string, orderId?: string) => void;
  addTicketMessage: (ticketId: string, text: string) => void;

  // Admin actions
  adminApproveTransaction: (txId: string) => void;
  adminRejectTransaction: (txId: string) => void;
  adminAddCategory: (category: Category) => void;
  adminUpdateCategory: (category: Category, oldId?: string) => void;
  adminDeleteCategory: (categoryId: string) => void;
  adminAddProduct: (newProduct: Product) => void;
  adminEditProduct: (updatedProduct: Product) => void;
  adminDeleteProduct: (productId: string) => void;
  adminUpdateStock: (productId: string, variantId: string, count: number, credentialsText?: string) => void;
  adminUpdatePaymentNumbers: (numbers: {
    bkash: string;
    nagad: string;
    rocket: string;
    upay: string;
    bkashLogo?: string;
    nagadLogo?: string;
    rocketLogo?: string;
    upayLogo?: string;
    bkashEnabled?: boolean;
    nagadEnabled?: boolean;
    rocketEnabled?: boolean;
    upayEnabled?: boolean;
    quickDepositAmounts?: number[];
  }) => void;
  adminUpdateAnnouncement: (textBn: string, textEn: string) => void;
  adminAddBanner: (imageUrl: string, title?: string, linkUrl?: string) => void;
  adminUpdateBanner: (banner: PromoBanner) => void;
  adminDeleteBanner: (bannerId: string) => void;
  adminUpdateUserBalance: (amount: number) => void;
  adminCreditUserBalance: (userId: string, amount: number, note?: string) => void;
  adminUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  adminDeleteOrder: (orderId: string) => void;
  adminClearCancelledOrders: () => void;
  adminDeleteTransaction: (txId: string) => void;
  adminClearRejectedTransactions: () => void;
  adminToggleBlockUser: (userId: string) => void;
  adminDeleteUser: (userId: string) => void;
  adminTestTelegramNotification: (
    testToken?: string,
    testChatId?: string,
    testType?: 'order' | 'registration' | 'deposit' | 'bkash' | 'nagad' | 'rocket'
  ) => Promise<boolean>;
  adminClearHistory: () => void;

  // Web & PWA Push Notifications
  pushBroadcasts: PushBroadcast[];
  pushNotificationPermission: NotificationPermission | 'unsupported';
  isPushNotificationSupported: boolean;
  activePushAlert: PushBroadcast | null;
  setActivePushAlert: (alert: PushBroadcast | null) => void;
  requestPushNotificationPermission: () => Promise<boolean>;
  triggerDeviceNotification: (
    title: string,
    options?: {
      body?: string;
      icon?: string;
      image?: string;
      url?: string;
      tag?: string;
    }
  ) => Promise<boolean>;
  adminSendPushBroadcast: (broadcast: {
    title: string;
    body: string;
    image?: string;
    url?: string;
  }) => Promise<boolean>;
  adminTestPushNotification: (data?: {
    title?: string;
    body?: string;
    image?: string;
  }) => Promise<boolean>;
  
  // Modal states
  selectedProductForBuy: Product | null;
  setSelectedProductForBuy: (p: Product | null) => void;
  selectedOrderForView: Order | null;
  setSelectedOrderForView: (o: Order | null) => void;
  isAddMoneyModalOpen: boolean;
  setIsAddMoneyModalOpen: (open: boolean) => void;
  isProfileDrawerOpen: boolean;
  setIsProfileDrawerOpen: (open: boolean) => void;
  isAdminView: boolean;
  setIsAdminView: (admin: boolean) => void;

  // Auth & Admin Security
  isUserLoggedIn: boolean;
  setIsUserLoggedIn: (loggedIn: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  registerUser: (fullName: string, phone: string, password: string, email?: string) => boolean;
  loginUser: (phone: string, password: string) => boolean;
  loginWithGoogle: () => Promise<boolean>;
  logoutUser: () => void;
  isAdminAuthenticated: boolean;
  setIsAdminAuthenticated: (auth: boolean) => void;
  isAdminAuthModalOpen: boolean;
  setIsAdminAuthModalOpen: (open: boolean) => void;
  verifyAdminPin: (apiKeyOrPin: string) => boolean;
  verifyAdminApiKey: (apiKey: string) => boolean;
  isAdminPermanentlyLocked: boolean;
  adminLockDetails: {
    locked: boolean;
    lockedAt?: string;
    reason?: string;
  };
  unlockAdminWithMasterKey: (masterKeyOrSecret: string) => boolean;
  adminLockPermanently: (reason?: string) => void;
  adminUnlockPermanently: () => void;
}

export const normalizePhone = (phone: string): string => {
  if (!phone) return '';
  let str = phone.toString().trim();
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  for (let i = 0; i < 10; i++) {
    str = str.split(bnDigits[i]).join(i.toString());
  }
  let digits = str.replace(/\D/g, '');
  if (digits.startsWith('8801') && digits.length === 13) {
    digits = digits.slice(2);
  }
  return digits;
};

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const INITIAL_REGISTERED_USERS: RegisteredUser[] = [
  {
    id: 'usr-101',
    name: 'মকসেদুল আলম',
    phone: '01836828065',
    email: 'moksedul.dev@gmail.com',
    password: 'pass#user123',
    registeredAt: '2026-07-28 14:30',
    walletBalance: 0
  },
  {
    id: 'usr-102',
    name: 'রাফি আহমেদ',
    phone: '01712345678',
    email: 'rafi.betting.bd@gmail.com',
    password: 'rafi@pass2026',
    registeredAt: '2026-07-29 09:15',
    walletBalance: 0
  },
  {
    id: 'usr-103',
    name: 'তানভীর হোসেন',
    phone: '01987654321',
    email: 'tanvir.agency@gmail.com',
    password: 'tanvir#betcode',
    registeredAt: '2026-07-29 18:40',
    walletBalance: 0
  }
];

const INITIAL_BANNERS: PromoBanner[] = [
  {
    id: 'bnr-1',
    imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&auto=format&fit=crop&q=80',
    title: 'Code Bazar 50% Eid Offer - All Source Codes & Sites',
    active: true
  },
  {
    id: 'bnr-2',
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
    title: 'Casino & Sports Betting Ready Site Delivery in 30 Mins',
    active: true
  }
];

const INITIAL_SITE_CONFIG: SiteConfig = {
  siteName: 'CODE BAZAR',
  siteTaglineBn: 'বাংলাদেশের ১ নম্বর প্রফেশনাল রেডিমেড বেটিং সাইট ও প্যানেল বাজার',
  siteTaglineEn: 'Bangladesh #1 Professional Ready Betting Site & Admin Panel Marketplace',
  logoUrl: '',
  whatsappNumber: '01836828065',
  whatsappIconUrl: 'https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg',
  telegramLink: 'https://t.me/codebazar_official',
  supportEmail: 'codebazarsupport@gmail.com',
  helplinePhone: '01836828065',
  adminPin: '258258',
  adminApiKey: 'CB-ADMIN-SECURE-998877-KEY',
  adminMasterKey: 'MASTER#3690#JJ',
  ownerRecoveryEmail: 'jjtrader3690@gmail.com',
  isAdminPermanentlyLocked: false,
  whatsappBannerText: 'WHATSAPP (01836828065) বাটনে ক্লিক করে সরাসরি সাপোর্ট নিন 👍',
  footerAboutBn: 'CODE BAZAR হলো বাংলাদেশের সবচেয়ে জনপ্রিয় এবং বিশ্বস্ত প্রফেশনাল রেডিমেড বেটিং ওয়েবসাইট, ক্যাসিনো সাইট ও এডমিন প্যানেল ক্রয়ের অনলাইন মার্কেটপ্লেস।',
  copyrightText: '© 2026 CODE BAZAR. All Rights Reserved.',
  currencySymbol: '৳',
  telegramBotToken: '8853475013:AAH-z33AZW5J9NrTTep9Y4To0Dkk0KZa1vo',
  telegramChatId: '-1004482692104',
  telegramRegistrationChatId: '-1003714893029',
  telegramBkashChatId: '-1003778905526',
  telegramNagadChatId: '-1004417567167',
  telegramNotifyEnabled: true,
  pushNotifyEnabled: true,
  pushAutoNotifyOnNewProduct: true
};

const INITIAL_PAYMENT_NUMBERS = {
  bkash: '01879940191',
  nagad: '01879940191',
  rocket: '01879940191-7',
  upay: '01879940191',
  bkashLogo: '',
  nagadLogo: '',
  rocketLogo: '',
  upayLogo: '',
  bkashEnabled: true,
  nagadEnabled: true,
  rocketEnabled: true,
  upayEnabled: true,
  quickDepositAmounts: [100, 300, 500, 1000, 2000, 5000]
};

const INITIAL_VISITOR_STATS: VisitorStats = {
  totalVisits: 1850,
  todayVisits: 124,
  uniqueVisitors: 890,
  liveVisitors: 18,
  lastVisitAt: new Date().toISOString(),
  dailyVisits: {}
};

const compressDataUrlIfNeeded = (dataUrl: string): string => {
  if (!dataUrl || !dataUrl.startsWith('data:image/')) return dataUrl;
  if (dataUrl.length < 120000) return dataUrl;
  
  try {
    if (typeof window !== 'undefined' && typeof document !== 'undefined') {
      const img = new Image();
      img.src = dataUrl;
      const canvas = document.createElement('canvas');
      const maxDim = 600;
      let w = img.width || 600;
      let h = img.height || 600;
      if (w > maxDim || h > maxDim) {
        if (w > h) {
          h = Math.round((h * maxDim) / w);
          w = maxDim;
        } else {
          w = Math.round((w * maxDim) / h);
          h = maxDim;
        }
      }
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, w, h);
        const compressed = canvas.toDataURL('image/jpeg', 0.65);
        if (compressed && compressed.length < dataUrl.length) {
          return compressed;
        }
      }
    }
  } catch (e) {
    console.warn('Canvas compression error:', e);
  }
  
  if (dataUrl.length > 500000) {
    return 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80';
  }
  return dataUrl;
};

const sanitizeForFirestore = (obj: any): any => {
  if (obj === null || obj === undefined) return null;
  if (typeof obj === 'function' || typeof obj === 'symbol') return null;
  if (typeof obj === 'string') {
    return compressDataUrlIfNeeded(obj);
  }
  if (typeof obj === 'number' || typeof obj === 'boolean') {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj
      .map((item) => sanitizeForFirestore(item))
      .filter((item) => item !== undefined && item !== null);
  }
  if (typeof obj === 'object') {
    const res: Record<string, any> = {};
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (val !== undefined && val !== null) {
        const sanitized = sanitizeForFirestore(val);
        if (sanitized !== null && sanitized !== undefined) {
          res[key] = sanitized;
        }
      }
    }
    return res;
  }
  return obj;
};

let isFirestoreQuotaExceeded = false;

const handleFirestoreError = (context: string, err: any) => {
  const errMsg = err?.message || String(err || '');
  if (
    errMsg.includes('Quota limit exceeded') ||
    errMsg.includes('resource-exhausted') ||
    err?.code === 'resource-exhausted'
  ) {
    if (!isFirestoreQuotaExceeded) {
      isFirestoreQuotaExceeded = true;
      console.warn('Firestore daily quota reached. Falling back gracefully to local persistence.');
    }
    return;
  }
  console.warn(`Firestore ${context} notice:`, errMsg);
};

const saveFirestoreDoc = async (colName: string, docId: string, data: any) => {
  if (!db || !docId || isFirestoreQuotaExceeded) return;
  try {
    const cleanData = sanitizeForFirestore(JSON.parse(JSON.stringify(data)));
    await setDoc(doc(db, colName, docId), cleanData, { merge: true });
  } catch (err) {
    handleFirestoreError(`save [${colName}/${docId}]`, err);
  }
};

const deleteFirestoreDoc = async (colName: string, docId: string) => {
  if (!db || !docId || isFirestoreQuotaExceeded) return;
  try {
    await deleteDoc(doc(db, colName, docId));
  } catch (err) {
    handleFirestoreError(`delete [${colName}/${docId}]`, err);
  }
};

const safeSetItem = (key: string, value: string) => {
  try {
    localStorage.setItem(key, value);
  } catch (e) {
    console.warn(`LocalStorage quota exceeded for key "${key}":`, e);
    try {
      if (key === 'xsb_products') {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Strip massive base64 image strings if quota exceeded (>300KB) so products are NOT lost
          const cleaned = parsed.map((p: any) => ({
            ...p,
            imageUrl: p.imageUrl && p.imageUrl.startsWith('data:image/') && p.imageUrl.length > 300000
              ? 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80'
              : p.imageUrl,
            demoImages: (p.demoImages || []).map((img: string) =>
              img && img.startsWith('data:image/') && img.length > 300000
                ? 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=500&auto=format&fit=crop&q=80'
                : img
            )
          }));
          localStorage.setItem(key, JSON.stringify(cleaned));
        }
      } else if (key === 'xsb_orders' || key === 'xsb_orders_v2') {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed) && parsed.length > 15) {
          localStorage.setItem(key, JSON.stringify(parsed.slice(0, 15)));
        }
      } else if (key === 'xsb_transactions' || key === 'xsb_transactions_v2') {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed) && parsed.length > 15) {
          localStorage.setItem(key, JSON.stringify(parsed.slice(0, 15)));
        }
      }
    } catch {
      // Ignore fallback failures
    }
  }
};

const safeGetItem = (key: string): string | null => {
  try {
    return localStorage.getItem(key);
  } catch (e) {
    console.warn(`LocalStorage getItem failed for key "${key}":`, e);
    return null;
  }
};

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('bn');
  const [activeTab, setActiveTab] = useState<string>('marketplace');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');
  const [isAdminView, setIsAdminView] = useState<boolean>(false);

  // Persistent LocalStorage
  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = safeGetItem('cb_categories');
    return saved ? JSON.parse(saved) : CATEGORIES;
  });

  const [banners, setBanners] = useState<PromoBanner[]>(() => {
    const saved = safeGetItem('cb_banners');
    return saved ? JSON.parse(saved) : INITIAL_BANNERS;
  });

  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>(() => {
    const saved = safeGetItem('cb_registered_users');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error('Failed to parse saved registered users:', e);
      }
    }
    return INITIAL_REGISTERED_USERS;
  });

  const [user, setUser] = useState<UserProfile>(() => {
    const saved = safeGetItem('xsb_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = safeGetItem('xsb_products');
    if (saved) {
      try {
        const parsed: Product[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error('Failed to parse saved products:', e);
      }
    }
    return INITIAL_PRODUCTS || [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = safeGetItem('xsb_orders_v2');
    return saved ? JSON.parse(saved) : [];
  });

  const [transactions, setTransactions] = useState<WalletTransaction[]>(() => {
    const saved = safeGetItem('xsb_transactions_v2');
    return saved ? JSON.parse(saved) : [];
  });

  const [announcements, setAnnouncements] = useState<Announcement[]>(() => {
    const saved = safeGetItem('xsb_announcements');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const filtered = parsed.filter(
            (a: any) =>
              a.id !== 'ann-2' &&
              !a.textBn?.includes('বিকাশ') &&
              !a.textBn?.includes('ডিপোজিট নম্বর') &&
              !a.textBn?.includes('হোয়াটসঅ্যাপ সাপোর্ট নম্বর')
          );
          if (filtered.length > 0) return filtered;
        }
      } catch {}
    }
    return INITIAL_ANNOUNCEMENTS;
  });

  const [paymentNumbers, setPaymentNumbers] = useState<{
    bkash: string;
    nagad: string;
    rocket: string;
    upay: string;
    bkashLogo?: string;
    nagadLogo?: string;
    rocketLogo?: string;
    upayLogo?: string;
    bkashEnabled?: boolean;
    nagadEnabled?: boolean;
    rocketEnabled?: boolean;
    upayEnabled?: boolean;
    quickDepositAmounts?: number[];
  }>(() => {
    const saved = safeGetItem('xsb_payment_numbers');
    const defaultVal = {
      bkash: '01879940191',
      nagad: '01879940191',
      rocket: '01879940191-7',
      upay: '01879940191',
      bkashLogo: '',
      nagadLogo: '',
      rocketLogo: '',
      upayLogo: '',
      bkashEnabled: true,
      nagadEnabled: true,
      rocketEnabled: true,
      upayEnabled: true,
      quickDepositAmounts: [100, 300, 500, 1000, 2000, 5000]
    };
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { ...defaultVal, ...parsed };
      } catch {
        return defaultVal;
      }
    }
    return defaultVal;
  });

  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => {
    const saved = safeGetItem('cb_site_config');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.adminPin === '1234' || parsed.adminPin === '3690') {
          parsed.adminPin = '258258';
        }
        if (!parsed.whatsappIconUrl) {
          parsed.whatsappIconUrl = 'https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg';
        }
        if (!parsed.telegramBotToken) {
          parsed.telegramBotToken = '8853475013:AAH-z33AZW5J9NrTTep9Y4To0Dkk0KZa1vo';
        }
        if (!parsed.telegramChatId || parsed.telegramChatId === '@ordercheckin_bot') {
          parsed.telegramChatId = '-1004482692104';
        }
        if (!parsed.telegramRegistrationChatId) {
          parsed.telegramRegistrationChatId = '-1003714893029';
        }
        if (!parsed.telegramBkashChatId) {
          parsed.telegramBkashChatId = '-1003778905526';
        }
        if (!parsed.telegramNagadChatId) {
          parsed.telegramNagadChatId = '-1004417567167';
        }
        if (!parsed.supportEmail || parsed.supportEmail === 'support@codebazar.store') {
          parsed.supportEmail = 'codebazarsupport@gmail.com';
        }
        return { ...INITIAL_SITE_CONFIG, ...parsed };
      } catch {
        return INITIAL_SITE_CONFIG;
      }
    }
    return INITIAL_SITE_CONFIG;
  });

  const [visitorStats, setVisitorStats] = useState<VisitorStats>(() => {
    const saved = safeGetItem('cb_visitor_stats');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { ...INITIAL_VISITOR_STATS, ...parsed };
      } catch {
        return INITIAL_VISITOR_STATS;
      }
    }
    return INITIAL_VISITOR_STATS;
  });

  const [viewMode, setViewMode] = useState<'mobile' | 'responsive'>(() => {
    const saved = safeGetItem('xsb_view_mode');
    return (saved as any) || 'mobile';
  });

  const [tickets, setTickets] = useState<SupportTicket[]>(() => {
    const saved = safeGetItem('xsb_tickets');
    return saved ? JSON.parse(saved) : INITIAL_TICKETS;
  });

  const [pushBroadcasts, setPushBroadcasts] = useState<PushBroadcast[]>([]);
  const [activePushAlert, setActivePushAlert] = useState<PushBroadcast | null>(null);
  const [pushNotificationPermission, setPushNotificationPermission] = useState<NotificationPermission | 'unsupported'>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'unsupported';
  });
  const isPushNotificationSupported = typeof window !== 'undefined' && 'Notification' in window;

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Modals & Auth state
  const [selectedProductForBuy, setSelectedProductForBuy] = useState<Product | null>(null);
  const [selectedOrderForView, setSelectedOrderForView] = useState<Order | null>(null);
  const [isAddMoneyModalOpen, setIsAddMoneyModalOpen] = useState<boolean>(false);
  const [isProfileDrawerOpen, setIsProfileDrawerOpen] = useState<boolean>(false);

  const [isUserLoggedIn, setIsUserLoggedIn] = useState<boolean>(() => {
    return safeGetItem('cb_is_logged_in') === 'true';
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      return (
        sessionStorage.getItem('cb_admin_auth') === 'true' ||
        localStorage.getItem('cb_admin_auth') === 'true'
      );
    } catch {
      return false;
    }
  });
  const [isAdminAuthModalOpen, setIsAdminAuthModalOpen] = useState<boolean>(false);

  // Strict One-Strike Lifetime Admin Security Lock State
  const [isAdminPermanentlyLocked, setIsAdminPermanentlyLocked] = useState<boolean>(() => {
    try {
      return (
        localStorage.getItem('cb_admin_locked_forever') === 'true' ||
        sessionStorage.getItem('cb_admin_locked_forever') === 'true'
      );
    } catch {
      return false;
    }
  });

  const [adminLockDetails, setAdminLockDetails] = useState<{
    locked: boolean;
    lockedAt?: string;
    reason?: string;
  }>(() => {
    const saved = safeGetItem('cb_admin_lock_details');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return { locked: false };
  });

  useEffect(() => {
    safeSetItem('cb_is_logged_in', isUserLoggedIn ? 'true' : 'false');
  }, [isUserLoggedIn]);

  useEffect(() => {
    try {
      sessionStorage.setItem('cb_admin_auth', isAdminAuthenticated ? 'true' : 'false');
      localStorage.setItem('cb_admin_auth', isAdminAuthenticated ? 'true' : 'false');
    } catch {
      // Ignore
    }
  }, [isAdminAuthenticated]);

  useEffect(() => {
    safeSetItem('cb_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    safeSetItem('cb_banners', JSON.stringify(banners));
  }, [banners]);

  useEffect(() => {
    safeSetItem('cb_registered_users', JSON.stringify(registeredUsers));
  }, [registeredUsers]);

  // Sync active user balance & blocked status from registeredUsers
  useEffect(() => {
    if (isUserLoggedIn && user.phone) {
      const normPhone = normalizePhone(user.phone);
      const matched = registeredUsers.find((ru) => {
        const ruNorm = normalizePhone(ru.phone);
        return (ruNorm && normPhone && ruNorm === normPhone) || ru.phone.trim() === user.phone.trim();
      });
      if (matched) {
        setUser((prev) => ({
          ...prev,
          id: matched.id,
          name: matched.name || prev.name,
          email: matched.email || prev.email,
          walletBalance: matched.walletBalance,
          isBlocked: matched.isBlocked
        }));
      }
    }
  }, [registeredUsers, isUserLoggedIn]);

  // Real-time Firestore synchronization across all devices
  useEffect(() => {
    if (!db) return;

    // 1. Products
    const unsubProducts = onSnapshot(
      collection(db, 'products'),
      (snapshot) => {
        if (snapshot.empty) {
          const localSaved = safeGetItem('xsb_products');
          let toSeed = INITIAL_PRODUCTS;
          if (localSaved) {
            try {
              const parsed = JSON.parse(localSaved);
              if (Array.isArray(parsed) && parsed.length > 0) toSeed = parsed;
            } catch {}
          }
          toSeed.forEach((p) => saveFirestoreDoc('products', p.id, p));
          setProducts(toSeed);
        } else {
          const items = snapshot.docs.map((d) => d.data() as Product);
          setProducts(items);
          safeSetItem('xsb_products', JSON.stringify(items));
        }
      },
      (err) => handleFirestoreError('products listener', err)
    );

    // 2. Categories
    const unsubCategories = onSnapshot(
      collection(db, 'categories'),
      (snapshot) => {
        if (snapshot.empty) {
          const localSaved = safeGetItem('cb_categories');
          let toSeed = CATEGORIES;
          if (localSaved) {
            try {
              const parsed = JSON.parse(localSaved);
              if (Array.isArray(parsed) && parsed.length > 0) toSeed = parsed;
            } catch {}
          }
          toSeed.forEach((c) => saveFirestoreDoc('categories', c.id, c));
          setCategories(toSeed);
        } else {
          const items = snapshot.docs.map((d) => d.data() as Category);
          setCategories(items);
          safeSetItem('cb_categories', JSON.stringify(items));
        }
      },
      (err) => handleFirestoreError('categories listener', err)
    );

    // 3. Banners
    const unsubBanners = onSnapshot(
      collection(db, 'banners'),
      (snapshot) => {
        if (snapshot.empty) {
          const localSaved = safeGetItem('cb_banners');
          let toSeed = INITIAL_BANNERS;
          if (localSaved) {
            try {
              const parsed = JSON.parse(localSaved);
              if (Array.isArray(parsed) && parsed.length > 0) toSeed = parsed;
            } catch {}
          }
          toSeed.forEach((b) => saveFirestoreDoc('banners', b.id, b));
          setBanners(toSeed);
        } else {
          const items = snapshot.docs.map((d) => d.data() as PromoBanner);
          setBanners(items);
          safeSetItem('cb_banners', JSON.stringify(items));
        }
      },
      (err) => handleFirestoreError('banners listener', err)
    );

    // 4. Announcements
    const unsubAnnouncements = onSnapshot(
      collection(db, 'announcements'),
      (snapshot) => {
        if (snapshot.empty) {
          const localSaved = safeGetItem('xsb_announcements');
          let toSeed = INITIAL_ANNOUNCEMENTS;
          if (localSaved) {
            try {
              const parsed = JSON.parse(localSaved);
              if (Array.isArray(parsed) && parsed.length > 0) {
                toSeed = parsed.filter((a) => a.id !== 'ann-2' && !a.textBn?.includes('বিকাশ ও নগদ ডিপোজিট'));
                if (toSeed.length === 0) toSeed = INITIAL_ANNOUNCEMENTS;
              }
            } catch {}
          }
          toSeed.forEach((a) => saveFirestoreDoc('announcements', a.id, a));
          setAnnouncements(toSeed);
        } else {
          const rawItems = snapshot.docs.map((d) => d.data() as Announcement);
          // Filter out bkash/nagad deposit notice if existing in database
          const items = rawItems.filter((a) => {
            const isBkashNotice = a.id === 'ann-2' || (a.textBn && a.textBn.includes('বিকাশ ও নগদ ডিপোজিট'));
            if (isBkashNotice) {
              deleteFirestoreDoc('announcements', a.id);
              return false;
            }
            return true;
          });
          const finalItems = items.length > 0 ? items : INITIAL_ANNOUNCEMENTS;
          setAnnouncements(finalItems);
          safeSetItem('xsb_announcements', JSON.stringify(finalItems));
        }
      },
      (err) => handleFirestoreError('announcements listener', err)
    );

    // 5. Registered Users
    const unsubUsers = onSnapshot(
      collection(db, 'registered_users'),
      (snapshot) => {
        if (snapshot.empty) {
          const localSaved = safeGetItem('cb_registered_users');
          let toSeed = INITIAL_REGISTERED_USERS;
          if (localSaved) {
            try {
              const parsed = JSON.parse(localSaved);
              if (Array.isArray(parsed) && parsed.length > 0) {
                toSeed = parsed.map((u: RegisteredUser) => {
                  if (u.id === 'usr-101' || u.id === 'usr-102' || u.id === 'usr-103') {
                    return { ...u, walletBalance: 0 };
                  }
                  return u;
                });
              }
            } catch {}
          }
          toSeed.forEach((u) => saveFirestoreDoc('registered_users', u.id, u));
          setRegisteredUsers(toSeed);
        } else {
          const items = snapshot.docs.map((d) => {
            const data = d.data() as RegisteredUser;
            // Clean up legacy mock balances for default seed accounts
            if ((data.id === 'usr-101' && data.walletBalance === 12500) ||
                (data.id === 'usr-102' && data.walletBalance === 4500) ||
                (data.id === 'usr-103' && data.walletBalance === 8000)) {
              const cleaned = { ...data, walletBalance: 0 };
              saveFirestoreDoc('registered_users', cleaned.id, cleaned);
              return cleaned;
            }
            return data;
          });
          setRegisteredUsers(items);
          safeSetItem('cb_registered_users', JSON.stringify(items));
        }
      },
      (err) => handleFirestoreError('registered_users listener', err)
    );

    // 6. Site Config
    const unsubSiteConfig = onSnapshot(
      doc(db, 'store_meta', 'site_config'),
      (docSnap) => {
        if (!docSnap.exists()) {
          const localSaved = safeGetItem('cb_site_config');
          let toSeed = INITIAL_SITE_CONFIG;
          if (localSaved) {
            try {
              const parsed = JSON.parse(localSaved);
              toSeed = { ...INITIAL_SITE_CONFIG, ...parsed };
            } catch {}
          }
          saveFirestoreDoc('store_meta', 'site_config', toSeed);
          setSiteConfig(toSeed);
        } else {
          const data = docSnap.data() as SiteConfig;
          const merged = { ...INITIAL_SITE_CONFIG, ...data };
          setSiteConfig(merged);
          safeSetItem('cb_site_config', JSON.stringify(merged));
        }
      },
      (err) => handleFirestoreError('site_config listener', err)
    );

    // 7. Payment Numbers
    const unsubPaymentNumbers = onSnapshot(
      doc(db, 'store_meta', 'payment_numbers'),
      (docSnap) => {
        if (!docSnap.exists()) {
          const localSaved = safeGetItem('xsb_payment_numbers');
          let toSeed = INITIAL_PAYMENT_NUMBERS;
          if (localSaved) {
            try {
              const parsed = JSON.parse(localSaved);
              toSeed = { ...INITIAL_PAYMENT_NUMBERS, ...parsed };
            } catch {}
          }
          saveFirestoreDoc('store_meta', 'payment_numbers', toSeed);
          setPaymentNumbers(toSeed);
        } else {
          const data = docSnap.data() as any;
          const merged = { ...INITIAL_PAYMENT_NUMBERS, ...data };
          setPaymentNumbers(merged);
          safeSetItem('xsb_payment_numbers', JSON.stringify(merged));
        }
      },
      (err) => handleFirestoreError('payment_numbers listener', err)
    );

    // 8. Orders
    const unsubOrders = onSnapshot(
      collection(db, 'orders'),
      (snapshot) => {
        if (!snapshot.empty) {
          const items = snapshot.docs.map((d) => d.data() as Order);
          setOrders(items);
          safeSetItem('xsb_orders_v2', JSON.stringify(items));
        }
      },
      (err) => handleFirestoreError('orders listener', err)
    );

    // 9. Transactions
    const unsubTransactions = onSnapshot(
      collection(db, 'transactions'),
      (snapshot) => {
        if (!snapshot.empty) {
          const items = snapshot.docs.map((d) => d.data() as WalletTransaction);
          setTransactions(items);
          safeSetItem('xsb_transactions_v2', JSON.stringify(items));
        }
      },
      (err) => handleFirestoreError('transactions listener', err)
    );

    // 10. Support Tickets
    const unsubTickets = onSnapshot(
      collection(db, 'tickets'),
      (snapshot) => {
        if (!snapshot.empty) {
          const items = snapshot.docs.map((d) => d.data() as SupportTicket);
          setTickets(items);
          safeSetItem('xsb_tickets', JSON.stringify(items));
        }
      },
      (err) => handleFirestoreError('tickets listener', err)
    );

    // 11. Broadcast Push Notifications (Real-time to all devices)
    const initialSessionTime = Date.now();
    let lastProcessedTimestamp = initialSessionTime;
    const unsubPushBroadcasts = onSnapshot(
      collection(db, 'broadcast_notifications'),
      (snapshot) => {
        if (!snapshot.empty) {
          const items = snapshot.docs.map((d) => d.data() as PushBroadcast);
          items.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
          setPushBroadcasts(items);

          // Real-time Push Notification Trigger on Mobile/Desktop
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
              const notif = change.doc.data() as PushBroadcast;
              if (notif.timestamp && notif.timestamp > lastProcessedTimestamp) {
                triggerDeviceNotification(notif.title, {
                  body: notif.body,
                  icon: notif.icon,
                  image: notif.image,
                  url: notif.url,
                  tag: notif.tag || notif.id
                });
                lastProcessedTimestamp = Math.max(lastProcessedTimestamp, notif.timestamp);
              }
            }
          });
        }
      },
      (err) => handleFirestoreError('broadcast_notifications listener', err)
    );

    // 12. Real-time Security Admin Lock Listener
    const unsubAdminLock = onSnapshot(
      doc(db, 'site_security', 'admin_lock'),
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          const locked = data.locked === true;
          setIsAdminPermanentlyLocked(locked);
          setAdminLockDetails({
            locked,
            lockedAt: data.lockedAt,
            reason: data.reason
          });
          safeSetItem('cb_admin_locked_forever', locked ? 'true' : 'false');
          safeSetItem('cb_admin_lock_details', JSON.stringify({
            locked,
            lockedAt: data.lockedAt,
            reason: data.reason
          }));
        } else {
          // If deleted or not set, check local state
          const localSaved = safeGetItem('cb_admin_locked_forever') === 'true';
          if (!localSaved) {
            setIsAdminPermanentlyLocked(false);
            setAdminLockDetails({ locked: false });
          }
        }
      },
      (err) => handleFirestoreError('admin_lock listener', err)
    );

    return () => {
      unsubProducts();
      unsubCategories();
      unsubBanners();
      unsubAnnouncements();
      unsubUsers();
      unsubSiteConfig();
      unsubPaymentNumbers();
      unsubOrders();
      unsubTransactions();
      unsubTickets();
      unsubPushBroadcasts();
      unsubAdminLock();
    };
  }, []);

  const registerUser = (fullName: string, phone: string, password: string, email?: string): boolean => {
    // 1. Strict Name Validation (real letters, min 3 chars, reject dummy names)
    const nameVal = validateFullName(fullName);
    if (!nameVal.isValid) {
      addToast(
        language === 'bn' ? (nameVal.errorBn || 'সঠিক নাম লিখুন') : (nameVal.errorEn || 'Please enter valid name'),
        'error'
      );
      return false;
    }

    // 2. Strict Bangladeshi Phone Number Validation (013-019, 11 digits, reject repeated/sequential numbers)
    const phoneVal = validateBangladeshiPhone(phone);
    if (!phoneVal.isValid) {
      addToast(
        language === 'bn' ? (phoneVal.errorBn || 'সঠিক মোবাইল নম্বর দিন') : (phoneVal.errorEn || 'Please enter valid BD phone'),
        'error'
      );
      return false;
    }

    // 3. Strict Real Email Validation
    if (!email || !email.trim()) {
      addToast(
        language === 'bn' ? 'আপনার আসল জিমেইল / ইমেইল অ্যাড্রেস লিখুন!' : 'Please enter your genuine Gmail / Email!',
        'error'
      );
      return false;
    }
    const emailVal = validateRealEmail(email);
    if (!emailVal.isValid) {
      addToast(
        language === 'bn' ? (emailVal.errorBn || 'সঠিক ইমেইল অ্যাড্রেস লিখুন!') : (emailVal.errorEn || 'Please enter valid email!'),
        'error'
      );
      return false;
    }

    // 4. Password validation (min 6 characters)
    const cleanPass = password.trim();
    if (cleanPass.length < 6) {
      addToast(
        language === 'bn' ? 'পাসওয়ার্ড সর্বনিম্ন ৬ ডিজিটের হতে হবে!' : 'Password must be at least 6 characters!',
        'error'
      );
      return false;
    }

    const cleanPhone = phoneVal.normalizedPhone;
    const cleanName = nameVal.normalizedName;
    const cleanEmail = emailVal.normalizedEmail;

    // 5. Check if mobile number is already registered
    const existingByPhone = registeredUsers.find((u) => {
      const uPhoneVal = validateBangladeshiPhone(u.phone);
      return (uPhoneVal.isValid && uPhoneVal.normalizedPhone === cleanPhone) || u.phone.trim() === cleanPhone;
    });

    if (existingByPhone) {
      addToast(
        language === 'bn'
          ? 'এই মোবাইল নম্বর দিয়ে ইতিমধ্যে অ্যাকাউন্ট তৈরি রয়েছে! দয়া করে "লগইন করুন" ট্যাবে যান।'
          : 'Mobile number already registered! Please switch to Login tab.',
        'error'
      );
      return false;
    }

    // 6. Check if email is already registered
    const existingByEmail = registeredUsers.find((u) => u.email && u.email.toLowerCase() === cleanEmail);
    if (existingByEmail) {
      addToast(
        language === 'bn'
          ? 'এই ইমেইল দিয়ে ইতিমধ্যে অ্যাকাউন্ট রয়েছে! দয়া করে লগইন করুন বা অন্য ইমেইল দিন।'
          : 'Email address already registered! Please login or use a different email.',
        'error'
      );
      return false;
    }

    const newUser: RegisteredUser = {
      id: 'usr-' + Date.now(),
      name: cleanName,
      phone: cleanPhone,
      email: cleanEmail,
      password: cleanPass,
      registeredAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      walletBalance: 0
    };

    setRegisteredUsers((prev) => {
      const updated = [newUser, ...prev.filter((u) => u.id !== newUser.id)];
      safeSetItem('cb_registered_users', JSON.stringify(updated));
      return updated;
    });
    saveFirestoreDoc('registered_users', newUser.id, newUser);

    sendTelegramRegistrationNotification({
      name: newUser.name,
      phone: newUser.phone,
      email: newUser.email,
      registeredAt: newUser.registeredAt
    });

    const activeUser: UserProfile = {
      ...INITIAL_USER,
      name: cleanName,
      phone: cleanPhone,
      email: cleanEmail,
      walletBalance: 0
    };

    setUser(activeUser);
    setIsUserLoggedIn(true);
    safeSetItem('xsb_user', JSON.stringify(activeUser));
    safeSetItem('cb_is_logged_in', 'true');

    addToast(
      language === 'bn'
        ? `স্বাগতম, ${cleanName}! অ্যাকাউন্ট রেজিস্ট্রেশন সফল হয়েছে।`
        : `Welcome, ${cleanName}! Registration successful.`,
      'success'
    );
    return true;
  };

  const loginUser = (identifier: string, password: string): boolean => {
    const rawCleanId = identifier.trim();
    const cleanId = normalizeBnDigits(rawCleanId);
    const cleanPass = password.trim();

    if (!cleanId) {
      addToast(
        language === 'bn' ? 'আপনার মোবাইল নম্বর বা ইমেইল লিখুন' : 'Please enter your mobile number or email',
        'error'
      );
      return false;
    }

    // Retrieve users from in-memory state or fallback to localStorage
    let currentUsers = [...registeredUsers];
    const savedLocalUsers = safeGetItem('cb_registered_users');
    if (savedLocalUsers) {
      try {
        const parsed: RegisteredUser[] = JSON.parse(savedLocalUsers);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge to ensure no missing newly registered user
          const map = new Map<string, RegisteredUser>();
          currentUsers.forEach((u) => map.set(u.id, u));
          parsed.forEach((u) => map.set(u.id, u));
          currentUsers = Array.from(map.values());
        }
      } catch {}
    }

    const isEmailInput = cleanId.includes('@');
    const inputNormalizedPhone = normalizePhoneNumber(cleanId);
    const lowerInput = cleanId.toLowerCase();

    const found = currentUsers.find((u) => {
      // 1. Email matching
      if (u.email && u.email.trim().toLowerCase() === lowerInput) {
        return true;
      }
      // 2. Phone matching (normalized & flexible)
      const uNormalizedPhone = normalizePhoneNumber(u.phone || '');
      if (inputNormalizedPhone && uNormalizedPhone && inputNormalizedPhone === uNormalizedPhone) {
        return true;
      }
      if (u.phone && (u.phone.trim() === cleanId || normalizeBnDigits(u.phone.trim()) === cleanId)) {
        return true;
      }
      // Last 10 or 11 digits match
      if (inputNormalizedPhone.length >= 10 && uNormalizedPhone.length >= 10) {
        if (inputNormalizedPhone.slice(-10) === uNormalizedPhone.slice(-10)) {
          return true;
        }
      }
      // 3. Name / Username matching (case-insensitive)
      if (u.name && u.name.trim().toLowerCase() === lowerInput) {
        return true;
      }
      return false;
    });

    if (found) {
      if (found.isBlocked) {
        addToast(
          language === 'bn'
            ? 'আপনার অ্যাকাউন্টটি ব্লক করা হয়েছে! হেল্পলাইন বা হোয়াটসঅ্যাপে যোগাযোগ করুন।'
            : 'Your account has been blocked! Please contact support.',
          'error'
        );
        return false;
      }

      // If user originally signed up via Google only (no custom password set)
      if (!found.password && (found.id?.startsWith('g-') || found.phone === 'Google Account')) {
        addToast(
          language === 'bn'
            ? 'এই অ্যাকাউন্টটি গুগল দিয়ে তৈরি। অনুগ্রহ করে "Sign in with Google" বাটনে ক্লিক করে লগইন করুন।'
            : 'This account was created with Google. Please use "Sign in with Google" button.',
          'info'
        );
        return false;
      }

      const storedPass = (found.password || '').trim();
      if (storedPass === cleanPass) {
        const loggedInUser: UserProfile = {
          ...INITIAL_USER,
          name: found.name,
          phone: found.phone,
          email: found.email,
          walletBalance: found.walletBalance ?? 0,
          isBlocked: found.isBlocked || false
        };
        setUser(loggedInUser);
        setIsUserLoggedIn(true);
        safeSetItem('xsb_user', JSON.stringify(loggedInUser));
        safeSetItem('cb_is_logged_in', 'true');
        addToast(
          language === 'bn'
            ? `স্বাগতম, ${found.name}! লগইন সফল হয়েছে।`
            : `Welcome back, ${found.name}! Login successful.`,
          'success'
        );
        return true;
      } else {
        addToast(
          language === 'bn' ? 'পাসওয়ার্ড ভুল হয়েছে! সঠিক পাসওয়ার্ড দিন।' : 'Incorrect password! Please try again.',
          'error'
        );
        return false;
      }
    } else {
      addToast(
        language === 'bn'
          ? (isEmailInput ? 'এই ইমেইল দিয়ে কোনো অ্যাকাউন্ট পাওয়া যায়নি।' : 'এই মোবাইল নম্বর বা অ্যাকাউন্টের তথ্য পাওয়া যায়নি। সঠিক তথ্য দিন বা রেজিস্ট্রেশন করুন।')
          : (isEmailInput ? 'No account found with this email.' : 'No account found with this phone number. Please register.'),
        'error'
      );
      return false;
    }
  };

  // Google Login & Registration flow
  const loginWithGoogle = async (): Promise<boolean> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const gUser = result.user;
      if (!gUser) {
        addToast(language === 'bn' ? 'গুগল সাইন-ইন সম্পন্ন হয়নি।' : 'Google sign-in incomplete.', 'error');
        return false;
      }

      const gEmail = (gUser.email || '').toLowerCase().trim();
      const gName = gUser.displayName || (gEmail ? gEmail.split('@')[0] : 'Google User');
      const gUid = gUser.uid;
      const gPhone = gUser.phoneNumber || 'Google Account';

      // Check if user already exists
      const existing = registeredUsers.find(
        (u) => (gEmail && u.email && u.email.toLowerCase() === gEmail) || u.id === `g-${gUid}`
      );

      if (existing) {
        if (existing.isBlocked) {
          addToast(
            language === 'bn'
              ? 'আপনার অ্যাকাউন্টটি ব্লক করা হয়েছে! হেল্পলাইন বা হোয়াটসঅ্যাপে যোগাযোগ করুন।'
              : 'Your account has been blocked! Please contact support.',
            'error'
          );
          return false;
        }

        const activeUser: UserProfile = {
          ...INITIAL_USER,
          name: existing.name || gName,
          phone: existing.phone || gPhone,
          email: existing.email || gEmail,
          walletBalance: existing.walletBalance ?? 0,
          isBlocked: false
        };

        setUser(activeUser);
        setIsUserLoggedIn(true);
        safeSetItem('xsb_user', JSON.stringify(activeUser));
        safeSetItem('cb_is_logged_in', 'true');

        addToast(
          language === 'bn'
            ? `স্বাগতম, ${activeUser.name}! গুগল দিয়ে লগইন সফল হয়েছে।`
            : `Welcome back, ${activeUser.name}! Logged in with Google.`,
          'success'
        );
        return true;
      }

      // New Google User Registration
      const newUser: RegisteredUser = {
        id: 'g-' + gUid,
        name: gName,
        phone: gPhone,
        email: gEmail,
        registeredAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
        walletBalance: 0
      };

      setRegisteredUsers((prev) => [newUser, ...prev]);
      saveFirestoreDoc('registered_users', newUser.id, newUser);

      sendTelegramRegistrationNotification({
        name: `${newUser.name} (Google Account)`,
        phone: newUser.phone,
        email: newUser.email,
        registeredAt: newUser.registeredAt
      });

      const activeUser: UserProfile = {
        ...INITIAL_USER,
        name: gName,
        phone: gPhone,
        email: gEmail,
        walletBalance: 0
      };

      setUser(activeUser);
      setIsUserLoggedIn(true);
      safeSetItem('xsb_user', JSON.stringify(activeUser));
      safeSetItem('cb_is_logged_in', 'true');

      addToast(
        language === 'bn'
          ? `স্বাগতম, ${gName}! গুগল দিয়ে রেজিস্ট্রেশন ও লগইন সফল হয়েছে।`
          : `Welcome, ${gName}! Google Registration & Login successful.`,
        'success'
      );
      return true;
    } catch (error: any) {
      if (error?.code === 'auth/popup-closed-by-user' || error?.code === 'auth/cancelled-popup-request') {
        return false;
      }
      console.error('Google Sign-in error:', error);
      addToast(
        language === 'bn'
          ? 'গুগল সাইন-ইন সম্পন্ন করা যায়নি। অনুগ্রহ করে মোবাইল ও পাসওয়ার্ড দিয়ে চেষ্টা করুন।'
          : 'Google sign-in could not be completed. Please try with phone and password.',
        'error'
      );
      return false;
    }
  };

  const logoutUser = () => {
    setIsUserLoggedIn(false);
    setUser(INITIAL_USER);
    safeSetItem('cb_is_logged_in', 'false');
    safeSetItem('xsb_user', JSON.stringify(INITIAL_USER));
    addToast(
      language === 'bn' ? 'আপনার অ্যাকাউন্টটি লগআউট করা হয়েছে।' : 'Account logged out successfully.',
      'info'
    );
  };

  const verifyAdminApiKey = (keyInput: string): boolean => {
    const trimmed = keyInput.trim();
    const activeApiKey = (siteConfig.adminApiKey || 'CB-ADMIN-SECURE-998877-KEY').trim();
    const fallbackPin = (siteConfig.adminPin || '258258').trim();

    if (trimmed && (trimmed === activeApiKey || trimmed === fallbackPin)) {
      setIsAdminAuthenticated(true);
      return true;
    }

    addToast(
      language === 'bn'
        ? 'ভুল API Key! অনুগ্রহ করে সঠিক API Key প্রদান করুন।'
        : 'Invalid API Key! Please enter your valid authorization key.',
      'error'
    );
    return false;
  };

  const verifyAdminPin = (input: string): boolean => {
    return verifyAdminApiKey(input);
  };

  const unlockAdminWithMasterKey = (secretKey: string): boolean => {
    const clean = secretKey.trim();
    const activeMasterKey = (siteConfig.adminMasterKey || 'MASTER#3690#JJ').trim();
    const ownerEmail = (siteConfig.ownerRecoveryEmail || 'jjtrader3690@gmail.com').trim().toLowerCase();

    // Validated against configured master key, owner email, or emergency key
    const isMasterMatch =
      clean === activeMasterKey ||
      clean.toLowerCase() === ownerEmail ||
      clean === 'MASTER#3690#JJ' ||
      clean === 'JJTRADER#3690' ||
      clean === '36903690';

    if (isMasterMatch) {
      const unlockedData = {
        locked: false,
        unlockedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
        reason: 'Master Recovery by Owner'
      };

      setIsAdminPermanentlyLocked(false);
      setAdminLockDetails(unlockedData);
      safeSetItem('cb_admin_locked_forever', 'false');
      safeSetItem('cb_admin_lock_details', JSON.stringify(unlockedData));
      saveFirestoreDoc('site_security', 'admin_lock', unlockedData);
      setIsAdminAuthenticated(true);
      sendTelegramSecurityRestored();

      addToast(
        language === 'bn'
          ? '👑 প্রধান ওনারের মাস্টার কি ভেরিফাইড! অ্যাডমিন প্যানেল সফলভাবে আনলক ও রিস্টোর করা হয়েছে।'
          : '👑 Owner Master Key Verified! Admin panel unlocked & restored successfully.',
        'success'
      );
      return true;
    }

    addToast(
      language === 'bn'
        ? '❌ ভুল মাস্টার সিক্রেট কি! শুধুমাত্র প্রধান ওনারের সঠিক মাস্টার কি গ্রহণযোগ্য।'
        : '❌ Invalid Master Recovery Key! Access Denied.',
      'error'
    );
    return false;
  };

  const adminLockPermanently = (reason = 'Manual Security Lockdown') => {
    const lockData = {
      locked: true,
      lockedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      reason
    };
    setIsAdminPermanentlyLocked(true);
    setAdminLockDetails(lockData);
    safeSetItem('cb_admin_locked_forever', 'true');
    safeSetItem('cb_admin_lock_details', JSON.stringify(lockData));
    saveFirestoreDoc('site_security', 'admin_lock', lockData);
    setIsAdminAuthenticated(false);
    sendTelegramSecurityAlert(reason);
    addToast(
      language === 'bn' ? '🚨 অ্যাডমিন প্যানেল চিরজীবনের জন্য লক করা হয়েছে।' : '🚨 Admin panel permanently locked.',
      'error'
    );
  };

  const adminUnlockPermanently = () => {
    unlockAdminWithMasterKey(siteConfig.adminMasterKey || 'MASTER#3690#JJ');
  };

  const adminUpdateSiteConfig = (newSettings: Partial<SiteConfig>) => {
    setSiteConfig((prev) => {
      const updated = { ...prev, ...newSettings };
      safeSetItem('cb_site_config', JSON.stringify(updated));
      saveFirestoreDoc('store_meta', 'site_config', updated);
      return updated;
    });
    addToast(
      language === 'bn' ? 'ওয়েবসাইটের সেটিংস সফলভাবে আপডেট করা হয়েছে!' : 'Website settings updated successfully!',
      'success'
    );
  };

  // Sync state to local storage
  useEffect(() => {
    safeSetItem('cb_site_config', JSON.stringify(siteConfig));
  }, [siteConfig]);

  useEffect(() => {
    safeSetItem('cb_visitor_stats', JSON.stringify(visitorStats));
  }, [visitorStats]);

  // Dynamic Browser Favicon Updater
  useEffect(() => {
    const logo = siteConfig.logoUrl || '/favicon.png';
    const appleLogo = siteConfig.logoUrl || '/apple-touch-icon.png';
    try {
      let faviconLink = document.querySelector("link[rel='icon']") as HTMLLinkElement;
      if (!faviconLink) {
        faviconLink = document.createElement('link');
        faviconLink.rel = 'icon';
        document.head.appendChild(faviconLink);
      }
      faviconLink.href = logo;

      let appleLink = document.querySelector("link[rel='apple-touch-icon']") as HTMLLinkElement;
      if (!appleLink) {
        appleLink = document.createElement('link');
        appleLink.rel = 'apple-touch-icon';
        document.head.appendChild(appleLink);
      }
      appleLink.href = appleLogo;
    } catch (e) {
      console.warn('Favicon update error:', e);
    }
  }, [siteConfig.logoUrl]);

  // Register Service Worker for PWA and Push Notifications
  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker
        .register('/sw.js')
        .then((reg) => {
          console.log('CODE BAZAR Service Worker registered:', reg.scope);
        })
        .catch((err) => {
          console.warn('Service Worker registration error:', err);
        });
    }
  }, []);

  // System Device Push Notification Trigger & In-App Heads-Up Notification
  const triggerDeviceNotification = async (
    title: string,
    options?: {
      body?: string;
      icon?: string;
      image?: string;
      url?: string;
      tag?: string;
    }
  ): Promise<boolean> => {
    // 1. Vibrate physical mobile device if hardware supported
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([200, 100, 200, 100, 200]);
      } catch {}
    }

    // 3. Always show interactive floating Heads-Up Android Notification banner on screen
    const alertId = options?.tag || 'alert-' + Date.now();
    const pushAlertObj: PushBroadcast = {
      id: alertId,
      title: title,
      body: options?.body || 'CODE BAZAR স্টোরে নতুন আপডেট এসেছে!',
      icon: options?.icon || siteConfig.logoUrl || '/icon-192.png',
      image: options?.image,
      url: options?.url || '/',
      createdAt: new Date().toISOString(),
      timestamp: Date.now()
    };
    setActivePushAlert(pushAlertObj);

    // Auto dismiss in-app notification after 8 seconds
    setTimeout(() => {
      setActivePushAlert((current) => (current?.id === alertId ? null : current));
    }, 8000);

    // 4. Trigger Native OS / Android Status Bar & Lock Screen Notification
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        const fullIconUrl = options?.icon || (siteConfig.logoUrl?.startsWith('http') ? siteConfig.logoUrl : new URL(siteConfig.logoUrl || '/icon-192.png', window.location.href).href);
        const notifOptions: any = {
          body: options?.body || 'CODE BAZAR স্টোরে নতুন আপডেট এসেছে!',
          icon: fullIconUrl,
          badge: new URL('/favicon.png', window.location.href).href,
          image: options?.image,
          data: { url: options?.url || '/' },
          tag: options?.tag || 'codebazar-' + Date.now(),
          vibrate: [200, 100, 200, 100, 200],
          renotify: true
        };

        try {
          if ('serviceWorker' in navigator) {
            const reg = await navigator.serviceWorker.ready;
            if (reg && reg.showNotification) {
              await reg.showNotification(title, notifOptions);
              return true;
            }
          }
          new Notification(title, notifOptions);
          return true;
        } catch (e) {
          try {
            new Notification(title, notifOptions);
            return true;
          } catch {}
        }
      }
    }

    return true;
  };

  const requestPushNotificationPermission = async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      addToast(
        language === 'bn'
          ? 'আপনার ডিভাইসে ব্রাউজার পুশ নোটিফিকেশন সমর্থিত নয়।'
          : 'Push notifications are not supported in this browser.',
        'info'
      );
      return false;
    }

    try {
      const permission = await Notification.requestPermission();
      setPushNotificationPermission(permission);
      if (permission === 'granted') {
        addToast(
          language === 'bn'
            ? '🎉 নোটিফিকেশন চালু হয়েছে! নতুন ওয়েবসাইট ও স্ক্রিপ্ট আপলোড হলেই আপনার ফোনে নোটিফিকেশন পাবেন।'
            : '🎉 Notifications enabled! You will get alerts for new products on your phone.',
          'success'
        );
        // Trigger a welcoming notification
        triggerDeviceNotification('CODE BAZAR - নোটিফিকেশন চালু হয়েছে! 🔔', {
          body: 'ধন্যবাদ! নতুন প্রোডাক্ট, আকর্ষণীয় অফার বা আপডেট আসলে সরাসরি আপনার ফোনের স্ক্রিনে দেখতে পাবেন।',
          icon: siteConfig.logoUrl || '/icon-192.png',
          image: '/icon-512.png',
          url: '/'
        });
        return true;
      } else if (permission === 'denied') {
        addToast(
          language === 'bn'
            ? 'নোটিফিকেশন পারমিশন বন্ধ করা রয়েছে। ব্রাউজার সাইট সেটিং থেকে এলাউ করতে পারেন।'
            : 'Notification permission blocked. Enable from browser site settings.',
          'error'
        );
        return false;
      }
    } catch (err) {
      console.error('Request notification permission error:', err);
    }
    return false;
  };

  const adminSendPushBroadcast = async (broadcastData: {
    title: string;
    body: string;
    image?: string;
    url?: string;
  }): Promise<boolean> => {
    if (!broadcastData.title?.trim() || !broadcastData.body?.trim()) {
      addToast(
        language === 'bn' ? 'দয়া করে নোটিফিকেশনের শিরোনাম ও মেসেজ লিখুন' : 'Please enter title and body',
        'error'
      );
      return false;
    }

    const newPush: PushBroadcast = {
      id: 'push-' + Date.now(),
      title: broadcastData.title.trim(),
      body: broadcastData.body.trim(),
      icon: siteConfig.logoUrl || '/icon-192.png',
      image: broadcastData.image?.trim() || undefined,
      url: broadcastData.url?.trim() || '/',
      createdAt: new Date().toISOString(),
      timestamp: Date.now(),
      tag: 'broadcast-' + Date.now()
    };

    try {
      await saveFirestoreDoc('broadcast_notifications', newPush.id, newPush);
      // Trigger locally
      triggerDeviceNotification(newPush.title, {
        body: newPush.body,
        image: newPush.image,
        icon: newPush.icon,
        url: newPush.url,
        tag: newPush.tag
      });
      addToast(
        language === 'bn'
          ? '🚀 সকল ইউজারের ফোনে পুশ নোটিফিকেশন সফলভাবে ব্রডকাস্ট করা হয়েছে!'
          : '🚀 Push notification broadcast sent to all registered devices successfully!',
        'success'
      );
      return true;
    } catch (err: any) {
      addToast(
        language === 'bn' ? `পুশ নোটিফিকেশন ব্যর্থ: ${err.message}` : `Broadcast error: ${err.message}`,
        'error'
      );
      return false;
    }
  };

  const adminTestPushNotification = async (data?: {
    title?: string;
    body?: string;
    image?: string;
  }): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      addToast(
        language === 'bn' ? 'এই ব্রাউজারে পুশ নোটিফিকেশন সুবিধা নেই।' : 'Notifications not supported.',
        'error'
      );
      return false;
    }

    if (Notification.permission !== 'granted') {
      const granted = await requestPushNotificationPermission();
      if (!granted) {
        addToast(
          language === 'bn'
            ? 'দয়া করে নোটিফিকেশন এলাউ (Allow) করুন টেস্ট নোটিফিকেশন পাওয়ার জন্য।'
            : 'Please allow notification permission to test.',
          'info'
        );
        return false;
      }
    }

    const testTitle = data?.title?.trim() || 'CODE BAZAR - নতুন প্রিমিয়াম বেটিং সাইট যুক্ত হয়েছে! 🔥';
    const testBody =
      data?.body?.trim() ||
      'ক্যাসিনো ও স্পোর্টস বেটিং ফুল কমপ্লিট সোর্স কোড মাত্র ৳১৫০০ টাকায় পাওয়া যাচ্ছে। বিস্তারিত দেখতে ও অর্ডার করতে এখনই ট্যাপ করুন!';
    const testImage =
      data?.image?.trim() ||
      'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&auto=format&fit=crop&q=80';

    const success = await triggerDeviceNotification(testTitle, {
      body: testBody,
      image: testImage,
      icon: siteConfig.logoUrl || '/icon-192.png',
      url: '/',
      tag: 'test-' + Date.now()
    });

    if (success) {
      addToast(
        language === 'bn'
          ? '🎉 আপনার ফোনের স্ক্রিনে/লকস্ক্রিনে টেস্ট নোটিফিকেশন পাঠানো হয়েছে! চেক করুন।'
          : '🎉 Test notification sent to your device screen/notification tray!',
        'success'
      );
      return true;
    } else {
      addToast(
        language === 'bn' ? 'নোটিফিকেশন প্রদর্শন করা যায়নি।' : 'Failed to display notification.',
        'error'
      );
      return false;
    }
  };
  useEffect(() => {
    try {
      const todayKey = new Date().toISOString().split('T')[0];
      const hasVisitedSession = sessionStorage.getItem('cb_visited_session');
      
      setVisitorStats((prev) => {
        const isNewUnique = !hasVisitedSession;
        if (isNewUnique) {
          sessionStorage.setItem('cb_visited_session', 'true');
        }
        
        const daily = { ...(prev.dailyVisits || {}) };
        daily[todayKey] = (daily[todayKey] || 0) + 1;

        const isSameDay = prev.lastVisitAt ? prev.lastVisitAt.startsWith(todayKey) : false;
        const newTodayVisits = isSameDay ? prev.todayVisits + 1 : 1;

        const updated: VisitorStats = {
          ...prev,
          totalVisits: prev.totalVisits + 1,
          todayVisits: newTodayVisits,
          uniqueVisitors: isNewUnique ? prev.uniqueVisitors + 1 : prev.uniqueVisitors,
          liveVisitors: Math.max(1, (prev.liveVisitors || 12) + (Math.floor(Math.random() * 3) - 1)),
          lastVisitAt: new Date().toISOString(),
          dailyVisits: daily
        };
        
        safeSetItem('cb_visitor_stats', JSON.stringify(updated));
        saveFirestoreDoc('site_stats', 'visitors', updated);
        return updated;
      });
    } catch (err) {
      console.warn('Visitor counter init error:', err);
    }
  }, []);

  // Listen to Firestore real-time visitor stats
  useEffect(() => {
    if (!db) return;
    try {
      const unsub = onSnapshot(doc(db, 'site_stats', 'visitors'), (snap) => {
        if (snap.exists()) {
          const data = snap.data() as VisitorStats;
          if (data && typeof data.totalVisits === 'number') {
            setVisitorStats((prev) => ({
              ...prev,
              ...data
            }));
          }
        }
      }, (err) => handleFirestoreError('visitor listener', err));
      return () => unsub();
    } catch (e) {
      console.warn('Firestore visitor listener failed:', e);
    }
  }, []);

  useEffect(() => {
    safeSetItem('xsb_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    safeSetItem('xsb_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    safeSetItem('xsb_orders_v2', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    safeSetItem('xsb_transactions_v2', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    safeSetItem('xsb_announcements', JSON.stringify(announcements));
  }, [announcements]);

  useEffect(() => {
    safeSetItem('xsb_payment_numbers', JSON.stringify(paymentNumbers));
  }, [paymentNumbers]);

  useEffect(() => {
    safeSetItem('xsb_view_mode', viewMode);
  }, [viewMode]);

  useEffect(() => {
    safeSetItem('xsb_tickets', JSON.stringify(tickets));
  }, [tickets]);

  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Add money request with strict verification and admin approval logic
  const addMoneyRequest = (amount: number, method: PaymentMethod, param3: string, param4?: string): boolean => {
    let trxIdVal = '';
    let mobileVal = '';

    if (param4 !== undefined) {
      mobileVal = param3;
      trxIdVal = param4;
    } else {
      trxIdVal = param3;
      mobileVal = user.phone || '';
    }

    if (amount <= 0) {
      addToast(language === 'bn' ? 'সঠিক ডিপোজিট পরিমাণ দিন।' : 'Enter valid deposit amount.', 'error');
      return false;
    }

    // 1. Strict Real Transaction ID Validation (Format, Fake Patterns & Duplicate Check)
    const existingTrxList = transactions.map((t) => t.trxId || '');
    const trxVal = validateTransactionId(trxIdVal, existingTrxList, method);
    if (!trxVal.isValid) {
      addToast(
        language === 'bn'
          ? (trxVal.errorBn || '❌ ভুল Transaction ID! সঠিক ট্রানজেকশন আইডি দিন।')
          : (trxVal.errorEn || '❌ Invalid Transaction ID! Please enter valid TrxID.'),
        'error'
      );
      return false;
    }

    const cleanTrx = trxVal.normalizedTrx;
    const cleanSender = user.phone || mobileVal || 'N/A';

    // All money deposit requests go to PENDING state - Money is NEVER credited automatically
    // The store owner / admin must check their bKash/Nagad app statement and manually click Approve in Admin Panel
    const newTx: WalletTransaction = {
      id: 'tx-' + Date.now(),
      type: 'deposit',
      amount,
      method,
      userId: user.id || undefined,
      userEmail: user.email || undefined,
      userName: user.name || undefined,
      trxId: cleanTrx,
      senderMobile: cleanSender,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending',
      descriptionBn: `${method.toUpperCase()} ডিপোজিট রিকোয়েস্ট (TrxID: ${cleanTrx})`,
      descriptionEn: `${method.toUpperCase()} Deposit Request (TrxID: ${cleanTrx})`,
      bonusAmount: 0
    };

    setTransactions((prev) => [newTx, ...prev]);
    saveFirestoreDoc('transactions', newTx.id, newTx);

    sendTelegramDepositNotification({
      userName: user.name || 'ইউজার',
      userPhone: cleanSender,
      method: method,
      amount: amount,
      trxId: cleanTrx,
      senderMobile: cleanSender,
      date: newTx.date
    });

    addToast(
      language === 'bn'
        ? `✅ আপনার ডিপোজিট রিকোয়েস্ট সফলভাবে জমা হয়েছে (TrxID: ${cleanTrx})। এডমিন ভেরিফাই করে ব্যালেন্স যুক্ত করবেন।`
        : `✅ Deposit request submitted (TrxID: ${cleanTrx}). Admin will verify and credit balance.`,
      'success'
    );

    return true;
  };

  // Telegram Notification Handlers
  const sendTelegramOrderNotification = (orderData: {
    productTitle: string;
    variantName: string;
    price: number;
    paidAmount: number;
    userEmail: string;
    domain: string;
    userPhone: string;
    orderNumber: string;
    paymentMethod?: string;
    trxId?: string;
  }) => {
    const token = (siteConfig.telegramOrderBotToken || siteConfig.telegramBotToken)?.trim();
    const chatId = siteConfig.telegramChatId?.trim();
    const enabled = siteConfig.telegramNotifyEnabled ?? true;

    if (!enabled || !token || !chatId) {
      return;
    }

    const messageText = `🔔 নতুন অর্ডার এসেছে!
📦 প্রোডাক্ট: ${orderData.productTitle} (${orderData.variantName})
💰 মূল্য: ${orderData.price} ৳
💵 পেইড অ্যামাউন্ট: ${orderData.paidAmount} ৳
📧 ইউজার জিমেইল: ${orderData.userEmail || 'N/A'}
🌐 ডোমেইন: ${orderData.domain || 'N/A'}
📞 মোবাইল নাম্বার: ${orderData.userPhone || 'N/A'}`;

    fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: messageText
      })
    }).catch((err) => {
      console.error('Telegram order notification error:', err);
    });
  };

  const sendTelegramRegistrationNotification = (userData: {
    name: string;
    phone: string;
    email: string;
    registeredAt: string;
  }) => {
    // Only use Registration Bot Token if provided, else fallback to default bot token
    const token = (siteConfig.telegramRegistrationBotToken || siteConfig.telegramBotToken)?.trim();
    // Only send to Registration Chat ID, or fallback to main chat ID if registration ID is not set
    const chatId = (siteConfig.telegramRegistrationChatId || siteConfig.telegramChatId)?.trim();
    const enabled = siteConfig.telegramNotifyEnabled ?? true;

    if (!enabled || !token || !chatId) return;

    const messageText = `👤 নতুন ইউজার রেজিস্ট্রেশন!
📛 নাম: ${userData.name}
📞 মোবাইল নাম্বার: ${userData.phone}
📧 ইমেইল: ${userData.email}
⏰ তারিখ: ${userData.registeredAt}`;

    fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: messageText })
    }).catch((err) => {
      console.error('Telegram registration notification error:', err);
    });
  };

  const sendTelegramDepositNotification = (depositData: {
    userName: string;
    userPhone: string;
    method: string;
    amount: number;
    trxId: string;
    senderMobile: string;
    date: string;
  }) => {
    // Only use Deposit Bot Token if provided, else fallback to default bot token
    const token = (siteConfig.telegramDepositBotToken || siteConfig.telegramBotToken)?.trim();
    const methodLower = depositData.method.toLowerCase();
    
    // Choose the target deposit channel based on payment method
    let targetChatId = '';
    if (methodLower === 'bkash' && siteConfig.telegramBkashChatId?.trim()) {
      targetChatId = siteConfig.telegramBkashChatId.trim();
    } else if (methodLower === 'nagad' && siteConfig.telegramNagadChatId?.trim()) {
      targetChatId = siteConfig.telegramNagadChatId.trim();
    } else if (methodLower === 'rocket' && siteConfig.telegramRocketChatId?.trim()) {
      targetChatId = siteConfig.telegramRocketChatId.trim();
    }

    // If specific method channel not provided, use general deposit channel, or fallback to main order chat ID
    if (!targetChatId) {
      targetChatId = (siteConfig.telegramDepositChatId || siteConfig.telegramChatId || '')?.trim();
    }

    const enabled = siteConfig.telegramNotifyEnabled ?? true;

    // Strict safety check: Never send deposit alert if no target deposit channel or token configured
    if (!enabled || !token || !targetChatId) return;

    const messageText = `💵 নতুন ডিপোজিট রিকোয়েস্ট (${depositData.method.toUpperCase()})!
👤 ইউজার নাম: ${depositData.userName}
📞 ইউজার ফোন: ${depositData.userPhone}
💳 পেমেন্ট মেথড: ${depositData.method.toUpperCase()}
💰 ডিপোজিট পরিমাণ: ${depositData.amount} ৳
🔢 TrxID: ${depositData.trxId}
📱 সেন্ডার নাম্বার: ${depositData.senderMobile}
⏰ তারিখ: ${depositData.date}`;

    fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: targetChatId, text: messageText })
    }).catch((err) => {
      console.error('Telegram deposit notification error:', err);
    });
  };

  const sendTelegramSecurityAlert = (reason: string) => {
    const token = (siteConfig.telegramOrderBotToken || siteConfig.telegramBotToken)?.trim();
    const chatId = (siteConfig.telegramChatId)?.trim();
    const enabled = siteConfig.telegramNotifyEnabled ?? true;
    if (!enabled || !token || !chatId) return;

    const message = `🚨🚨🚨 [জরুরি সিকিউরিটি এলার্ট - CODE BAZAR] 🚨🚨🚨
⚠️ এডমিন প্যানেলে ভুল পাসওয়ার্ড দিয়ে অননুমোদিত প্রবেশের চেষ্টা করা হয়েছে!
🔒 ব্যবস্থা: ১ বার ভুল পাসওয়ার্ড দেওয়ার কারণে অ্যাডমিন প্যানেল চিরজীবনের জন্য ব্লক (Permanent Lifetime Locked) করা হয়েছে।
🕒 সময়: ${new Date().toISOString().replace('T', ' ').substring(0, 19)}
👑 আনলক পদ্ধতি: শুধুমাত্র প্রধান ওনারের সিক্রেট মাস্টার কি (Master Recovery Key) দিয়ে রিকভারি সম্ভব।`;

    fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: message })
    }).catch((err) => console.error('Telegram security alert error:', err));
  };

  const sendTelegramSecurityRestored = () => {
    const token = (siteConfig.telegramOrderBotToken || siteConfig.telegramBotToken)?.trim();
    const chatId = (siteConfig.telegramChatId)?.trim();
    const enabled = siteConfig.telegramNotifyEnabled ?? true;
    if (!enabled || !token || !chatId) return;

    const message = `✅✅✅ [সিকিউরিটি রিস্টোর - CODE BAZAR] ✅✅✅
👑 প্রধান ওনার কর্তৃক মাস্টার কি দিয়ে এডমিন প্যানেল সফলভাবে আনলক ও রিস্টোর করা হয়েছে।
🕒 সময়: ${new Date().toISOString().replace('T', ' ').substring(0, 19)}
🛡️ বর্তমান স্ট্যাটাস: সিস্টেম আনলকড ও সচল।`;

    fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: message })
    }).catch((err) => console.error('Telegram security restored error:', err));
  };

  const adminTestTelegramNotification = async (
    testToken?: string,
    testChatId?: string,
    testType: 'order' | 'registration' | 'deposit' | 'bkash' | 'nagad' | 'rocket' = 'order'
  ): Promise<boolean> => {
    const token = (testToken || siteConfig.telegramBotToken)?.trim();
    const chatId = (testChatId || siteConfig.telegramChatId)?.trim();

    if (!token || !chatId) {
      addToast(
        language === 'bn'
          ? 'দয়া করে টেলিগ্রাম Bot Token এবং Channel ID বসান!'
          : 'Please enter Telegram Bot Token and Channel ID!',
        'error'
      );
      return false;
    }

    let testMessage = '';
    if (testType === 'registration') {
      testMessage = `👤 [টেস্ট নোটিফিকেশন] নতুন ইউজার রেজিস্ট্রেশন
📛 নাম: টেস্ট ইউজার
📞 মোবাইল: 01836828065
📧 ইমেইল: testuser@gmail.com
⏰ তারিখ: ${new Date().toISOString().replace('T', ' ').substring(0, 16)}
✅ আপনার রেজিস্ট্রেশন টেলিগ্রাম বট ও চ্যানেল নোটিফিকেশন সফলভাবে কাজ করছে!`;
    } else if (testType === 'deposit' || testType === 'bkash' || testType === 'nagad' || testType === 'rocket') {
      const methodName = testType === 'bkash' ? 'bKash' : testType === 'nagad' ? 'Nagad' : testType === 'rocket' ? 'Rocket' : 'WALLET';
      testMessage = `💵 [টেস্ট নোটিফিকেশন] নতুন ডিপোজিট রিকোয়েস্ট (${methodName})
👤 ইউজার: টেস্ট কাস্টমার
📞 ফোন: 01836828065
💳 মেথড: ${methodName}
💰 পরিমাণ: ৫০০ ৳
🔢 TrxID: 9X8K2LA102
📱 সেন্ডার নাম্বার: 01879940191
⏰ তারিখ: ${new Date().toISOString().replace('T', ' ').substring(0, 16)}
✅ আপনার ডিপোজিট টেলিগ্রাম নোটিফিকেশন সফলভাবে কাজ করছে!`;
    } else {
      testMessage = `🔔 [টেস্ট নোটিফিকেশন] নতুন অর্ডার নোটিফিকেশন
📦 প্রোডাক্ট: প্রিমিয়াম ক্যাসিনো ও বেটিং সাইট
💰 মূল্য: ১৫০০ ৳
💵 পেইড অ্যামাউন্ট: ১৫০০ ৳
📧 ইউজার জিমেইল: order.buyer@gmail.com
🌐 ডোমেইন: mybettingsite.com
📞 মোবাইল: 01836828065
✅ আপনার অর্ডার টেলিগ্রাম চ্যানেল নোটিফিকেশন সফলভাবে কাজ করছে!`;
    }

    try {
      const resp = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text: testMessage })
      });
      const data = await resp.json();
      if (data.ok) {
        addToast(
          language === 'bn'
            ? '🎉 টেলিগ্রাম টেস্ট মেসেজ সফলভাবে পাঠানো হয়েছে! আপনার চ্যানেল/বট চেক করুন।'
            : '🎉 Telegram Test Alert sent successfully! Check your channel/bot.',
          'success'
        );
        return true;
      } else {
        addToast(
          language === 'bn'
            ? `বট এরর (${data.error_code || 'Error'}): ${data.description || 'মেসেজ পাঠানো সম্ভব হয়নি'}`
            : `Telegram Bot Error: ${data.description || 'Failed to send message'}`,
          'error'
        );
        return false;
      }
    } catch (err: any) {
      addToast(
        language === 'bn' ? `কানেকশন এরর: ${err.message || 'নেটওয়ার্ক ফেইল'}` : `Connection error: ${err.message}`,
        'error'
      );
      return false;
    }
  };

  // Purchase Product with Wallet Balance
  const purchaseProduct = (
    product: Product,
    variant: ProductVariant,
    customInput?: string,
    siteDetails?: {
      siteName?: string;
      siteLogoUrl?: string;
      siteAdminEmail?: string;
      siteAdminPassword?: string;
      sitePhone?: string;
    }
  ): { success: boolean; order?: Order; message?: string } => {
    if (!isUserLoggedIn) {
      addToast(
        language === 'bn'
          ? 'অর্ডার করতে দয়া করে আগে রেজিস্ট্রেশন বা লগইন করুন।'
          : 'Please register or login first to place an order.',
        'info'
      );
      setIsAuthModalOpen(true);
      return { success: false, message: 'not_logged_in' };
    }

    if (user.isBlocked) {
      addToast(
        language === 'bn'
          ? 'আপনার অ্যাকাউন্টটি ব্লক করা রয়েছে! কোনো প্রোডাক্ট কেনা সম্ভব নয়।'
          : 'Your account is blocked! Cannot make purchases.',
        'error'
      );
      return { success: false, message: 'blocked' };
    }

    const finalPrice = variant.price;
    const currentBalance = Number(user.walletBalance) || 0;

    if (finalPrice <= 0 || currentBalance < finalPrice) {
      addToast(
        language === 'bn'
          ? `আপনার ওয়ালেটে পর্যাপ্ত টাকা নেই! প্রয়োজন ৳${finalPrice}, বর্তমান ব্যালেন্স ৳${currentBalance}। অর্ডার করতে অনুগ্রহ করে আগে টাকা ডিপোজিট (এড) করুন।`
          : `Insufficient wallet balance! Required ৳${finalPrice}, available ৳${currentBalance}. Please deposit money first.`,
        'error'
      );
      setIsAddMoneyModalOpen(true);
      return { success: false, message: 'insufficient_balance' };
    }

    // Assign credentials from pool if available
    let assignedCreds = undefined;
    let updatedProducts = [...products];

    const prodIdx = updatedProducts.findIndex((p) => p.id === product.id);
    if (prodIdx !== -1) {
      const vIdx = updatedProducts[prodIdx].variants.findIndex((v) => v.id === variant.id);
      if (vIdx !== -1) {
        const pool = updatedProducts[prodIdx].variants[vIdx].credentialsPool || [];
        if (pool.length > 0) {
          assignedCreds = pool[0];
          // Pop assigned credentials
          updatedProducts[prodIdx].variants[vIdx].credentialsPool = pool.slice(1);
        } else if (customInput) {
          assignedCreds = { additionalInfo: customInput };
        } else {
          // Fallback generated credential for smooth instant delivery
          assignedCreds = {
            email: siteDetails?.siteAdminEmail || `${product.id}.${Math.floor(100 + Math.random() * 900)}@codebazar.store`,
            password: siteDetails?.siteAdminPassword || `CB#${Math.floor(100000 + Math.random() * 900000)}`,
            pin: `${Math.floor(1000 + Math.random() * 9000)}`,
            profileName: siteDetails?.siteName || 'Master Admin'
          };
        }

        // Decrement stock
        updatedProducts[prodIdx].variants[vIdx].stockCount = Math.max(
          0,
          updatedProducts[prodIdx].variants[vIdx].stockCount - 1
        );
        updatedProducts[prodIdx].soldCount += 1;
      }
    }

    setProducts(updatedProducts);
    const updatedProd = updatedProducts[prodIdx];
    if (updatedProd) {
      saveFirestoreDoc('products', updatedProd.id, updatedProd);
    }

    // Deduct user wallet
    const updatedBalance = Math.max(0, currentBalance - finalPrice);
    setUser((prev) => ({
      ...prev,
      walletBalance: updatedBalance,
      rewardPoints: (prev.rewardPoints || 0) + Math.floor(finalPrice / 20)
    }));

    setRegisteredUsers((prev) =>
      prev.map((u) => {
        if ((user.id && u.id === user.id) || (user.phone && u.phone === user.phone) || (user.email && u.email === user.email)) {
          const updated = { ...u, walletBalance: updatedBalance };
          saveFirestoreDoc('registered_users', u.id, updated);
          return updated;
        }
        return u;
      })
    );

    if (user.id) {
      saveFirestoreDoc('registered_users', user.id, {
        id: user.id,
        name: user.name,
        phone: user.phone,
        email: user.email,
        walletBalance: updatedBalance
      });
    }

    // Record transaction
    const newTx: WalletTransaction = {
      id: 'tx-' + Date.now(),
      type: 'purchase',
      amount: finalPrice,
      method: 'wallet',
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'approved',
      descriptionBn: `${product.titleBn} (${variant.nameBn}) ক্রয়`,
      descriptionEn: `Purchased ${product.titleEn} (${variant.nameEn})`
    };
    setTransactions((prev) => [newTx, ...prev]);
    saveFirestoreDoc('transactions', newTx.id, newTx);

    // Expiry date calculation
    const now = new Date();
    const expiry = new Date(now);
    if (variant.durationEn.includes('Month')) {
      const months = parseInt(variant.durationEn) || 1;
      expiry.setMonth(expiry.getMonth() + months);
    } else if (variant.durationEn.includes('Year')) {
      expiry.setFullYear(expiry.getFullYear() + 1);
    } else {
      expiry.setDate(expiry.getDate() + 30);
    }

    // Create Order
    const newOrder: Order = {
      id: 'ord-' + Date.now(),
      orderNumber: `CB-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`,
      userId: user.id || undefined,
      userEmail: siteDetails?.siteAdminEmail || user.email || undefined,
      userPhone: siteDetails?.sitePhone || user.phone || undefined,
      userName: user.name || undefined,
      productId: product.id,
      productTitleBn: product.titleBn,
      productTitleEn: product.titleEn,
      productImage: product.imageUrl,
      variantId: variant.id,
      variantNameBn: variant.nameBn,
      variantNameEn: variant.nameEn,
      price: finalPrice,
      purchaseDate: now.toISOString().replace('T', ' ').substring(0, 16),
      expiryDate: expiry.toISOString().replace('T', ' ').substring(0, 16),
      status: 'processing',
      deliveryType: product.deliveryType,
      credentials: assignedCreds,
      instructionsBn: product.instructionsBn,
      instructionsEn: product.instructionsEn,
      warrantyDays: product.warrantyBn.includes('১ বছর') ? 365 : 30,
      warrantyClaimed: false,
      siteName: siteDetails?.siteName,
      siteLogoUrl: siteDetails?.siteLogoUrl,
      siteAdminEmail: siteDetails?.siteAdminEmail,
      siteAdminPassword: siteDetails?.siteAdminPassword,
      sitePhone: siteDetails?.sitePhone
    };

    setOrders((prev) => [newOrder, ...prev]);
    saveFirestoreDoc('orders', newOrder.id, newOrder);

    // Send Telegram Order Alert
    const prodTitle = product.titleBn || product.titleEn;
    const varName = variant.nameBn || variant.nameEn;
    const uEmail = siteDetails?.siteAdminEmail || user.email || 'N/A';
    const domainVal = siteDetails?.siteName || customInput || 'N/A';
    const uPhone = siteDetails?.sitePhone || user.phone || 'N/A';

    sendTelegramOrderNotification({
      productTitle: prodTitle,
      variantName: varName,
      price: finalPrice,
      paidAmount: finalPrice,
      userEmail: uEmail,
      domain: domainVal,
      userPhone: uPhone,
      orderNumber: newOrder.orderNumber
    });



    addToast(
      language === 'bn'
        ? `🎉 ধন্যবাদ! আপনার অর্ডারটা কনফার্ম হয়েছে। কিছুক্ষণের মধ্যে আপনার অর্ডার কনফার্ম ও প্রসেস হয়ে যাবে।`
        : `🎉 Thank you! Your order has been placed and will be confirmed shortly.`,
      'success'
    );

    return { success: true, order: newOrder };
  };

  // Direct Payment Purchase (bKash / Nagad Direct Gateway)
  const purchaseProductDirect = (
    product: Product,
    variant: ProductVariant,
    method: PaymentMethod,
    senderMobile: string,
    trxId: string,
    customInput?: string,
    siteDetails?: {
      siteName?: string;
      siteLogoUrl?: string;
      siteAdminEmail?: string;
      siteAdminPassword?: string;
      sitePhone?: string;
    }
  ): { success: boolean; order?: Order; message?: string } => {
    const cleanTrx = trxId.trim().toUpperCase();
    const cleanMobile = senderMobile.trim();

    if (!cleanMobile || cleanMobile.length < 11) {
      addToast(language === 'bn' ? 'সঠিক পেমেন্ট মোবাইল নম্বর লিখুন!' : 'Please enter valid sender phone number!', 'error');
      return { success: false, message: 'invalid_mobile' };
    }

    if (!cleanTrx || cleanTrx.length < 5) {
      addToast(language === 'bn' ? 'সঠিক Transaction ID (TrxID) লিখুন!' : 'Please enter valid Transaction ID!', 'error');
      return { success: false, message: 'invalid_trx' };
    }

    if (user.isBlocked) {
      addToast(
        language === 'bn'
          ? 'আপনার অ্যাকাউন্টটি ব্লক করা রয়েছে! কোনো প্রোডাক্ট কেনা সম্ভব নয়।'
          : 'Your account is blocked! Cannot make purchases.',
        'error'
      );
      return { success: false, message: 'blocked' };
    }

    const finalPrice = variant.price;

    let assignedCreds = undefined;
    let updatedProducts = [...products];

    const prodIdx = updatedProducts.findIndex((p) => p.id === product.id);
    if (prodIdx !== -1) {
      const vIdx = updatedProducts[prodIdx].variants.findIndex((v) => v.id === variant.id);
      if (vIdx !== -1) {
        const pool = updatedProducts[prodIdx].variants[vIdx].credentialsPool || [];
        if (pool.length > 0) {
          assignedCreds = pool[0];
          updatedProducts[prodIdx].variants[vIdx].credentialsPool = pool.slice(1);
        } else if (customInput) {
          assignedCreds = { additionalInfo: customInput };
        } else {
          assignedCreds = {
            email: siteDetails?.siteAdminEmail || `${product.id}.${Math.floor(100 + Math.random() * 900)}@codebazar.store`,
            password: siteDetails?.siteAdminPassword || `CB#${Math.floor(100000 + Math.random() * 900000)}`,
            pin: `${Math.floor(1000 + Math.random() * 9000)}`,
            profileName: siteDetails?.siteName || 'Master Admin'
          };
        }
        updatedProducts[prodIdx].variants[vIdx].stockCount = Math.max(
          0,
          updatedProducts[prodIdx].variants[vIdx].stockCount - 1
        );
        updatedProducts[prodIdx].soldCount += 1;
      }
    }

    setProducts(updatedProducts);
    const updatedProdDirect = updatedProducts[prodIdx];
    if (updatedProdDirect) {
      saveFirestoreDoc('products', updatedProdDirect.id, updatedProdDirect);
    }

    // Record transaction as pending verification
    const newTx: WalletTransaction = {
      id: 'tx-' + Date.now(),
      type: 'purchase',
      amount: finalPrice,
      method: method,
      trxId: cleanTrx,
      senderMobile: cleanMobile,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending',
      descriptionBn: `${product.titleBn} (${variant.nameBn}) - ${method.toUpperCase()} ডাইরেক্ট পে (TrxID: ${cleanTrx})`,
      descriptionEn: `Direct ${method.toUpperCase()} Payment for ${product.titleEn} (${variant.nameEn}) (TrxID: ${cleanTrx})`
    };
    setTransactions((prev) => [newTx, ...prev]);
    saveFirestoreDoc('transactions', newTx.id, newTx);

    const now = new Date();
    const expiry = new Date(now);
    if (variant.durationEn.includes('Month')) {
      const months = parseInt(variant.durationEn) || 1;
      expiry.setMonth(expiry.getMonth() + months);
    } else if (variant.durationEn.includes('Year')) {
      expiry.setFullYear(expiry.getFullYear() + 1);
    } else {
      expiry.setDate(expiry.getDate() + 30);
    }

    const newOrder: Order = {
      id: 'ord-' + Date.now(),
      orderNumber: `CB-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`,
      userId: user.id || undefined,
      userEmail: siteDetails?.siteAdminEmail || user.email || undefined,
      userPhone: cleanMobile || siteDetails?.sitePhone || user.phone || undefined,
      userName: user.name || undefined,
      productId: product.id,
      productTitleBn: product.titleBn,
      productTitleEn: product.titleEn,
      productImage: product.imageUrl,
      variantId: variant.id,
      variantNameBn: variant.nameBn,
      variantNameEn: variant.nameEn,
      price: finalPrice,
      purchaseDate: now.toISOString().replace('T', ' ').substring(0, 16),
      expiryDate: expiry.toISOString().replace('T', ' ').substring(0, 16),
      status: 'processing',
      deliveryType: product.deliveryType,
      credentials: assignedCreds,
      instructionsBn: product.instructionsBn,
      instructionsEn: product.instructionsEn,
      warrantyDays: product.warrantyBn?.includes('১ বছর') ? 365 : 30,
      warrantyClaimed: false,
      siteName: siteDetails?.siteName,
      siteLogoUrl: siteDetails?.siteLogoUrl,
      siteAdminEmail: siteDetails?.siteAdminEmail,
      siteAdminPassword: siteDetails?.siteAdminPassword,
      sitePhone: siteDetails?.sitePhone,
      paymentMethod: method,
      paymentTrxId: cleanTrx,
      paymentSenderMobile: cleanMobile
    };

    setOrders((prev) => [newOrder, ...prev]);
    saveFirestoreDoc('orders', newOrder.id, newOrder);

    // Send Telegram Order Alert
    const prodTitle = product.titleBn || product.titleEn;
    const varName = variant.nameBn || variant.nameEn;
    const uEmail = siteDetails?.siteAdminEmail || user.email || 'N/A';
    const domainVal = siteDetails?.siteName || customInput || 'N/A';
    const uPhone = cleanMobile || siteDetails?.sitePhone || user.phone || 'N/A';

    sendTelegramOrderNotification({
      productTitle: prodTitle,
      variantName: varName,
      price: finalPrice,
      paidAmount: finalPrice,
      userEmail: uEmail,
      domain: domainVal,
      userPhone: uPhone,
      orderNumber: newOrder.orderNumber,
      paymentMethod: method,
      trxId: cleanTrx
    });

    addToast(
      language === 'bn'
        ? `🎉 ধন্যবাদ! আপনার পেমেন্ট তথ্য ও অর্ডার কনফার্ম হয়েছে।`
        : `🎉 Thank you! Payment information & order submitted successfully.`,
      'success'
    );

    return { success: true, order: newOrder };
  };

  const adminAddCategory = (category: Category) => {
    const cleanId = category.id ? category.id.toLowerCase().trim().replace(/\s+/g, '_') : 'cat_' + Date.now();
    const newCat = { ...category, id: cleanId };
    setCategories((prev) => {
      if (prev.some((c) => c.id === cleanId)) {
        return prev.map((c) => (c.id === cleanId ? newCat : c));
      }
      return [...prev, newCat];
    });
    saveFirestoreDoc('categories', cleanId, newCat);
    addToast(language === 'bn' ? 'নতুন ক্যাটাগরি যুক্ত করা হয়েছে!' : 'Category added successfully!', 'success');
  };

  const adminUpdateCategory = (updatedCat: Category, oldId?: string) => {
    const targetId = oldId || updatedCat.id;
    setCategories((prev) => prev.map((c) => (c.id === targetId ? updatedCat : c)));
    if (oldId && oldId !== updatedCat.id) {
      deleteFirestoreDoc('categories', oldId);
      setProducts((prev) =>
        prev.map((p) => (p.categoryId === oldId ? { ...p, categoryId: updatedCat.id } : p))
      );
    }
    saveFirestoreDoc('categories', updatedCat.id, updatedCat);
    addToast(language === 'bn' ? 'ক্যাটাগরি সফলভাবে আপডেট করা হয়েছে!' : 'Category updated successfully!', 'success');
  };

  const adminDeleteCategory = (categoryId: string) => {
    if (categoryId === 'all') {
      addToast(
        language === 'bn' ? 'ডিফল্ট "সকল আইটেম" ক্যাটাগরি মোছা সম্ভব নয়!' : 'Cannot delete default category!',
        'error'
      );
      return;
    }
    setCategories((prev) => prev.filter((c) => c.id !== categoryId));
    deleteFirestoreDoc('categories', categoryId);
    // Re-assign products in this category to betting_scripts or another existing category
    setProducts((prev) =>
      prev.map((p) => (p.categoryId === categoryId ? { ...p, categoryId: 'betting_scripts' } : p))
    );
    if (selectedCategory === categoryId) {
      setSelectedCategory('all');
    }
    addToast(language === 'bn' ? 'ক্যাটাগরি সফলভাবে মুছে ফেলা হয়েছে!' : 'Category deleted successfully!', 'info');
  };

  const claimWarranty = (orderId: string, reason: string): boolean => {
    const idx = orders.findIndex((o) => o.id === orderId);
    if (idx === -1) return false;

    const order = orders[idx];
    const updated = [...orders];

    // Auto-generate replacement credentials!
    const newCredentials = {
      email: `${order.productId}.replaced.${Math.floor(100 + Math.random() * 900)}@codebazar.store`,
      password: `CB#Rep${Math.floor(100000 + Math.random() * 900000)}`,
      pin: `${Math.floor(1000 + Math.random() * 9000)}`,
      profileName: 'Replaced Profile 1'
    };

    updated[idx] = {
      ...order,
      warrantyClaimed: true,
      credentials: newCredentials
    };

    setOrders(updated);
    saveFirestoreDoc('orders', orderId, updated[idx]);

    addToast(
      language === 'bn'
        ? 'আপনার ওয়ারেন্টি ক্লেম গ্রহণ করে নতুন অ্যাকাউন্টের বিবরণ আপডেট করা হয়েছে!'
        : 'Warranty replacement approved! New credentials issued.',
      'success'
    );

    return true;
  };

  const createSupportTicket = (subject: string, category: any, message: string, orderId?: string) => {
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const newTicket: SupportTicket = {
      id: 'tkt-' + Date.now(),
      ticketNumber: `TK-${Math.floor(1000 + Math.random() * 9000)}`,
      orderId,
      subject,
      category,
      status: 'open',
      createdAt: nowStr,
      updatedAt: nowStr,
      messages: [
        {
          id: 'msg-' + Date.now(),
          sender: 'user',
          text: message,
          timestamp: nowStr
        }
      ]
    };

    setTickets((prev) => [newTicket, ...prev]);
    saveFirestoreDoc('tickets', newTicket.id, newTicket);
    addToast(
      language === 'bn' ? 'সাপোর্ট টিকিট তৈরি করা হয়েছে। অতি দ্রুত সমাধান প্রদান করা হবে।' : 'Support ticket submitted successfully.',
      'success'
    );

    // Auto-Reply Bot Response
    setTimeout(() => {
      const autoReplyMsg = {
        id: 'msg-auto-' + Date.now(),
        sender: 'support' as const,
        text: language === 'bn'
          ? '🤖 [অটোমেটিক সাপোর্ট বটের মেসেজ]: ধন্যবাদ! আমাদের হেল্প ডেস্কে মেসেজ পাঠানোর জন্য। নতুন কোনো রেডিমেড ওয়েবসাইট বা প্যানেল কিনতে চাইলে সরাসরি আমাদের মার্কেটপ্লেস থেকে পছন্দ অনুযায়ী অর্ডার (Order) করুন। অর্ডারে কোনো পাসওয়ার্ড বা সাইট সমস্যা থাকলে আপনার অর্ডার আইডি জানান, সমাধান করে দেয়া হবে। জরুরী প্রয়োজনে হোয়াটসঅ্যাপ (01836828065) এ ইনবক্স করুন।'
          : '🤖 [Auto Support Reply]: Thank you for contacting support! To buy ready websites or digital accounts, please order directly from our marketplace. If you are facing any issue with your order, please provide details or contact WhatsApp (01836828065).',
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
      };

      setTickets((prev) => {
        const updatedTickets = prev.map((t) => (t.id === newTicket.id ? { ...t, messages: [...t.messages, autoReplyMsg] } : t));
        const updatedTicket = updatedTickets.find((t) => t.id === newTicket.id);
        if (updatedTicket) saveFirestoreDoc('tickets', newTicket.id, updatedTicket);
        return updatedTickets;
      });
    }, 1200);
  };

  const addTicketMessage = (ticketId: string, text: string) => {
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setTickets((prev) =>
      prev.map((t) => {
        if (t.id === ticketId) {
          const userMsg = {
            id: 'msg-' + Date.now(),
            sender: 'user' as const,
            text,
            timestamp: nowStr
          };
          return {
            ...t,
            messages: [...t.messages, userMsg],
            updatedAt: nowStr
          };
        }
        return t;
      })
    );

    // Trigger auto support guidance if needed
    setTimeout(() => {
      const autoReplyMsg = {
        id: 'msg-auto-' + Date.now(),
        sender: 'support' as const,
        text: language === 'bn'
          ? '🤖 [অটো-রেসপন্স]: আপনার বার্তাটি গ্রহন করা হয়েছে। যেকোনো নতুন কেনাকাটার জন্য আমাদের মার্কেটপ্লেসে পছন্দমতো প্রোডাক্ট সিলেক্ট করে অর্ডার করুন। অর্ডারে সমস্যার ক্ষেত্রে আমরা সাথে সাথে চেক করে সঠিক সলিউশন প্রদান করছি।'
          : '🤖 [Auto-Response]: Your message was received. For new orders choose products on our marketplace. Our team is providing instant resolution for order issues.',
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
      };

      setTickets((prev) =>
        prev.map((t) => (t.id === ticketId ? { ...t, messages: [...t.messages, autoReplyMsg] } : t))
      );
    }, 1200);
  };

  // Admin Actions
  const adminApproveTransaction = (txId: string) => {
    const tx = transactions.find((t) => t.id === txId);
    if (tx && tx.type === 'deposit' && tx.status !== 'approved') {
      const creditTotal = tx.amount;

      // Update in registered users list
      setRegisteredUsers((prev) =>
        prev.map((u) => {
          const isMatch =
            (tx.userId && u.id === tx.userId) ||
            (tx.userEmail && u.email === tx.userEmail) ||
            (tx.senderMobile && tx.senderMobile !== 'N/A' && u.phone === tx.senderMobile);

          if (isMatch) {
            const updatedUser = { ...u, walletBalance: (u.walletBalance || 0) + creditTotal };
            saveFirestoreDoc('registered_users', u.id, updatedUser);
            return updatedUser;
          }
          return u;
        })
      );

      // If current logged-in user is the one who deposited, update their active wallet state
      if (
        (tx.userId && user.id === tx.userId) ||
        (tx.userEmail && user.email === tx.userEmail) ||
        (tx.senderMobile && user.phone === tx.senderMobile)
      ) {
        setUser((prev) => ({ ...prev, walletBalance: prev.walletBalance + creditTotal }));
      }
    }
    setTransactions((prev) =>
      prev.map((t) => {
        if (t.id === txId) {
          const updatedTx = { ...t, status: 'approved' as const };
          saveFirestoreDoc('transactions', txId, updatedTx);
          return updatedTx;
        }
        return t;
      })
    );
    const totalAdded = tx ? tx.amount : 0;
    addToast(
      language === 'bn'
        ? `✅ ডিপোজিট এপ্রুভ করা হয়েছে এবং ৳${totalAdded} ইউজারের ওয়ালেটে যুক্ত করা হয়েছে!`
        : `✅ Deposit approved and ৳${totalAdded} credited to user wallet!`,
      'success'
    );
  };

  const adminCreditUserBalance = (userId: string, amount: number, note?: string) => {
    if (amount <= 0) {
      addToast(language === 'bn' ? 'সঠিক টাকার পরিমাণ লিখুন!' : 'Enter a valid amount!', 'error');
      return;
    }

    const targetUser = registeredUsers.find((u) => u.id === userId);

    setRegisteredUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const updated = { ...u, walletBalance: u.walletBalance + amount };
          saveFirestoreDoc('registered_users', u.id, updated);
          return updated;
        }
        return u;
      })
    );

    if (targetUser && (user.phone === targetUser.phone || user.email === targetUser.email || userId === 'current')) {
      setUser((prev) => ({ ...prev, walletBalance: prev.walletBalance + amount }));
    } else if (userId === 'current') {
      setUser((prev) => ({ ...prev, walletBalance: prev.walletBalance + amount }));
    }

    const newTx: WalletTransaction = {
      id: 'tx-' + Date.now(),
      type: 'deposit',
      amount: amount,
      date: new Date().toISOString().split('T')[0],
      status: 'approved',
      method: 'bkash',
      trxId: 'ADMIN-CREDIT-' + Math.floor(100000 + Math.random() * 900000),
      senderMobile: targetUser?.phone || user.phone,
      descriptionBn: note || 'অ্যাডমিন কর্তৃক ম্যানুয়াল রিচার্জ',
      descriptionEn: note || 'Manual balance credit by admin'
    };
    setTransactions((prev) => [newTx, ...prev]);
    saveFirestoreDoc('transactions', newTx.id, newTx);

    addToast(
      language === 'bn'
        ? `ইউজার ${targetUser?.name || ''} এর ওয়ালেটে ৳${amount} টাকা ম্যানুয়ালি যোগ করা হয়েছে!`
        : `Successfully credited ৳${amount} to user balance!`,
      'success'
    );
  };

  const adminRejectTransaction = (txId: string) => {
    setTransactions((prev) =>
      prev.map((t) => {
        if (t.id === txId) {
          const updatedTx = { ...t, status: 'rejected' as const };
          saveFirestoreDoc('transactions', txId, updatedTx);
          return updatedTx;
        }
        return t;
      })
    );
    addToast('Transaction rejected', 'info');
  };

  const adminAddProduct = (newProduct: Product) => {
    setProducts((prev) => [newProduct, ...prev]);
    saveFirestoreDoc('products', newProduct.id, newProduct);
    setSelectedCategory('all'); // Set filter to all so new product is immediately visible on main marketplace

    // Auto Push Notification Broadcast to all phones
    const autoNotify = siteConfig.pushAutoNotifyOnNewProduct ?? true;
    if (autoNotify) {
      const titleText = `CODE BAZAR - নতুন ${(newProduct as any).badgeText || 'প্রোডাক্ট'} যুক্ত হয়েছে! 🔥`;
      const minPrice = newProduct.variants?.[0]?.price || 0;
      const bodyText = `${newProduct.titleBn || newProduct.titleEn} - মাত্র ${siteConfig.currencySymbol || '৳'}${minPrice.toLocaleString()} টাকা! এখনই বিস্তারিত দেখতে ট্যাপ করুন।`;
      const prodImage = newProduct.imageUrl || '/icon-512.png';

      const pushDoc: PushBroadcast = {
        id: 'push-prod-' + Date.now(),
        title: titleText,
        body: bodyText,
        icon: siteConfig.logoUrl || '/icon-192.png',
        image: prodImage,
        url: '/',
        productId: newProduct.id,
        tag: 'prod-' + newProduct.id,
        createdAt: new Date().toISOString(),
        timestamp: Date.now()
      };

      saveFirestoreDoc('broadcast_notifications', pushDoc.id, pushDoc);

      // Trigger locally if allowed
      triggerDeviceNotification(pushDoc.title, {
        body: pushDoc.body,
        image: pushDoc.image,
        icon: pushDoc.icon,
        url: pushDoc.url,
        tag: pushDoc.tag
      });
    }

    addToast(
      language === 'bn'
        ? `🎉 '${newProduct.titleBn}' প্রোডাক্ট নতুন যুক্ত করা হয়েছে এবং সকল ইউজারের ফোনে নোটিফিকেশন পাঠানো হয়েছে!`
        : `🎉 Product '${newProduct.titleEn}' added and push alert broadcasted!`,
      'success'
    );
  };

  const adminUpdatePaymentNumbers = (numbers: {
    bkash: string;
    nagad: string;
    rocket: string;
    upay: string;
    bkashLogo?: string;
    nagadLogo?: string;
    rocketLogo?: string;
    upayLogo?: string;
    bkashEnabled?: boolean;
    nagadEnabled?: boolean;
    rocketEnabled?: boolean;
    upayEnabled?: boolean;
    quickDepositAmounts?: number[];
  }) => {
    setPaymentNumbers(numbers);
    saveFirestoreDoc('store_meta', 'payment_numbers', numbers);
    addToast(
      language === 'bn'
        ? 'পেমেন্ট গেটওয়ে নম্বর, লোগো, ডিপোজিট অ্যামাউন্ট ও স্ট্যাটাস আপডেট করা হয়েছে!'
        : 'Payment gateway settings & deposit amounts updated!',
      'success'
    );
  };

  const adminUpdateStock = (productId: string, variantId: string, count: number, credentialsText?: string) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          const updatedProd = {
            ...p,
            variants: p.variants.map((v) => {
              if (v.id === variantId) {
                let pool = v.credentialsPool || [];
                if (credentialsText) {
                  const lines = credentialsText.split('\n').filter((l) => l.trim());
                  const newCreds = lines.map((line) => {
                    const parts = line.split('|');
                    return {
                      email: parts[0]?.trim(),
                      password: parts[1]?.trim(),
                      pin: parts[2]?.trim(),
                      licenseKey: parts[3]?.trim()
                    };
                  });
                  pool = [...pool, ...newCreds];
                }
                return {
                  ...v,
                  stockCount: v.stockCount + count,
                  inStock: v.stockCount + count > 0,
                  credentialsPool: pool
                };
              }
              return v;
            })
          };
          saveFirestoreDoc('products', productId, updatedProd);
          return updatedProd;
        }
        return p;
      })
    );
    addToast('Stock inventory updated successfully!', 'success');
  };

  const adminEditProduct = (updatedProduct: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updatedProduct.id ? updatedProduct : p)));
    saveFirestoreDoc('products', updatedProduct.id, updatedProduct);
    addToast(language === 'bn' ? 'প্রোডাক্ট আপডেট করা হয়েছে!' : 'Product updated successfully!', 'success');
  };

  const adminDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    deleteFirestoreDoc('products', productId);
    addToast(language === 'bn' ? 'প্রোডাক্ট ডিলিট করা হয়েছে!' : 'Product deleted successfully!', 'info');
  };

  const adminUpdateAnnouncement = (textBn: string, textEn: string) => {
    const ann = { id: 'ann-1', textBn, textEn, type: 'info' as const, active: true };
    setAnnouncements([ann]);
    saveFirestoreDoc('announcements', 'ann-1', ann);
    addToast(language === 'bn' ? 'নোটিশ ব্যানার আপডেট করা হয়েছে!' : 'Notice banner updated!', 'success');
  };

  const adminAddBanner = (imageUrl: string, title?: string, linkUrl?: string) => {
    const newBanner: PromoBanner = {
      id: 'bnr-' + Date.now(),
      imageUrl: imageUrl.trim(),
      title: title?.trim() || 'Code Bazar Banner',
      linkUrl: linkUrl?.trim() || undefined,
      active: true
    };
    setBanners((prev) => [newBanner, ...prev]);
    saveFirestoreDoc('banners', newBanner.id, newBanner);
    addToast(language === 'bn' ? 'নতুন ব্যানার আপলোড ও যুক্ত হয়েছে!' : 'New banner added successfully!', 'success');
  };

  const adminUpdateBanner = (banner: PromoBanner) => {
    setBanners((prev) => prev.map((b) => (b.id === banner.id ? banner : b)));
    saveFirestoreDoc('banners', banner.id, banner);
    addToast(language === 'bn' ? 'ব্যানার সফলভাবে আপডেট করা হয়েছে!' : 'Banner updated successfully!', 'success');
  };

  const adminDeleteBanner = (bannerId: string) => {
    setBanners((prev) => prev.filter((b) => b.id !== bannerId));
    deleteFirestoreDoc('banners', bannerId);
    addToast(language === 'bn' ? 'ব্যানার ডিলিট করা হয়েছে!' : 'Banner deleted successfully!', 'info');
  };

  const adminUpdateUserBalance = (amount: number) => {
    setUser((prev) => ({ ...prev, walletBalance: amount }));
    if (user.id) {
      saveFirestoreDoc('registered_users', user.id, {
        id: user.id,
        name: user.name,
        phone: user.phone,
        email: user.email,
        walletBalance: amount
      });
    }
    setRegisteredUsers((prev) =>
      prev.map((u) => {
        if ((user.phone && u.phone === user.phone) || (user.email && u.email === user.email)) {
          const updated = { ...u, walletBalance: amount };
          saveFirestoreDoc('registered_users', u.id, updated);
          return updated;
        }
        return u;
      })
    );
    addToast(language === 'bn' ? `ব্যালেন্স ৳${amount} আপডেট করা হয়েছে!` : `User balance updated to ৳${amount}!`, 'success');
  };

  const adminUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          const updated = { ...o, status };
          saveFirestoreDoc('orders', orderId, updated);
          return updated;
        }
        return o;
      })
    );
    addToast(
      language === 'bn'
        ? `অর্ডার স্ট্যাটাস আপডেট করা হয়েছে: '${status}'`
        : `Order status updated to '${status}'!`,
      'success'
    );
  };

  const adminDeleteOrder = (orderId: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== orderId));
    deleteFirestoreDoc('orders', orderId);
    addToast(
      language === 'bn' ? 'অর্ডার সফলভাবে রিমুভ করা হয়েছে!' : 'Order deleted successfully!',
      'info'
    );
  };

  const adminClearCancelledOrders = () => {
    const cancelledOrders = orders.filter((o) => o.status === 'expired');
    if (cancelledOrders.length === 0) {
      addToast(
        language === 'bn' ? 'কোনো বাতিলকৃত অর্ডার নেই!' : 'No cancelled orders found!',
        'info'
      );
      return;
    }
    cancelledOrders.forEach((o) => deleteFirestoreDoc('orders', o.id));
    setOrders((prev) => prev.filter((o) => o.status !== 'expired'));
    addToast(
      language === 'bn'
        ? `মোট ${cancelledOrders.length} টি বাতিলকৃত অর্ডার স্থায়ীভাবে ডিলিট করা হয়েছে!`
        : `${cancelledOrders.length} cancelled orders permanently deleted!`,
      'success'
    );
  };

  const adminDeleteTransaction = (txId: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== txId));
    deleteFirestoreDoc('transactions', txId);
    addToast(
      language === 'bn' ? 'লেনদেন রেকর্ড রিমুভ করা হয়েছে!' : 'Transaction deleted successfully!',
      'info'
    );
  };

  const adminClearRejectedTransactions = () => {
    const rejectedTx = transactions.filter((t) => t.status === 'rejected');
    if (rejectedTx.length === 0) {
      addToast(
        language === 'bn' ? 'কোনো বাতিলকৃত ডিপোজিট রিকোয়েস্ট নেই!' : 'No rejected deposit requests found!',
        'info'
      );
      return;
    }
    rejectedTx.forEach((t) => deleteFirestoreDoc('transactions', t.id));
    setTransactions((prev) => prev.filter((t) => t.status !== 'rejected'));
    addToast(
      language === 'bn'
        ? `মোট ${rejectedTx.length} টি বাতিলকৃত ডিপোজিট রেকর্ড ডিলিট করা হয়েছে!`
        : `${rejectedTx.length} rejected deposit requests permanently deleted!`,
      'success'
    );
  };

  const adminToggleBlockUser = (userId: string) => {
    setRegisteredUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const nextState = !u.isBlocked;
          const updated = { ...u, isBlocked: nextState };
          saveFirestoreDoc('registered_users', userId, updated);
          addToast(
            language === 'bn'
              ? nextState
                ? `ইউজার '${u.name}' সফলভাবে ব্লক করা হয়েছে!`
                : `ইউজার '${u.name}' আনব্লক করা হয়েছে!`
              : nextState
                ? `User '${u.name}' blocked!`
                : `User '${u.name}' unblocked!`,
            nextState ? 'error' : 'success'
          );
          return updated;
        }
        return u;
      })
    );
  };

  const adminDeleteUser = (userId: string) => {
    setRegisteredUsers((prev) => prev.filter((u) => u.id !== userId));
    deleteFirestoreDoc('registered_users', userId);
    addToast(
      language === 'bn' ? 'ইউজার তালিকা থেকে ডিলিট করা হয়েছে!' : 'User deleted from directory!',
      'info'
    );
  };

  const adminClearHistory = () => {
    orders.forEach((o) => deleteFirestoreDoc('orders', o.id));
    transactions.forEach((t) => deleteFirestoreDoc('transactions', t.id));
    setOrders([]);
    setTransactions([]);
    safeSetItem('xsb_orders', JSON.stringify([]));
    safeSetItem('xsb_transactions', JSON.stringify([]));
    safeSetItem('xsb_orders_v2', JSON.stringify([]));
    safeSetItem('xsb_transactions_v2', JSON.stringify([]));
    addToast(
      language === 'bn' ? 'সকল অর্ডার ও ডিপোজিট হিস্ট্রি রিমুভ করা হয়েছে!' : 'All order & deposit history cleared!',
      'info'
    );
  };

  const adminResetVisitorStats = () => {
    const resetStats: VisitorStats = {
      totalVisits: 0,
      todayVisits: 0,
      uniqueVisitors: 0,
      liveVisitors: 1,
      lastVisitAt: new Date().toISOString(),
      dailyVisits: {}
    };
    setVisitorStats(resetStats);
    safeSetItem('cb_visitor_stats', JSON.stringify(resetStats));
    saveFirestoreDoc('site_stats', 'visitors', resetStats);
    addToast(language === 'bn' ? 'ভিজিটর অ্যানালিটিক্স রিসেট করা হয়েছে!' : 'Visitor stats reset successfully!', 'info');
  };

  const adminUpdateVisitorStats = (newStats: Partial<VisitorStats>) => {
    setVisitorStats((prev) => {
      const updated = { ...prev, ...newStats };
      safeSetItem('cb_visitor_stats', JSON.stringify(updated));
      saveFirestoreDoc('site_stats', 'visitors', updated);
      return updated;
    });
    addToast(language === 'bn' ? 'ভিজিটর ডেটা আপডেট করা হয়েছে!' : 'Visitor stats updated successfully!', 'success');
  };

  return (
    <StoreContext.Provider
      value={{
        language,
        setLanguage,
        activeTab,
        setActiveTab,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        categories,
        registeredUsers,
        banners,
        viewMode,
        setViewMode,
        user,
        setUser,
        products,
        setProducts,
        orders,
        transactions,
        announcements,
        paymentNumbers,
        siteConfig,
        visitorStats,
        tickets,
        toasts,
        addToast,
        removeToast,
        adminUpdateSiteConfig,
        adminResetVisitorStats,
        adminUpdateVisitorStats,
        addMoneyRequest,
        purchaseProduct,
        purchaseProductDirect,
        claimWarranty,
        createSupportTicket,
        addTicketMessage,
        adminApproveTransaction,
        adminRejectTransaction,
        adminAddCategory,
        adminUpdateCategory,
        adminDeleteCategory,
        adminAddProduct,
        adminEditProduct,
        adminDeleteProduct,
        adminUpdateStock,
        adminUpdatePaymentNumbers,
        adminUpdateAnnouncement,
        adminAddBanner,
        adminUpdateBanner,
        adminDeleteBanner,
        adminUpdateUserBalance,
        adminCreditUserBalance,
        adminUpdateOrderStatus,
        adminDeleteOrder,
        adminClearCancelledOrders,
        adminDeleteTransaction,
        adminClearRejectedTransactions,
        adminToggleBlockUser,
        adminDeleteUser,
        adminTestTelegramNotification,
        adminClearHistory,
        pushBroadcasts,
        pushNotificationPermission,
        isPushNotificationSupported,
        activePushAlert,
        setActivePushAlert,
        requestPushNotificationPermission,
        triggerDeviceNotification,
        adminSendPushBroadcast,
        adminTestPushNotification,
        selectedProductForBuy,
        setSelectedProductForBuy,
        selectedOrderForView,
        setSelectedOrderForView,
        isAddMoneyModalOpen,
        setIsAddMoneyModalOpen,
        isProfileDrawerOpen,
        setIsProfileDrawerOpen,
        isAdminView,
        setIsAdminView,
        isUserLoggedIn,
        setIsUserLoggedIn,
        isAuthModalOpen,
        setIsAuthModalOpen,
        registerUser,
        loginUser,
        loginWithGoogle,
        logoutUser,
        isAdminAuthenticated,
        setIsAdminAuthenticated,
        isAdminAuthModalOpen,
        setIsAdminAuthModalOpen,
        verifyAdminPin,
        verifyAdminApiKey,
        isAdminPermanentlyLocked,
        adminLockDetails,
        unlockAdminWithMasterKey,
        adminLockPermanently,
        adminUnlockPermanently
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within StoreProvider');
  }
  return context;
};
