// Small compatibility layer so the existing store code can keep its
// collection/doc/onSnapshot style while using the existing Realtime Database.
import {
  Database,
  DataSnapshot,
  onValue,
  ref,
  remove,
  set,
  update,
} from 'firebase/database';

type DocSnap = {
  id: string;
  exists: () => boolean;
  data: () => any;
};

type QuerySnap = {
  empty: boolean;
  docs: DocSnap[];
  docChanges: () => Array<{ type: 'added' | 'modified' | 'removed'; doc: DocSnap }>;
};

type DocRef = { __kind: 'doc'; db: Database; path: string; id: string };
type CollectionRef = { __kind: 'collection'; db: Database; path: string };

export const collection = (database: Database, path: string): CollectionRef => ({
  __kind: 'collection', db: database, path,
});

export const doc = (database: Database, collectionPath: string, id: string): DocRef => ({
  __kind: 'doc', db: database, path: `${collectionPath}/${id}`, id,
});

const makeDoc = (id: string, value: any): DocSnap => ({
  id,
  exists: () => value !== null && value !== undefined,
  data: () => (value && typeof value === 'object' ? value : {}),
});

const collectionSnapshot = (snapshot: DataSnapshot): QuerySnap => {
  const value = snapshot.val();
  const docs: DocSnap[] = [];
  if (value && typeof value === 'object') {
    Object.entries(value).forEach(([id, data]) => docs.push(makeDoc(id, data)));
  }
  return {
    empty: docs.length === 0,
    docs,
    // RTDB's value listener does not expose Firestore-style docChanges.
    // Treat current records as added; the store's timestamp guard prevents
    // old notifications from firing on initial load.
    docChanges: () => docs.map((d) => ({ type: 'added' as const, doc: d })),
  };
};

const documentSnapshot = (snapshot: DataSnapshot, id: string): DocSnap =>
  makeDoc(id, snapshot.val());

export const onSnapshot = (
  target: CollectionRef | DocRef,
  next: (snapshot: any) => void,
  error?: (err: any) => void,
) => {
  const listener = onValue(
    ref(target.db, target.path),
    (snapshot) => {
      try {
        next(target.__kind === 'collection'
          ? collectionSnapshot(snapshot)
          : documentSnapshot(snapshot, target.id));
      } catch (err) {
        error?.(err);
      }
    },
    (err) => error?.(err),
  );
  return listener;
};

export const setDoc = async (
  target: DocRef,
  data: any,
  options?: { merge?: boolean },
) => {
  const targetRef = ref(target.db, target.path);
  if (options?.merge) {
    await update(targetRef, data);
  } else {
    await set(targetRef, data);
  }
};

export const deleteDoc = async (target: DocRef) => {
  await remove(ref(target.db, target.path));
};
